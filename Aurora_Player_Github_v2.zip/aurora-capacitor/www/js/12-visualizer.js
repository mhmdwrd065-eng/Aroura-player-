// =======================================================
// == كشف أداء الجهاز وضبط الجودة تلقائياً ==
// =======================================================

const DevicePerf = (() => {
    const cores  = navigator.hardwareConcurrency || 2;
    const memory = navigator.deviceMemory        || 2;
    const dpr    = window.devicePixelRatio       || 1;

    // مستوى ضعيف (أجهزة متوسطة-أدنى)
    const isLow  = cores <= 2 || memory <= 1 ||
                   (cores <= 4 && memory <= 2) ||
                   (screen.width <= 420 && dpr >= 2 && memory <= 2);

    // [تحسين] مستوى ضعيف جداً — للهواتف ذات GPU محدود كـ Oppo A1K
    // المعيار: جهاز ضعيف + 4 أنوية أو أقل + ذاكرة 2GB + شاشة DPR عالية
    const isUltraLow = isLow && cores <= 4 && memory <= 2 && dpr >= 2;

    return {
        isLowEnd:     isLow,
        isUltraLow:   isUltraLow,
        fftSize:      isUltraLow ? 256  : (isLow ? 512  : 1024),
        targetFPS:    isUltraLow ? 24   : (isLow ? 30   : 60),
        maxParticles: isUltraLow ? 30   : (isLow ? 60   : 150),
        maxDPR:       isLow ? 1    : Math.min(window.devicePixelRatio || 1, 2),
        detailScale:  isUltraLow ? 0.35 : (isLow ? 0.5  : 1.0),
        quality:      isUltraLow ? 'ultralow' : (isLow ? 'low' : 'high'),
    };
})();

// [تشخيص] طباعة معلومات الجهاز في الكونسول
console.log(`[Aurora] 🎨 جودة الرسم: ${DevicePerf.quality} | ${DevicePerf.targetFPS}fps | fftSize=${DevicePerf.fftSize} | particles=${DevicePerf.maxParticles} | glow=${DevicePerf.isUltraLow ? 'معطّل' : 'مفعّل'}`);

// ── ضبط معدل الإطارات التكيفي ──
let _lastFrameTime = 0;
const _frameInterval = 1000 / DevicePerf.targetFPS;

// [تحسين] دالة مساعدة لتحديد عدد العناصر بناءً على مستوى الأداء
// isUltraLow → UL,  isLow → L,  عادي → H
function _N(ultraLow, low, high) {
    return DevicePerf.isUltraLow ? ultraLow : (DevicePerf.isLowEnd ? low : high);
}

// ── طاقة إطار مُحسَّنة (تُحسب مرة واحدة لكل إطار) ──
let _frameAvgEnergy = 0;
let _frameBassAvg   = 0;
let _frameMidAvg    = 0;
let _frameHighAvg   = 0;

// ── بيانات مُنعَّمة (Smoothed Frequency) ──
let _smoothedFreq  = null;
// [تحسين] الأجهزة الضعيفة جداً تحصل على تنعيم أسرع لتجنب الإحساس بالتأخر
const _SMOOTH_FAST = DevicePerf.isUltraLow ? 0.45 : (DevicePerf.isLowEnd ? 0.55 : 0.72);
const _SMOOTH_SLOW = DevicePerf.isUltraLow ? 0.65 : (DevicePerf.isLowEnd ? 0.75 : 0.88);

// ── كشف البيت (Beat Detection) ──
let _beatAvgEnergy = 0;
let _beatDetected  = false;
let _beatPulse     = 0;
// [تحسين] اضمحلال أسرع على الأجهزة الضعيفة = حسابات أقل
const _BEAT_DECAY  = DevicePerf.isUltraLow ? 0.14 : (DevicePerf.isLowEnd ? 0.10 : 0.05);

// ── حالة مؤثرات تحتاج جسيمات / مصفوفات دائمة ──
let _rainDrops   = null;
let _matrixCols  = null;
let _fwRockets   = [];
let _fwSparks    = [];
let _fwLastLaunch = 0;
let _stars3D     = null;
let _sdDrops     = null;
let _sdSplashes  = null;
let _shockwaves  = null;
let _shockLastTime = 0;

// ── ذاكرة تدرج الشمس ──
let _sunGradCache = null;
let _sunGradLastR = -1;

// ── دوال مساعدة للتوهج — تعمل على جميع الأجهزة ──
// [تحسين] shadowBlur هو أثقل عملية على GPU في الرسم بـ Canvas
// الأجهزة الضعيفة جداً: تعطيل كامل = توفير 30-50% من وقت الرسم
// الأجهزة الضعيفة: تخفيف شديد (حد أقصى 6 بدلاً من 10)
function _glow(ctx, color, blur) {
    if (DevicePerf.isUltraLow) return;   // تعطيل كامل لأجهزة ضعيفة جداً
    if (blur > 0) {
        ctx.shadowColor = color;
        ctx.shadowBlur = DevicePerf.isLowEnd ? Math.min(blur * 0.4, 6) : blur;
    }
}
function _clearGlow(ctx) {
    if (!DevicePerf.isUltraLow) ctx.shadowBlur = 0;
}

// ── دالة إعادة تهيئة حالة المؤثرات ──
function resetVisualizerState() {
    _rainDrops  = null;
    _matrixCols = null;
    _fwRockets  = [];
    _fwSparks   = [];
    _fwLastLaunch = 0;
    _stars3D    = null;
    _sdDrops    = null;
    _sdSplashes = null;
    _shockwaves = null;
    _shockLastTime = 0;
}

// =======================================================
// == المؤثرات البصرية — كل مؤثر يشبه اسمه تماماً ==
// =======================================================
const visualizerRoutines = {

    // ────────────────────────────────────────────────────
    // 1. أعمدة التردد — أعمدة ترتفع مع كل نغمة
    // ────────────────────────────────────────────────────
    'freq-bars': (ctx, data, time, w, h, bFreq) => {
        const N  = _N(40, 64, 128);
        const sp = 2;
        const bw = (w - N * sp) / N;
        const boost = 1 + _beatPulse * 0.2;

        for (let i = 0; i < N; i++) {
            const val = _smoothedFreq ? _smoothedFreq[Math.floor(i * bFreq / N)] : data.freq[Math.floor(i * bFreq / N)];
            const bh  = (val / 255) * h * 0.93 * boost;
            if (bh < 1) { continue; }
            const hue = (i / N * 200 + time * 50) % 360;
            const x   = i * (bw + sp);

            if (!DevicePerf.isLowEnd && bh > 4) {
                const g = ctx.createLinearGradient(x, h, x, h - bh);
                g.addColorStop(0,   `hsl(${hue},90%,28%)`);
                g.addColorStop(0.5, `hsl(${hue},90%,52%)`);
                g.addColorStop(1,   `hsl(${(hue+40)%360},100%,78%)`);
                ctx.fillStyle = g;
                ctx.beginPath();
                ctx.roundRect(x, h - bh, bw, bh, [bw * 0.4, bw * 0.4, 0, 0]);
                ctx.fill();
            } else {
                ctx.fillStyle = `hsl(${hue},90%,55%)`;
                ctx.fillRect(x, h - bh, bw, bh);
            }
        }
    },

    // ────────────────────────────────────────────────────
    // 2. نبض بيضاوي — موجات صوتية متصلة بحدود البيضاوي
    // ────────────────────────────────────────────────────
    'oval-pulse': (ctx, data, time, w, h, bFreq) => {
        const cx    = w / 2, cy = h / 2;
        const isLow = DevicePerf.isLowEnd;
        const hue0  = (time * 42) % 360;

        const RX = Math.min(cx, cy) * 0.86;
        const RY = RX * 0.60;

        const bassSum = (data.freq[0]+data.freq[1]+data.freq[2]+data.freq[3]) * 0.25 / 255;
        const beatScale = 1 + _beatPulse * 0.04 + bassSum * 0.02;
        const pRX = RX * beatScale;
        const pRY = RY * beatScale;

        // ══════════════════════════════════════
        // 1. هالة خلفية ناعمة
        // ══════════════════════════════════════
        if (!isLow) {
            ctx.globalAlpha = 0.07 + bassSum * 0.08 + _beatPulse * 0.05;
            ctx.fillStyle = `hsl(${hue0},100%,50%)`;
            ctx.beginPath();
            ctx.ellipse(cx, cy, pRX * 1.10, pRY * 1.10, 0, 0, Math.PI * 2);
            ctx.fill();
            ctx.globalAlpha = 1;
        }

        // ══════════════════════════════════════
        // 2. خطوط الموجة على شكل X — خطّان قطريّان يتقاطعان في المركز
        // ══════════════════════════════════════

        // مساعد: إسقاط نقطة خارج البيضاوي إلى حدوده (يمنع الخروج عن الإطار)
        const clampToEllipse = (px, py) => {
            const dx = px - cx, dy = py - cy;
            const ratio = (dx * dx) / (pRX * pRX) + (dy * dy) / (pRY * pRY);
            if (ratio <= 1) return [px, py];
            const t = 1 / Math.sqrt(ratio);
            return [cx + dx * t, cy + dy * t];
        };

        const xAngles = [Math.PI / 4, -Math.PI / 4];

        // متوسط الطاقة الكلي للمشهد — يُستخدم كمقياس رئيسي لكلا الخطين
        const totalBins = Math.min(bFreq, (_smoothedFreq ? _smoothedFreq.length : data.freq.length));
        let globalEnergy = 0;
        for (let fi = 0; fi < totalBins; fi++) {
            globalEnergy += (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
        }
        globalEnergy /= totalBins;

        ctx.lineCap  = 'round';
        ctx.lineJoin = 'round';

        for (let li = 0; li < 2; li++) {
            const theta = xAngles[li];
            const cosT  = Math.cos(theta);
            const sinT  = Math.sin(theta);

            // طول نصف الخط من المركز حتى حافة البيضاوي
            const r_theta = 1 / Math.sqrt(
                (cosT * cosT) / (pRX * pRX) + (sinT * sinT) / (pRY * pRY)
            );

            // كلا الخطين يمسحان الطيف الكامل (0 → bFreq)
            // لكن بإزاحة طور مختلفة لكل خط حتى يبدوا مستقلَّين
            const phaseShift = li * Math.PI;           // إزاحة 180° بين الخطين
            const timeSpeed  = 7 + li * 2.8;           // سرعة حركة الموجة مختلفة

            // طاقة الخط — مزيج من الطيف الكامل لضمان دائمية الحركة
            const bandE = Math.pow(globalEnergy, 1.3) * (1 + _beatPulse * 0.4);

            const hue = (hue0 + li * 160 + 30) % 360;
            // سعة الموجة القصوى: محدودة بـ 20% من نصف القطر لتبقى داخل البيضاوي
            const maxAmp = r_theta * 0.20 * (0.3 + bandE * 4) * (1 + _beatPulse * 0.30);

            ctx.globalAlpha = 0.45 + Math.min(bandE, 1) * 0.55;
            ctx.strokeStyle = `hsl(${hue},100%,${48 + Math.min(bandE,1) * 32}%)`;
            ctx.lineWidth   = isLow ? (1.4 + bandE * 2.5) : (1.8 + bandE * 3.5);
            _glow(ctx, `hsl(${hue},100%,70%)`,
                  isLow ? bandE * 8 : bandE * 16 + _beatPulse * 6);

            const steps = isLow ? 64 : 120;
            ctx.beginPath();
            for (let s = 0; s <= steps; s++) {
                const st     = s / steps;
                const tAlong = (st - 0.5) * 2;   // -1 → +1

                // نقطة أساسية على محور الخط
                const baseX = cx + tAlong * r_theta * cosT;
                const baseY = cy + tAlong * r_theta * sinT;

                // ══ الإصلاح الجذري: موجة مركّبة من هارمونيكَين ══
                // globalEnergy يضمن تحرّك الخط كاملاً من طرف لطرف — بدون energy محلية
                // الهارمونيكَان يعطيان شكلاً عضوياً غير منتظم ومتحركاً بالكامل
                const wave1 = Math.sin(st * Math.PI * 4 + time * timeSpeed        + phaseShift);
                const wave2 = Math.sin(st * Math.PI * 7 + time * timeSpeed * 1.35 + phaseShift + 1.2);
                // تنويع بسيط: النصف الأول يستجيب للباص، الثاني للمنتصف
                const localBoost = 1 + (st < 0.5 ? bassSum * 0.8 : _frameMidAvg * 0.8);
                const sig = (wave1 * 0.65 + wave2 * 0.35) * globalEnergy * localBoost;

                // تليين الحواف: الموجة تصفر لتلتحم بالبيضاوي
                const fade = Math.min(Math.min(st, 1 - st) / 0.07, 1);

                // إزاحة عمودياً على اتجاه الخط
                let px = baseX + sig * maxAmp * fade * (-sinT);
                let py = baseY + sig * maxAmp * fade * ( cosT);

                // ضمان البقاء داخل البيضاوي
                [px, py] = clampToEllipse(px, py);

                s === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
            }
            ctx.stroke();
        }
        _clearGlow(ctx);

        // ══════════════════════════════════════
        // 3. حلقة نبض داخلية عند كل بيت
        // ══════════════════════════════════════
        if (!isLow && _beatPulse > 0.15) {
            const pr = 0.48 + _beatPulse * 0.14;
            ctx.globalAlpha = _beatPulse * 0.38;
            ctx.strokeStyle = `hsl(${hue0},100%,82%)`;
            ctx.lineWidth   = 1.2 + _beatPulse * 2.5;
            _glow(ctx, `hsl(${hue0},100%,80%)`, 12 * _beatPulse);
            ctx.beginPath();
            ctx.ellipse(cx, cy, pRX * pr, pRY * pr, 0, 0, Math.PI * 2);
            ctx.stroke();
            _clearGlow(ctx);
        }

        // ══════════════════════════════════════
        // 4. الإطار البيضاوي الرئيسي
        // ══════════════════════════════════════
        // طبقة توهج خارجي
        if (!isLow) {
            ctx.globalAlpha = 0.22 + _beatPulse * 0.10 + bassSum * 0.12;
            ctx.lineWidth   = 9 + _beatPulse * 7;
            ctx.strokeStyle = `hsl(${hue0},100%,50%)`;
            _glow(ctx, `hsl(${hue0},100%,58%)`, 18 + _beatPulse * 12);
            ctx.beginPath();
            ctx.ellipse(cx, cy, pRX, pRY, 0, 0, Math.PI * 2);
            ctx.stroke();
            _clearGlow(ctx);
        }

        // الخط الرئيسي متعدد الألوان
        ctx.globalAlpha = 0.90 + _beatPulse * 0.10;
        ctx.lineWidth   = isLow ? (2.5 + _beatPulse * 3.5) : (3 + _beatPulse * 4.5 + bassSum * 2);
        const bGrad = ctx.createLinearGradient(cx - pRX, cy, cx + pRX, cy);
        bGrad.addColorStop(0,    `hsl(${hue0},100%,60%)`);
        bGrad.addColorStop(0.33, `hsl(${(hue0+90)%360},100%,70%)`);
        bGrad.addColorStop(0.67, `hsl(${(hue0+180)%360},100%,70%)`);
        bGrad.addColorStop(1,    `hsl(${(hue0+270)%360},100%,60%)`);
        ctx.strokeStyle = bGrad;
        _glow(ctx, `hsl(${hue0},100%,70%)`, 7 + _beatPulse * 11 + bassSum * 7);
        ctx.beginPath();
        ctx.ellipse(cx, cy, pRX, pRY, 0, 0, Math.PI * 2);
        ctx.stroke();
        _clearGlow(ctx);

        // ══════════════════════════════════════
        // 5. نقاط متوهجة على محيط البيضاوي
        // ══════════════════════════════════════
        if (!isLow) {
            const dotCount = 28;
            for (let i = 0; i < dotCount; i++) {
                const fi  = Math.floor(i * bFreq / dotCount);
                const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const v   = Math.pow(vs, 1.8);
                if (v < 0.32) continue;
                const ang  = (i / dotCount) * Math.PI * 2 - Math.PI / 2;
                const dotX = cx + Math.cos(ang) * pRX;
                const dotY = cy + Math.sin(ang) * pRY;
                const hue  = (hue0 + (i / dotCount) * 360) % 360;
                ctx.globalAlpha = (v - 0.32) * 1.5;
                _glow(ctx, `hsl(${hue},100%,90%)`, 7 + v * 8);
                ctx.fillStyle = `hsl(${hue},100%,95%)`;
                ctx.beginPath();
                ctx.arc(dotX, dotY, 1.5 + v * 4, 0, Math.PI * 2);
                ctx.fill();
            }
            _clearGlow(ctx);
        }

        ctx.globalAlpha = 1; ctx.lineCap = 'butt'; ctx.lineJoin = 'miter';
    },

    // ────────────────────────────────────────────────────
    // 3. موجة الصوت — شكل الموجة المركزي مع تعبئة
    // ────────────────────────────────────────────────────
    'time-wave': (ctx, data, time, w, h, bFreq, bTime) => {
        const cy = h / 2, step = DevicePerf.isLowEnd ? 3 : 1;
        const sw = w * step / bTime;
        const hue = (time * 40) % 360;

        ctx.globalAlpha = 0.22;
        ctx.fillStyle = `hsl(${hue},90%,50%)`;
        ctx.beginPath(); ctx.moveTo(0, cy);
        let x = 0;
        for (let i = 0; i < bTime; i += step) {
            ctx.lineTo(x, cy + (data.time[i] / 128.0 - 1) * cy * 0.9); x += sw;
        }
        ctx.lineTo(w, cy); ctx.closePath(); ctx.fill();
        ctx.globalAlpha = 1;

        ctx.lineWidth = DevicePerf.isLowEnd ? 2 : 2.5;
        _glow(ctx, `hsl(${hue},100%,60%)`, 8);
        ctx.beginPath(); x = 0;
        for (let i = 0; i < bTime; i += step) {
            i === 0 ? ctx.moveTo(x, cy + (data.time[i]/128.0-1)*cy*0.9)
                    : ctx.lineTo(x, cy + (data.time[i]/128.0-1)*cy*0.9);
            x += sw;
        }
        ctx.stroke(); _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 4. انعكاس مرآوي — أعمدة تتمدد للأعلى والأسفل كالمرآة
    // ────────────────────────────────────────────────────
    'mirror-bars': (ctx, data, time, w, h, bFreq) => {
        const N = _N(30, 48, 84);
        const bw = (w / N) - 1.5, cy = h / 2;

        for (let i = 0; i < N; i++) {
            const val = (_smoothedFreq ? _smoothedFreq[Math.floor(i*bFreq/N)] : data.freq[Math.floor(i*bFreq/N)]) / 255;
            const bh = val * cy * (1 + _beatPulse * 0.18);
            const x = i * (bw + 1.5), hue = (i / N * 360 + time * 25) % 360;

            if (!DevicePerf.isLowEnd && bh > 3) {
                const g = ctx.createLinearGradient(x, cy - bh, x, cy + bh);
                g.addColorStop(0,   `hsla(${hue},100%,78%,0.9)`);
                g.addColorStop(0.5, `hsla(${hue},100%,44%,1)`);
                g.addColorStop(1,   `hsla(${hue},100%,78%,0.9)`);
                ctx.fillStyle = g;
            } else {
                ctx.fillStyle = `hsl(${hue},100%,55%)`;
            }
            ctx.fillRect(x, cy - bh, bw, bh * 2);
        }
        _glow(ctx, `hsl(${(time*40)%360},100%,80%)`, 5);
        _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 5. جزيئات متناثرة — جسيمات تتطاير عشوائياً
    // ────────────────────────────────────────────────────
    'scatter': (ctx, data, time, w, h, bFreq) => {
        const N = _N(36, 60, 120);
        for (let i = 0; i < N; i++) {
            const v  = (_smoothedFreq ? _smoothedFreq[Math.floor(i*bFreq/N)] : data.freq[Math.floor(i*bFreq/N)]) / 255;
            const t  = time * (0.4 + i * 0.003);
            const oR = (0.12 + v * 0.78) * Math.min(w, h) * 0.44;
            const ang = (i / N) * Math.PI * 2 + t;
            const x  = w/2 + Math.cos(ang)*oR + Math.sin(t*1.3+i)*oR*0.28;
            const y  = h/2 + Math.sin(ang)*oR*0.6 + Math.cos(t+i*0.5)*oR*0.28;
            const hue = (i/N*360 + time*60) % 360;

            ctx.globalAlpha = 0.4 + v * 0.6;
            _glow(ctx, `hsl(${hue},100%,60%)`, DevicePerf.isLowEnd ? 0 : 5*v);
            ctx.fillStyle = `hsl(${hue},100%,60%)`;
            ctx.beginPath(); ctx.arc(x%w, y%h, 2+v*8, 0, Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 6. أعمدة معكوسة — شكل V متماثل ينمو من المركز
    // ────────────────────────────────────────────────────
    'v-bars': (ctx, data, time, w, h, bFreq) => {
        const N = DevicePerf.isLowEnd ? 22 : 38;
        const bw = (w / 2) / N - 1, cx = w / 2;

        for (let i = 0; i < N; i++) {
            const v = (_smoothedFreq ? _smoothedFreq[Math.floor(i*bFreq/N)] : data.freq[Math.floor(i*bFreq/N)]) / 255;
            const bh = v * h * 0.9 * (1 + _beatPulse * 0.15);
            const hue = (i/N*240 + time*35) % 360;

            if (!DevicePerf.isLowEnd && bh > 4) {
                const g = ctx.createLinearGradient(0, h, 0, h - bh);
                g.addColorStop(0, `hsla(${hue},100%,28%,0.8)`);
                g.addColorStop(1, `hsla(${(hue+30)%360},100%,74%,1)`);
                ctx.fillStyle = g;
            } else { ctx.fillStyle = `hsl(${hue},100%,55%)`; }

            ctx.fillRect(cx-(i+1)*(bw+1), h-bh, bw, bh);
            ctx.fillRect(cx+i*(bw+1), h-bh, bw, bh);
        }
    },

    // ────────────────────────────────────────────────────
    // 7. مصفوفة نقاط — شاشة LED تضيء مع الموسيقى
    // ────────────────────────────────────────────────────
    'dot-matrix': (ctx, data, time, w, h, bFreq) => {
        const cols = DevicePerf.isLowEnd ? 13 : 21;
        const rows = DevicePerf.isLowEnd ? 8  : 13;
        const cw = w/cols, ch = h/rows, maxR = Math.min(cw,ch)*0.42;

        for (let r = 0; r < rows; r++) {
            for (let c = 0; c < cols; c++) {
                const idx = Math.floor((r*cols+c)/(cols*rows)*bFreq);
                const v = data.freq[idx] / 255;
                const x = (c+0.5)*cw, y = (r+0.5)*ch;
                const hue = (c*15+r*20+time*30) % 360;

                ctx.globalAlpha = 0.12 + v * 0.12;
                ctx.fillStyle = `hsl(${hue},100%,50%)`;
                ctx.beginPath(); ctx.arc(x, y, maxR, 0, Math.PI*2); ctx.fill();

                if (v > 0.04) {
                    ctx.globalAlpha = 0.5 + v * 0.5;
                    _glow(ctx, `hsl(${hue},100%,60%)`, DevicePerf.isLowEnd ? 0 : 8*v);
                    ctx.fillStyle = `hsl(${hue},100%,${55+v*25}%)`;
                    ctx.beginPath(); ctx.arc(x, y, maxR*v, 0, Math.PI*2); ctx.fill();
                    _clearGlow(ctx);
                }
            }
        }
        ctx.globalAlpha = 1;
    },

    // ────────────────────────────────────────────────────
    // 8. حلقة الطاقة — حلقة بلازما تنبض بالطاقة
    // ────────────────────────────────────────────────────
    'energy-ring': (ctx, data, time, w, h, bFreq) => {
        const cx = w / 2, cy = h / 2, R = Math.min(cx, cy);
        const isLow = DevicePerf.isLowEnd;
        const hue0  = (time * 55) % 360;

        // ── حجم الحلقة يتمدد مع الباص ──
        const bass   = _frameBassAvg + _beatPulse * 0.35;
        const ringR  = R * (0.40 + bass * 0.10);

        // ── 1. هالة خارجية (aurora glow) تتنفس مع الإيقاع ──
        if (!isLow) {
            const glowR = ringR * (1.55 + _beatPulse * 0.25);
            const ag = ctx.createRadialGradient(cx, cy, ringR * 0.7, cx, cy, glowR);
            ag.addColorStop(0,   `hsla(${hue0},100%,65%,${0.22 + _beatPulse * 0.18})`);
            ag.addColorStop(0.5, `hsla(${(hue0+80)%360},100%,55%,${0.07 + _frameBassAvg * 0.10})`);
            ag.addColorStop(1,   `hsla(${hue0},100%,45%,0)`);
            ctx.fillStyle = ag; ctx.globalAlpha = 1;
            ctx.beginPath(); ctx.arc(cx, cy, glowR, 0, Math.PI * 2); ctx.fill();
        }

        // ── 2. نواة بلازما مركزية ──
        const coreR = R * (0.12 + _frameBassAvg * 0.14 + _beatPulse * 0.07);
        const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR * 3.2);
        cg.addColorStop(0,   `hsla(${hue0},100%,98%,${0.80 + _beatPulse * 0.20})`);
        cg.addColorStop(0.3, `hsla(${hue0},100%,72%,${0.50 + _frameBassAvg * 0.30})`);
        cg.addColorStop(0.7, `hsla(${(hue0+60)%360},100%,52%,0.15)`);
        cg.addColorStop(1,   `hsla(${hue0},100%,40%,0)`);
        _glow(ctx, `hsl(${hue0},100%,85%)`, 20 + _beatPulse * 22);
        ctx.fillStyle = cg; ctx.globalAlpha = 1;
        ctx.beginPath(); ctx.arc(cx, cy, coreR * 3.2, 0, Math.PI * 2); ctx.fill();
        _clearGlow(ctx);

        // ── 3. حلقات corona متعددة (طبقات توهج ناعمة) ──
        if (!isLow) {
            [[ringR * 0.97, 18, 0.07], [ringR, 9, 0.16], [ringR * 1.03, 4, 0.28]].forEach(([r, lw, a]) => {
                ctx.globalAlpha = a + _beatPulse * 0.10;
                ctx.lineWidth   = lw;
                ctx.strokeStyle = `hsl(${hue0},100%,70%)`;
                _glow(ctx, `hsl(${hue0},100%,78%)`, lw * 1.8);
                ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
            });
            ctx.globalAlpha = 1; _clearGlow(ctx);
        }

        // ── 4. أقواس مقسّمة تنبض لكل تردد ──
        const segs  = _N(32, 48, 96);
        const gap   = 0.028;                                  // فراغ بين القوسين (راديان)
        const arcW  = (Math.PI * 2 / segs) - gap;
        ctx.lineCap = 'round';

        for (let i = 0; i < segs; i++) {
            const fi  = Math.floor(i * bFreq / segs);
            const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const vr  = data.freq[fi] / 255;
            const v   = vs * 0.55 + vr * 0.45;
            if (v < 0.03) continue;

            const angC = (i / segs) * Math.PI * 2 - Math.PI / 2;
            const hue  = (hue0 + (i / segs) * 300) % 360;
            const lum  = 50 + v * 38;
            const ext  = v * R * 0.30 * (1 + _beatPulse * 0.45); // مقدار تمدد القوس للخارج
            const base = ringR - 2;
            const tip  = ringR + ext;
            const lw   = isLow ? (2.5 + v * 5) : (3 + v * 8);

            ctx.globalAlpha = 0.50 + v * 0.50;
            ctx.lineWidth   = lw;
            _glow(ctx, `hsl(${hue},100%,${lum}%)`, isLow ? v * 8 : v * 22 + _beatPulse * 7);

            if (!isLow && v > 0.35) {
                // تدرج من قاعدة القوس إلى طرفه
                const gx1 = cx + Math.cos(angC) * base;
                const gy1 = cy + Math.sin(angC) * base;
                const gx2 = cx + Math.cos(angC) * tip;
                const gy2 = cy + Math.sin(angC) * tip;
                const lg  = ctx.createLinearGradient(gx1, gy1, gx2, gy2);
                lg.addColorStop(0,   `hsla(${hue},100%,${lum}%,0.65)`);
                lg.addColorStop(0.55,`hsla(${hue},100%,${lum+16}%,0.90)`);
                lg.addColorStop(1,   `hsla(${(hue+50)%360},100%,93%,1)`);
                ctx.strokeStyle = lg;
            } else {
                ctx.strokeStyle = `hsl(${hue},100%,${lum}%)`;
            }

            ctx.beginPath();
            ctx.arc(cx, cy, (base + tip) / 2, angC - arcW / 2, angC + arcW / 2);
            ctx.stroke();

            // نقطة توهج عند طرف القوس للقمم العالية
            if (!isLow && v > 0.52) {
                ctx.globalAlpha = (v - 0.52) * 2.1;
                _glow(ctx, `hsl(${hue},100%,94%)`, 14 + v * 8);
                ctx.fillStyle = `hsl(${hue},100%,97%)`;
                ctx.beginPath();
                ctx.arc(cx + Math.cos(angC) * tip, cy + Math.sin(angC) * tip,
                        2 + v * 5, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        _clearGlow(ctx); ctx.lineCap = 'butt';

        // ── 5. الحلقة الرئيسية المضيئة ──
        ctx.globalAlpha = 0.72 + _beatPulse * 0.28;
        ctx.lineWidth   = 2.8 + _beatPulse * 3.5;
        ctx.strokeStyle = `hsl(${hue0},100%,84%)`;
        _glow(ctx, `hsl(${hue0},100%,88%)`, isLow ? 10 : 28 + _beatPulse * 14);
        ctx.beginPath(); ctx.arc(cx, cy, ringR, 0, Math.PI * 2); ctx.stroke();
        _clearGlow(ctx);

        // ── 6. جسيمات دوّارة على محيط الحلقة ──
        if (!isLow) {
            const pts = 6;
            for (let p = 0; p < pts; p++) {
                const ang  = (p / pts) * Math.PI * 2 + time * 0.9;
                const fi   = Math.floor(p * bFreq / pts);
                const v    = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const hue  = (hue0 + p * 60) % 360;
                const dist = ringR * (1.0 + v * 0.18 + _beatPulse * 0.08);
                ctx.globalAlpha = 0.60 + v * 0.40;
                _glow(ctx, `hsl(${hue},100%,88%)`, 10 + v * 14);
                ctx.fillStyle = `hsl(${hue},100%,94%)`;
                ctx.beginPath();
                ctx.arc(cx + Math.cos(ang) * dist, cy + Math.sin(ang) * dist,
                        2.5 + v * 5, 0, Math.PI * 2);
                ctx.fill();
            }
            _clearGlow(ctx);
        }

        // ── 7. موجة صدمة انفجارية عند كل بيت قوي ──
        if (_beatPulse > 0.35) {
            for (let s = 0; s < (isLow ? 1 : 3); s++) {
                const sr = ringR * (1.10 + s * 0.16 + (1 - _beatPulse) * 0.28);
                ctx.globalAlpha = _beatPulse * (0.55 - s * 0.15);
                ctx.lineWidth   = (4 - s * 0.8) * _beatPulse;
                ctx.strokeStyle = `hsl(${(hue0 + s * 50) % 360},100%,90%)`;
                _glow(ctx, `hsl(${hue0},100%,82%)`, 16 * _beatPulse);
                ctx.beginPath(); ctx.arc(cx, cy, sr, 0, Math.PI * 2); ctx.stroke();
            }
            _clearGlow(ctx);
        }

        ctx.globalAlpha = 1;
    },

    // ────────────────────────────────────────────────────
    // 9. لولب مزدوج — حلزون DNA بعمق ثلاثي وجسور متوهجة
    // ────────────────────────────────────────────────────
    'helix': (ctx, data, time, w, h, bFreq) => {
        const cx = w/2, cy = h/2;
        const isLow = DevicePerf.isLowEnd;
        const rMax  = Math.min(cx, cy) * 0.62;
        const turns = 3;
        const N     = _N(36, 60, 120);
        const speed = 0.6 + _frameAvgEnergy * 0.5;
        const hue1  = (time * 42) % 360;
        const hue2  = (hue1 + 180) % 360;

        // ── حساب نقاط الشريطين ──
        const strandA = new Array(N);
        const strandB = new Array(N);
        for (let i = 0; i < N; i++) {
            const t   = i / (N - 1);
            const fi  = Math.floor(t * bFreq);
            const v   = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const ang = t * Math.PI * 2 * turns + time * speed;
            const y   = cy - rMax * 0.88 + t * rMax * 1.76;
            const r   = rMax * 0.36 * (0.45 + v * 0.8);
            const dep = (Math.sin(ang) + 1) / 2;   // 0..1 عمق A
            strandA[i] = { x: cx + Math.cos(ang)*r,           y, v, dep, hue: (hue1+t*30)%360 };
            strandB[i] = { x: cx + Math.cos(ang+Math.PI)*r,   y, v, dep: 1-dep, hue: (hue2+t*30)%360 };
        }

        // ── الجسور الرابطة ──
        const bStep = isLow ? 12 : 7;
        for (let i = 0; i < N; i += bStep) {
            const a = strandA[i], b = strandB[i];
            if (a.v < 0.1) continue;
            const bHue = ((a.hue + b.hue) / 2) % 360;
            ctx.globalAlpha = 0.3 + a.v * 0.5;
            ctx.strokeStyle = `hsl(${bHue},90%,68%)`;
            ctx.lineWidth   = 0.8 + a.v * 2;
            _glow(ctx, `hsl(${bHue},100%,70%)`, a.v * 7);
            ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
            if (!isLow && a.v > 0.5) {
                ctx.globalAlpha = a.v * 0.65;
                ctx.fillStyle = `hsl(${bHue},100%,90%)`;
                ctx.beginPath(); ctx.arc((a.x+b.x)/2,(a.y+b.y)/2, 1.5+a.v*2, 0, Math.PI*2); ctx.fill();
            }
        }
        _clearGlow(ctx);

        // ── رسم كل شريط كـ path واحد بلون موحَّد ──
        [[strandA, hue1], [strandB, hue2]].forEach(([strand, baseHue]) => {
            // خط رئيسي واحد
            ctx.lineWidth   = isLow ? 2 : 2.8;
            ctx.strokeStyle = `hsl(${baseHue},100%,62%)`;
            ctx.globalAlpha = 0.9;
            _glow(ctx, `hsl(${baseHue},100%,70%)`, isLow ? 4 : 9);
            ctx.beginPath();
            strand.forEach((pt, i) => {
                i === 0 ? ctx.moveTo(pt.x, pt.y) : ctx.lineTo(pt.x, pt.y);
            });
            ctx.stroke();
            _clearGlow(ctx);

            // نقاط عقد فقط عند الترددات العالية
            const dotStep = isLow ? 8 : 4;
            for (let i = 0; i < N; i += dotStep) {
                const pt = strand[i];
                if (pt.v < 0.25) continue;
                ctx.globalAlpha = 0.55 + pt.dep * 0.45;
                _glow(ctx, `hsl(${pt.hue},100%,75%)`, pt.v * 10 * pt.dep);
                ctx.fillStyle = `hsl(${pt.hue},100%,${62 + pt.dep*22}%)`;
                ctx.beginPath();
                ctx.arc(pt.x, pt.y, (isLow ? 1.5 : 2) + pt.v * 4 * pt.dep, 0, Math.PI*2);
                ctx.fill();
            }
            _clearGlow(ctx);
        });

        ctx.globalAlpha = 1;
    },

    // ────────────────────────────────────────────────────
    // 10. نفق فضائي — نفق دائري بمنظور ثلاثي حقيقي
    // ────────────────────────────────────────────────────
    'tunnel': (ctx, data, time, w, h, bFreq) => {
        const cx = w/2, cy = h/2;
        const isLow = DevicePerf.isLowEnd;
        const maxR  = Math.max(w, h) * 0.72;
        const rings = _N(6, 10, 20);
        const spd   = 0.18 + _frameAvgEnergy * 0.35 + _beatPulse * 0.12;
        const hue0  = (time * 32) % 360;

        // ── خطوط منظور تشع من المركز ──
        if (!isLow) {
            const lines = 12;
            ctx.lineWidth = 0.5;
            for (let l = 0; l < lines; l++) {
                const ang    = (l / lines) * Math.PI * 2 + time * 0.05;
                const fi     = Math.floor(l * bFreq / lines);
                const v      = data.freq[fi] / 255;
                const hue    = (hue0 + l * 30) % 360;
                ctx.globalAlpha = 0.12 + v * 0.2;
                ctx.strokeStyle = `hsl(${hue},100%,65%)`;
                ctx.beginPath();
                ctx.moveTo(cx, cy);
                ctx.lineTo(cx + Math.cos(ang) * maxR * 1.2,
                           cy + Math.sin(ang) * maxR * 1.2);
                ctx.stroke();
            }
            ctx.globalAlpha = 1;
        }

        // ── حلقات النفق من الأبعد للأقرب ──
        for (let i = rings; i >= 1; i--) {
            const phase  = ((i / rings) + time * spd) % 1;
            // منظور: الحلقات القريبة أكبر وأكثر شفافية
            const r      = phase * maxR;
            const fi     = Math.floor((i / rings) * bFreq);
            const v      = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const hue    = (hue0 + phase * 120 + i * 18) % 360;
            const alpha  = (1 - phase) * (0.35 + v * 0.65);

            if (r < 2) continue;

            ctx.globalAlpha = Math.min(alpha, 1);
            _glow(ctx, `hsl(${hue},100%,65%)`, isLow ? 2 : 14 * (1-phase));

            // الحلقة الأساسية
            ctx.strokeStyle = `hsl(${hue},100%,${48 + v*30 + (1-phase)*12}%)`;
            ctx.lineWidth   = (1.5 + v*4) * (1 - phase * 0.6);
            ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI*2); ctx.stroke();

            // نقاط موزعة على محيط الحلقة — تضيف التفاصيل
            if (!isLow && v > 0.3 && (i % 2 === 0)) {
                const dots = Math.floor(4 + v * 8);
                for (let d = 0; d < dots; d++) {
                    const dAng = (d / dots) * Math.PI * 2 + time * 0.3 + i;
                    ctx.globalAlpha = alpha * v * 0.7;
                    ctx.fillStyle = `hsl(${(hue+30)%360},100%,85%)`;
                    ctx.beginPath();
                    ctx.arc(cx + Math.cos(dAng) * r,
                            cy + Math.sin(dAng) * r,
                            1 + v * 2.5, 0, Math.PI*2);
                    ctx.fill();
                }
            }
        }
        _clearGlow(ctx);

        // ── نقطة الانهيار في المركز — أكثر عنصر درامياً ──
        const collapseR  = 4 + _beatPulse * 14 + _frameBassAvg * 10;
        const collapseHue = (hue0 + 60) % 360;
        const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, collapseR * 3);
        cg.addColorStop(0,   `hsla(${collapseHue},100%,98%,${0.7 + _beatPulse*0.3})`);
        cg.addColorStop(0.3, `hsla(${collapseHue},100%,70%,${0.4 + _beatPulse*0.3})`);
        cg.addColorStop(1,   `hsla(${collapseHue},100%,50%,0)`);
        ctx.fillStyle = cg;
        ctx.globalAlpha = 1;
        _glow(ctx, `hsl(${collapseHue},100%,90%)`, 20 + _beatPulse*20);
        ctx.beginPath(); ctx.arc(cx, cy, collapseR * 3, 0, Math.PI*2); ctx.fill();
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 11. قطرات المطر — قطرات تسقط من الأعلى بجاذبية
    // ────────────────────────────────────────────────────
    'rain-drops': (ctx, data, time, w, h, bFreq) => {
        const N = _N(18, 30, 60);
        const spd = 1 + _frameAvgEnergy*3 + _beatPulse*4;

        if (!_rainDrops || _rainDrops.length !== N) {
            _rainDrops = Array.from({length:N}, () => ({
                x:   Math.random()*w,
                y:   Math.random()*h,
                len: 12 + Math.random()*32,
                spd: 2 + Math.random()*4,
                col: Math.floor(Math.random()*bFreq),
            }));
        }

        for (let i = 0; i < N; i++) {
            const d = _rainDrops[i];
            const v = data.freq[Math.min(d.col, bFreq-1)] / 255;
            if (v < 0.05) { d.y+=d.spd*spd; if(d.y>h+d.len) d.y=-d.len; continue; }

            const hue = (190 + v*100 + time*20) % 360;
            const len = (d.len + v*40)*(1+_beatPulse*0.25);
            const g = ctx.createLinearGradient(d.x, d.y-len, d.x, d.y);
            g.addColorStop(0, `hsla(${hue},90%,60%,0)`);
            g.addColorStop(1, `hsla(${hue},90%,78%,${0.5+v*0.5})`);
            ctx.strokeStyle = g; ctx.lineWidth = 1.5+v*2;
            ctx.beginPath(); ctx.moveTo(d.x, d.y-len); ctx.lineTo(d.x, d.y); ctx.stroke();

            _glow(ctx, `hsl(${hue},100%,80%)`, DevicePerf.isLowEnd ? 0 : 6);
            ctx.fillStyle = `hsl(${hue},100%,82%)`; ctx.globalAlpha = 0.7+v*0.3;
            ctx.beginPath(); ctx.arc(d.x, d.y, 2+v*3, 0, Math.PI*2); ctx.fill();
            ctx.globalAlpha = 1; _clearGlow(ctx);

            d.y += d.spd*spd;
            if (d.y > h+len) { d.y=-len; d.x=Math.random()*w; }
        }
    },

    // ────────────────────────────────────────────────────
    // 12. كرة متوهجة — كرة ثلاثية الأبعاد بمدارات ونبض حي
    // ────────────────────────────────────────────────────
    // ────────────────────────────────────────────────────
    // 12. كرة متوهجة — كرة بلازما ثلاثية بسطح حي ومدارات متوهجة
    // ────────────────────────────────────────────────────
    'sphere': (ctx, data, time, w, h, bFreq) => {
        const cx = w / 2, cy = h / 2;
        const isLow  = DevicePerf.isLowEnd;
        const R      = Math.min(cx, cy) * (0.38 + _frameBassAvg * 0.18 + _beatPulse * 0.07);
        const hue0   = (time * 38) % 360;
        const spinY  = time * 0.22;   // دوران حول المحور العمودي
        const tiltX  = 0.30;          // إمالة المحور الأفقي (ثابتة – تمنح العمق)

        // ── مُساعد: تحويل نقطة ثلاثية الأبعاد على سطح الكرة → شاشة ──
        // theta = خط طول (0..2π), phi = خط عرض (0..π)
        const project = (theta, phi) => {
            const x3 =  Math.sin(phi) * Math.cos(theta);
            const y3 = -Math.cos(phi);
            const z3 =  Math.sin(phi) * Math.sin(theta);
            // تدوير حول X بزاوية tiltX
            const yr = y3 * Math.cos(tiltX) - z3 * Math.sin(tiltX);
            const zr = y3 * Math.sin(tiltX) + z3 * Math.cos(tiltX);
            return { sx: cx + x3 * R, sy: cy + yr * R, depth: (zr + 1) / 2 };
        };

        // ════════════════════════════════════════════════
        // 1. غلاف جوي (atmosphere) — طبقتان ملونتان
        // ════════════════════════════════════════════════
        if (!isLow) {
            // الطبقة الخارجية
            const atmR = R * (1.55 + _beatPulse * 0.22);
            const ag = ctx.createRadialGradient(cx, cy, R * 0.82, cx, cy, atmR);
            ag.addColorStop(0,   `hsla(${hue0},100%,62%,${0.28 + _beatPulse * 0.22})`);
            ag.addColorStop(0.4, `hsla(${(hue0+70)%360},100%,52%,${0.10 + _frameBassAvg * 0.14})`);
            ag.addColorStop(1,   `hsla(${hue0},100%,44%,0)`);
            ctx.fillStyle = ag; ctx.globalAlpha = 1;
            ctx.beginPath(); ctx.arc(cx, cy, atmR, 0, Math.PI * 2); ctx.fill();

            // الطبقة الداخلية — أشد إضاءةً عند البيت
            const innR = R * (1.20 + _beatPulse * 0.14);
            const ig = ctx.createRadialGradient(cx, cy, R * 0.88, cx, cy, innR);
            ig.addColorStop(0,   `hsla(${(hue0+120)%360},100%,70%,${0.18 + _beatPulse * 0.28})`);
            ig.addColorStop(1,   `hsla(${(hue0+120)%360},100%,50%,0)`);
            ctx.fillStyle = ig; ctx.globalAlpha = 1;
            ctx.beginPath(); ctx.arc(cx, cy, innR, 0, Math.PI * 2); ctx.fill();
        }

        // ════════════════════════════════════════════════
        // 2. جسم الكرة — تدرج كروي بمحاكاة إضاءة حقيقية
        // ════════════════════════════════════════════════
        // نقطة الضوء الوهمية أعلى-يسار تعطي إحساسًا بالكرة الصلبة
        const lightX = cx - R * 0.32;
        const lightY = cy - R * 0.32;
        const bg = ctx.createRadialGradient(lightX, lightY, 0, cx, cy, R * 1.05);
        bg.addColorStop(0,   `hsla(${(hue0+20)%360},90%,82%,${0.60 + _beatPulse * 0.25})`);
        bg.addColorStop(0.35,`hsla(${hue0},100%,58%,${0.72 + _frameBassAvg * 0.20})`);
        bg.addColorStop(0.72,`hsla(${(hue0+160)%360},100%,36%,0.85)`);
        bg.addColorStop(1,   `hsla(${(hue0+200)%360},100%,18%,0.92)`);
        _glow(ctx, `hsl(${hue0},100%,68%)`, isLow ? 10 : 22 + _beatPulse * 18);
        ctx.fillStyle = bg; ctx.globalAlpha = 1;
        ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();
        _clearGlow(ctx);

        // ════════════════════════════════════════════════
        // 3. خطوط الطول — تدور ويتلاشى ما يواجه الخلف
        // ════════════════════════════════════════════════
        const lonCount = _N(6, 9, 16);
        const lonSegs  = _N(14, 22, 40);

        // نبني كل خط كـ path، نرتّبها من الأبعد للأقرب (painter's algorithm)
        const lonData = [];
        for (let j = 0; j < lonCount; j++) {
            const theta = (j / lonCount) * Math.PI * 2 + spinY;
            const fi    = Math.floor(j * bFreq / lonCount);
            const vs    = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const vr    = data.freq[fi] / 255;
            const v     = vs * 0.6 + vr * 0.4;
            // عمق خط الطول بناءً على موضعه الزاوي
            const depthJ = (Math.cos(theta - spinY) + 1) / 2;
            lonData.push({ j, theta, v, depthJ });
        }
        lonData.sort((a, b) => a.depthJ - b.depthJ);  // الأبعد أولاً

        for (const { j, theta, v, depthJ } of lonData) {
            if (depthJ < 0.02) continue;
            const hue = (hue0 + j * 22) % 360;
            ctx.globalAlpha = depthJ * (0.30 + v * 0.62);
            ctx.strokeStyle = `hsl(${hue},100%,${46 + v * 32 + depthJ * 16}%)`;
            ctx.lineWidth   = (0.8 + v * 2.8) * depthJ;
            _glow(ctx, `hsl(${hue},100%,70%)`, depthJ * (v * 12 + _beatPulse * 5));
            ctx.beginPath();
            for (let k = 0; k <= lonSegs; k++) {
                const phi = (k / lonSegs) * Math.PI;
                const { sx, sy } = project(theta, phi);
                k === 0 ? ctx.moveTo(sx, sy) : ctx.lineTo(sx, sy);
            }
            ctx.stroke();
        }
        _clearGlow(ctx);

        // ════════════════════════════════════════════════
        // 4. خطوط العرض — بيضاويات مسطحة مع عمق z-sorted
        // ════════════════════════════════════════════════
        const latCount = _N(5, 8, 14);
        for (let i = 1; i < latCount; i++) {
            const phi  = (i / latCount) * Math.PI;
            const y3d  = -Math.cos(phi);
            const r2d  = Math.sin(phi) * R;
            const yr   = y3d * Math.cos(tiltX);
            const ry   = r2d * Math.abs(Math.cos(tiltX));      // التسطيح الناتج عن الإمالة
            const fi   = Math.floor(i * bFreq / latCount);
            const vs   = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const vr   = data.freq[fi] / 255;
            const v    = vs * 0.55 + vr * 0.45;
            const hue  = (hue0 + i * 25 + 60) % 360;
            const pole = 1 - Math.abs(y3d);                    // 0 عند القطبين، 1 عند الخط الاستوائي
            ctx.globalAlpha = (0.22 + v * 0.60) * (0.5 + pole * 0.5);
            ctx.strokeStyle = `hsl(${hue},100%,${44 + v * 34 + pole * 12}%)`;
            ctx.lineWidth   = 0.7 + v * 2.5;
            _glow(ctx, `hsl(${hue},100%,68%)`, v * 11 + pole * 3);
            ctx.beginPath();
            ctx.ellipse(cx, cy + yr * R, r2d, Math.max(ry, 1.5), 0, 0, Math.PI * 2);
            ctx.stroke();
        }
        _clearGlow(ctx);

        // ════════════════════════════════════════════════
        // 5. حزام استوائي متوهج يتسع مع الباص
        // ════════════════════════════════════════════════
        const eqThick = 3.5 + _frameBassAvg * 8 + _beatPulse * 6;
        const eqA     = 0.55 + _frameBassAvg * 0.30 + _beatPulse * 0.15;
        const eqHue   = (hue0 + 180) % 360;
        ctx.globalAlpha = eqA;
        ctx.lineWidth   = eqThick;
        ctx.strokeStyle = `hsl(${eqHue},100%,78%)`;
        _glow(ctx, `hsl(${eqHue},100%,85%)`, isLow ? 8 : 24 + _beatPulse * 14);
        ctx.beginPath();
        ctx.ellipse(cx, cy, R, R * Math.abs(Math.cos(tiltX)), 0, 0, Math.PI * 2);
        ctx.stroke();
        _clearGlow(ctx);

        // ════════════════════════════════════════════════
        // 6. جسيمات على السطح — تطير عند القمم الطيفية
        // ════════════════════════════════════════════════
        if (!isLow) {
            const surfPts = 20;
            for (let p = 0; p < surfPts; p++) {
                const theta = (p / surfPts) * Math.PI * 2 + spinY * 1.3 + p * 0.4;
                const phi   = Math.PI * (0.25 + (p % 5) * 0.14);
                const fi    = Math.floor(p * bFreq / surfPts);
                const vs    = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const v     = Math.pow(vs, 1.6);
                if (v < 0.22) continue;
                const { sx, sy, depth } = project(theta, phi);
                if (depth < 0.12) continue;             // تجاهل نقاط الخلف
                const hue = (hue0 + p * 18) % 360;
                ctx.globalAlpha = depth * (0.45 + v * 0.55);
                _glow(ctx, `hsl(${hue},100%,88%)`, 8 + v * 16 + _beatPulse * 8);
                ctx.fillStyle = `hsl(${hue},100%,${80 + v * 18}%)`;
                ctx.beginPath();
                ctx.arc(sx, sy, (1.5 + v * 5.5) * depth, 0, Math.PI * 2);
                ctx.fill();
            }
            _clearGlow(ctx);
        }

        // ════════════════════════════════════════════════
        // 7. مدارات إلكترونية — 4 مدارات بزوايا مختلفة
        // ════════════════════════════════════════════════
        if (!isLow) {
            const orbCount = 4;
            for (let o = 0; o < orbCount; o++) {
                const tilt    = (o / orbCount) * Math.PI * 0.85 + 0.12;
                const orbR    = R * (1.22 + o * 0.10);
                const angSpd  = time * (0.55 + o * 0.18);
                const fi      = Math.floor(o * bFreq / orbCount);
                const vs      = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const v       = vs * 0.6 + (data.freq[fi] / 255) * 0.4;
                const oHue    = (hue0 + o * 90) % 360;
                const ry      = orbR * Math.abs(Math.cos(tilt));

                // مسار المدار (بيضاوي شبه شفاف)
                ctx.globalAlpha = 0.18 + v * 0.14;
                ctx.strokeStyle = `hsl(${oHue},90%,65%)`;
                ctx.lineWidth   = 0.9 + v * 0.8;
                _glow(ctx, `hsl(${oHue},100%,70%)`, 4);
                ctx.beginPath();
                ctx.ellipse(cx, cy, orbR, Math.max(ry, 2), 0, 0, Math.PI * 2);
                ctx.stroke();
                _clearGlow(ctx);

                // الجسيم المداري نفسه
                const ox = cx + Math.cos(angSpd) * orbR;
                const oy = cy + Math.sin(angSpd) * ry;
                ctx.globalAlpha = 0.72 + v * 0.28;
                _glow(ctx, `hsl(${oHue},100%,84%)`, 12 + v * 18 + _beatPulse * 10);
                ctx.fillStyle = `hsl(${oHue},100%,${78 + v * 20}%)`;
                ctx.beginPath();
                ctx.arc(ox, oy, 2.8 + v * 6, 0, Math.PI * 2);
                ctx.fill();

                // ذيل الجسيم (3 نقاط خلفه تتلاشى)
                for (let t = 1; t <= 3; t++) {
                    const ta  = angSpd - t * 0.22;
                    const tx  = cx + Math.cos(ta) * orbR;
                    const ty  = cy + Math.sin(ta) * ry;
                    ctx.globalAlpha = (0.4 - t * 0.10) * v;
                    ctx.fillStyle   = `hsl(${oHue},100%,75%)`;
                    ctx.beginPath();
                    ctx.arc(tx, ty, (2 - t * 0.4) + v * 2.5, 0, Math.PI * 2);
                    ctx.fill();
                }
                _clearGlow(ctx);
            }
        }

        // ════════════════════════════════════════════════
        // 8. وميض انفجاري عند البيت — خيوط طاقة من المركز
        // ════════════════════════════════════════════════
        if (!isLow && _beatPulse > 0.45) {
            const tendrils = 7;
            for (let t = 0; t < tendrils; t++) {
                const ang = (t / tendrils) * Math.PI * 2 + time * 2.2;
                const len = R * (0.28 + _beatPulse * 0.55);
                const hue = (hue0 + t * 52) % 360;
                ctx.globalAlpha = (_beatPulse - 0.45) * 1.85;
                _glow(ctx, `hsl(${hue},100%,90%)`, 10 + _beatPulse * 12);
                ctx.strokeStyle = `hsl(${hue},100%,92%)`;
                ctx.lineWidth   = 1.5 + _beatPulse * 3;
                ctx.lineCap     = 'round';
                ctx.beginPath();
                ctx.moveTo(cx + Math.cos(ang) * R * 0.55,
                           cy + Math.sin(ang) * R * 0.55);
                ctx.lineTo(cx + Math.cos(ang) * (R * 0.55 + len),
                           cy + Math.sin(ang) * (R * 0.55 + len));
                ctx.stroke();
            }
            ctx.lineCap = 'butt'; _clearGlow(ctx);
        }

        // ════════════════════════════════════════════════
        // 9. بريق علوي (specular highlight) — يوهم بسطح لامع
        // ════════════════════════════════════════════════
        const sg = ctx.createRadialGradient(
            cx - R * 0.28, cy - R * 0.28, 0,
            cx - R * 0.10, cy - R * 0.10, R * 0.65
        );
        sg.addColorStop(0,   `rgba(255,255,255,${0.42 + _beatPulse * 0.30})`);
        sg.addColorStop(0.35,`rgba(255,255,255,${0.10 + _frameBassAvg * 0.12})`);
        sg.addColorStop(1,   `rgba(255,255,255,0)`);
        ctx.fillStyle = sg; ctx.globalAlpha = 1;
        ctx.beginPath(); ctx.arc(cx, cy, R, 0, Math.PI * 2); ctx.fill();

        ctx.globalAlpha = 1; _clearGlow(ctx);
    },
    // ────────────────────────────────────────────────────
    // 13. تشويش رقمي — تشويه فيديو مع إزاحة قنوات RGB
    // ────────────────────────────────────────────────────
    'digital-glitch': (ctx, data, time, w, h, bFreq) => {
        const N = DevicePerf.isLowEnd ? 14 : 22;
        const rowH = h / N, offset = _frameAvgEnergy * 55;

        for (let i = 0; i < N; i++) {
            const v = data.freq[Math.floor(i*bFreq/N)] / 255;
            if (v < 0.07) continue;
            const y = i * rowH;
            const shft = (Math.sin(i*3.7+time*11)*0.5+0.5) * offset * v;

            ctx.fillStyle = `rgba(255,0,80,${v*0.7})`;
            ctx.fillRect(shft, y, w*v, rowH*0.8);
            ctx.fillStyle = `rgba(0,180,255,${v*0.5})`;
            ctx.fillRect(-shft*0.5+w*(1-v), y+rowH*0.1, w*v*0.6, rowH*0.7);

            if (v > 0.38) {
                ctx.fillStyle = `rgba(255,255,255,${(v-0.38)*1.5})`;
                ctx.fillRect(0, y, w, 1.5);
            }
        }

        if (!DevicePerf.isLowEnd && _beatPulse > 0.6) {
            const gy = Math.abs(Math.sin(time*7)) * h;
            ctx.fillStyle = `rgba(0,255,200,${_beatPulse*0.35})`;
            ctx.fillRect(0, gy, w*_frameAvgEnergy, 12+_beatPulse*28);
        }
    },

    // ────────────────────────────────────────────────────
    // 14. تموجات الماء — موجات دائرية تتمدد من المركز
    // ────────────────────────────────────────────────────
    'ripple': (ctx, data, time, w, h, bFreq) => {
        const cx = w/2, cy = h/2;
        const MAX = Math.min(cx,cy)*0.95;
        const N = DevicePerf.isLowEnd ? 12 : 22;
        const hue = (time*35)%360;

        for (let i = 0; i < N; i++) {
            const t = ((i/N + time*0.25) % 1);
            const r = t * MAX;
            const v = data.freq[Math.floor(i*bFreq/N)] / 255;
            const a = (1-t)*(0.15+v*0.6)*(1+_beatPulse*0.4);
            const h2 = (hue+i*15)%360;
            ctx.globalAlpha = a;
            ctx.strokeStyle = `hsl(${h2},90%,${60+v*20}%)`;
            ctx.lineWidth = 1.5+v*3+_beatPulse*2;
            _glow(ctx, `hsl(${h2},100%,70%)`, DevicePerf.isLowEnd ? 0 : 10*(1-t));
            ctx.beginPath(); ctx.arc(cx,cy,r,0,Math.PI*2); ctx.stroke();
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 15. ألعاب نارية — صواريخ تطير وتنفجر بألوان مبهجة مع الإيقاع
    // ────────────────────────────────────────────────────
    'fireworks': (ctx, data, time, w, h, bFreq) => {
        const isLow = DevicePerf.isLowEnd;
        // حدود مستقلة لضمان عمل المؤثر دائماً
        const MAX_ROCKETS = isLow ? 5 : 10;
        const MAX_SPARKS  = isLow ? 300 : 700;

        // إطلاق الصواريخ: عند البيت أو كل ~1.8 ثانية كاحتياط
        const timeSince   = time - _fwLastLaunch;
        const beatTrigger = _beatPulse > 0.35;
        const timeTrigger = timeSince > 1.8;
        if ((beatTrigger || timeTrigger) && _fwRockets.length < MAX_ROCKETS) {
            _fwLastLaunch = time;
            const count = isLow ? 1 : (beatTrigger && _beatPulse > 0.65 ? 2 : 1);
            for (let n = 0; n < count; n++) {
                _fwRockets.push({
                    x: w * (0.12 + Math.random() * 0.76),
                    y: h + 5,
                    // تحديد السرعة بحيث لا يتجاوز الصاروخ أعلى الشاشة (h * 0.08)
                    // معادلة المسافة: d = v²/(2a) حيث a=0.19، أقصى ارتفاع = h * 0.92
                    // v_max = sqrt(2 * 0.19 * h * 0.92) ≈ sqrt(0.35*h) لكن نضيف هامش أمان
                    vy: -(Math.min(3.5 + _frameBassAvg * 4 + Math.random() * 2.5, Math.sqrt(0.30 * h))),
                    hue: Math.random() * 360,
                    trail: [],
                });
            }
        }

        // تحريك الصواريخ ورسمها
        for (let i = _fwRockets.length - 1; i >= 0; i--) {
            const r = _fwRockets[i];
            r.trail.push({ x: r.x, y: r.y });
            const TRAIL = isLow ? 10 : 22;
            if (r.trail.length > TRAIL) r.trail.shift();
            r.y += r.vy;
            r.vy += 0.19;
            r.x += Math.sin(r.y * 0.022) * 1.5;

            for (let j = 0; j < r.trail.length; j++) {
                const a = (j + 1) / r.trail.length;
                ctx.globalAlpha = a * 0.88;
                _glow(ctx, `hsl(${r.hue},100%,75%)`, a * 7);
                ctx.fillStyle = `hsl(${r.hue},100%,${50 + a * 32}%)`;
                ctx.beginPath();
                ctx.arc(r.trail[j].x, r.trail[j].y, 1.2 + a * 2.5, 0, Math.PI * 2);
                ctx.fill();
            }
            ctx.globalAlpha = 1;
            _glow(ctx, '#ffffff', 12);
            ctx.fillStyle = '#ffffff';
            ctx.beginPath(); ctx.arc(r.x, r.y, 2.8, 0, Math.PI * 2); ctx.fill();
            _clearGlow(ctx);

            // الانفجار عند التباطؤ أو الاقتراب من حافة الشاشة العلوية
            if (r.vy >= -1.0 || r.y < h * 0.10) {
                ctx.globalAlpha = 0.55;
                _glow(ctx, `hsl(${r.hue},100%,90%)`, 35);
                ctx.fillStyle = `hsl(${r.hue},80%,95%)`;
                ctx.beginPath(); ctx.arc(r.x, r.y, 18, 0, Math.PI * 2); ctx.fill();
                _clearGlow(ctx);

                // إضافة الشرار فقط إن كان هناك مجال
                const room = Math.max(0, MAX_SPARKS - _fwSparks.length);
                const burst = Math.min(isLow ? 38 : 85, room);
                for (let s = 0; s < burst; s++) {
                    const ang = (s / burst) * Math.PI * 2 + Math.random() * 0.35;
                    const spd = 1.8 + Math.random() * 5.5;
                    _fwSparks.push({
                        x: r.x, y: r.y,
                        vx: Math.cos(ang) * spd,
                        vy: Math.sin(ang) * spd - 0.8,
                        life: 0.85 + Math.random() * 0.25,
                        hue: (r.hue + Math.random() * 70 - 35 + 360) % 360,
                        sz: 1.5 + Math.random() * 2,
                    });
                }
                // طبقة ثانية بألوان مكملة
                if (!isLow && room > burst) {
                    const burst2 = Math.min(28, room - burst);
                    for (let s = 0; s < burst2; s++) {
                        const ang = (s / burst2) * Math.PI * 2 + 0.08;
                        const spd = 0.9 + Math.random() * 3;
                        _fwSparks.push({
                            x: r.x, y: r.y,
                            vx: Math.cos(ang) * spd,
                            vy: Math.sin(ang) * spd - 0.3,
                            life: 1.1 + Math.random() * 0.2,
                            hue: (r.hue + 180) % 360,
                            sz: 1 + Math.random() * 1.5,
                        });
                    }
                }
                _fwRockets.splice(i, 1);
            }
        }

        // تحريك الشرار ورسمه
        for (let i = _fwSparks.length - 1; i >= 0; i--) {
            const s = _fwSparks[i];
            s.x += s.vx; s.y += s.vy;
            s.vy += 0.09; s.vx *= 0.97;
            s.life -= 0.016;
            if (s.life <= 0) { _fwSparks.splice(i, 1); continue; }
            const a = Math.min(s.life, 1);
            ctx.globalAlpha = a;
            _glow(ctx, `hsl(${s.hue},100%,65%)`, 5 * a);
            ctx.fillStyle = `hsl(${s.hue},100%,${52 + a * 28}%)`;
            ctx.beginPath();
            ctx.arc(s.x, s.y, s.sz * a, 0, Math.PI * 2);
            ctx.fill();
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 16. شريط مموج — شريط كثيف بتدرج لوني يتموج
    // ────────────────────────────────────────────────────
    'wave-ribbon': (ctx, data, time, w, h, bFreq, bTime) => {
        const cy = h/2, step = DevicePerf.isLowEnd ? 3 : 1;
        const sw = w*step/bTime, hue = (time*45)%360;
        const thick = 8 + _frameAvgEnergy*22 + _beatPulse*10;

        ctx.globalAlpha = 0.2; ctx.fillStyle = `hsl(${hue},90%,55%)`;
        ctx.beginPath(); ctx.moveTo(0,cy); let x=0;
        for (let i=0;i<bTime;i+=step) {
            ctx.lineTo(x, cy+(data.time[i]/128.0-1)*cy*0.85+Math.sin(time+i*0.02)*8); x+=sw;
        }
        ctx.lineTo(w,cy); ctx.closePath(); ctx.fill(); ctx.globalAlpha=1;

        const g2 = ctx.createLinearGradient(0,cy-thick,0,cy+thick);
        g2.addColorStop(0,   `hsla(${(hue+60)%360},100%,72%,0)`);
        g2.addColorStop(0.5, `hsla(${hue},100%,60%,0.92)`);
        g2.addColorStop(1,   `hsla(${(hue+120)%360},100%,72%,0)`);
        ctx.strokeStyle=g2; ctx.lineWidth=thick;
        ctx.beginPath(); x=0;
        for (let i=0;i<bTime;i+=step) {
            i===0 ? ctx.moveTo(x, cy+(data.time[i]/128.0-1)*cy*0.85+Math.sin(time+i*0.02)*8)
                  : ctx.lineTo(x, cy+(data.time[i]/128.0-1)*cy*0.85+Math.sin(time+i*0.02)*8);
            x+=sw;
        }
        ctx.stroke();
    },

    // ────────────────────────────────────────────────────
    // 17. نجم نابض — نجم يتوهج ويتنفس مع الإيقاع
    // ────────────────────────────────────────────────────
    'pulsar': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, R=Math.min(cx,cy);
        const eng = _frameAvgEnergy + _beatPulse*0.3;
        const r0  = R*0.08 + eng*R*0.88;
        const hue = (time*70)%360;
        const N   = DevicePerf.isUltraLow ? 2 : ((!DevicePerf.isLowEnd && _beatPulse>0.4) ? 4 : 3);
        _glow(ctx, `hsl(${hue},100%,70%)`, DevicePerf.isLowEnd ? 0 : 22*eng);
        for (let i=0;i<N;i++) {
            const frac=1-i/N;
            ctx.globalAlpha = Math.min(1,eng*frac*1.2);
            ctx.strokeStyle = `hsl(${(hue+i*15)%360},100%,${60+frac*20}%)`;
            ctx.lineWidth = (i===0&&_beatPulse>0.7)?6:3+frac*2;
            ctx.beginPath(); ctx.arc(cx,cy,r0*(1-i*0.22),0,Math.PI*2); ctx.stroke();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 18. حقل النجوم — نجوم تتحرك نحوك بسرعة الضوء
    // ────────────────────────────────────────────────────
    'starfield': (ctx, data, time, w, h, bFreq) => {
        const N = _N(50, 80, 180);
        const cx=w/2, cy=h/2;
        const spd = 0.005 + _frameAvgEnergy*0.025 + _beatPulse*0.02;

        if (!_stars3D || _stars3D.length!==N*3) {
            _stars3D = new Float32Array(N*3);
            let s=42;
            const rnd=()=>{s=(s*9301+49297)%233280;return s/233280;};
            for (let i=0;i<N;i++) { _stars3D[i*3]=rnd()*2-1; _stars3D[i*3+1]=rnd()*2-1; _stars3D[i*3+2]=rnd(); }
        }

        const hue=(time*20)%360;
        for (let i=0;i<N;i++) {
            _stars3D[i*3+2]-=spd;
            if (_stars3D[i*3+2]<=0) {
                _stars3D[i*3]=Math.random()*2-1; _stars3D[i*3+1]=Math.random()*2-1; _stars3D[i*3+2]=1;
            }
            const z=_stars3D[i*3+2];
            const sx=cx+(_stars3D[i*3]/z)*cx, sy=cy+(_stars3D[i*3+1]/z)*cy;
            if (sx<0||sx>w||sy<0||sy>h) continue;
            const r=(1-z)*4+0.5, a=1-z, h2=(hue+i*2)%360;
            ctx.globalAlpha=a;
            if (!DevicePerf.isLowEnd && r>1.5) {
                const prevX=cx+(_stars3D[i*3]/(z+spd*3))*cx, prevY=cy+(_stars3D[i*3+1]/(z+spd*3))*cy;
                ctx.strokeStyle=`hsla(${h2},80%,85%,${a*0.5})`; ctx.lineWidth=r*0.5;
                ctx.beginPath(); ctx.moveTo(prevX,prevY); ctx.lineTo(sx,sy); ctx.stroke();
            }
            ctx.fillStyle=`hsl(${h2},80%,${80+a*20}%)`;
            ctx.beginPath(); ctx.arc(sx,sy,r,0,Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 19. دوامة — جسيمات تلتف في حلزون لوغاريتمي
    // ────────────────────────────────────────────────────
    'vortex': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, R=Math.min(cx,cy);
        const step = DevicePerf.isLowEnd ? 8 : 4;
        const spin = 5 + _beatPulse*6;

        for (let i=0;i<bFreq;i+=step) {
            const v=(_smoothedFreq?_smoothedFreq[i]:data.freq[i])/255;
            const t=i/bFreq;
            const ang=(t*Math.PI*10)-time*spin;
            const r=R*(0.05+t*0.9)*(0.3+v*0.7);
            const x=cx+Math.cos(ang)*r, y=cy+Math.sin(ang)*r*0.8;
            const hue=(t*280+time*60)%360;
            ctx.globalAlpha=0.4+v*0.6;
            _glow(ctx,`hsl(${hue},100%,65%)`,DevicePerf.isLowEnd?0:5*v);
            ctx.fillStyle=`hsl(${hue},100%,${55+v*25}%)`;
            ctx.beginPath(); ctx.arc(x,y,1.5+v*4,0,Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 20. أشكال هندسية — مثلث + مربع + خماسي + سداسي
    // ────────────────────────────────────────────────────
    'geometric': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, R=Math.min(cx,cy)*0.8;
        const shapes=[3,4,5,6];
        const N=DevicePerf.isLowEnd ? 2 : 4;

        for (let si=0;si<N;si++) {
            const sides=shapes[si];
            const v=data.freq[Math.floor(si*bFreq/N)]/255;
            const size=R*(0.14+v*0.7)/(si*0.3+1);
            const hue=(si*90+time*40)%360;
            const rot=time*(0.3+si*0.15)*(si%2===0?1:-1);
            ctx.globalAlpha=0.4+v*0.6;
            ctx.strokeStyle=`hsl(${hue},100%,${55+v*25}%)`;
            ctx.lineWidth=1.5+v*3;
            _glow(ctx,`hsl(${hue},100%,70%)`,DevicePerf.isLowEnd?0:10*v);
            ctx.save(); ctx.translate(cx,cy); ctx.rotate(rot);
            ctx.beginPath();
            for (let k=0;k<=sides;k++) {
                const ang=(k/sides)*Math.PI*2-Math.PI/2;
                k===0?ctx.moveTo(Math.cos(ang)*size,Math.sin(ang)*size)
                     :ctx.lineTo(Math.cos(ang)*size,Math.sin(ang)*size);
            }
            ctx.closePath(); ctx.stroke(); ctx.restore();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 21. مجرة — ذراعا مجرة حلزونية تدوران ببطء
    // ────────────────────────────────────────────────────
    'galaxy-matrix': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, R=Math.min(cx,cy)*0.85;
        const N=DevicePerf.isLowEnd?120:280, arms=2;
        const hue=(time*15)%360;

        const grad=ctx.createRadialGradient(cx,cy,0,cx,cy,R*0.22);
        grad.addColorStop(0,`hsla(${(hue+40)%360},80%,92%,${0.3+_frameBassAvg*0.5})`);
        grad.addColorStop(1,`hsla(${hue},80%,60%,0)`);
        ctx.fillStyle=grad; ctx.beginPath(); ctx.arc(cx,cy,R*0.22,0,Math.PI*2); ctx.fill();

        for (let i=0;i<N;i++) {
            const arm=i%arms, t=i/N;
            const v=data.freq[Math.floor(t*bFreq)]/255;
            const ang=t*Math.PI*6+(arm*Math.PI)+time*0.12;
            const r=R*(0.05+t*0.85)*(0.6+v*0.4);
            const x=cx+Math.cos(ang)*r+(Math.random()-0.5)*R*0.06;
            const y=cy+Math.sin(ang)*r*0.55;
            const h2=(hue+t*60+arm*40)%360;
            const sz=0.8+v*3+(1-t)*2;
            ctx.globalAlpha=0.3+v*0.6+(1-t)*0.4;
            ctx.fillStyle=`hsl(${h2},90%,${65+v*25}%)`;
            ctx.beginPath(); ctx.arc(x,y,sz,0,Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 22. فقاعات ليزر — فقاعات تطفو وأشعة ليزر تربطها
    // ────────────────────────────────────────────────────
    'laser-bubbles': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2;
        const N=DevicePerf.isLowEnd?8:14, hue=(time*60)%360;
        const orb=[];

        for (let i=0;i<N;i++) {
            const v=data.freq[Math.floor(i*bFreq/N)]/255;
            const ang=(i/N)*Math.PI*2+time*0.4+i*0.3;
            const R=Math.min(cx,cy)*(0.2+v*0.65);
            const x=cx+Math.cos(ang)*R, y=cy+Math.sin(ang)*R*0.8;
            const r=4+v*18, h2=(hue+i*25)%360;
            orb.push({x,y,r,h2,v});

            ctx.globalAlpha=0.3+v*0.5;
            ctx.strokeStyle=`hsl(${h2},100%,70%)`; ctx.lineWidth=1.5+v*2;
            _glow(ctx,`hsl(${h2},100%,70%)`,DevicePerf.isLowEnd?0:12*v);
            ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.stroke();

            if (!DevicePerf.isLowEnd && v>0.2) {
                ctx.globalAlpha=v*0.4; ctx.fillStyle=`hsl(${h2},100%,88%)`;
                ctx.beginPath(); ctx.arc(x-r*0.3,y-r*0.3,r*0.24,0,Math.PI*2); ctx.fill();
            }
        }
        _clearGlow(ctx);

        ctx.lineWidth=1;
        for (let i=0;i<orb.length;i++) {
            for (let j=i+1;j<orb.length;j++) {
                const d=Math.hypot(orb[i].x-orb[j].x,orb[i].y-orb[j].y);
                if (d>Math.min(w,h)*0.5) continue;
                const alpha=(1-d/(Math.min(w,h)*0.5))*(orb[i].v+orb[j].v)*0.4;
                ctx.globalAlpha=alpha;
                ctx.strokeStyle=`hsl(${(orb[i].h2+orb[j].h2)/2},100%,65%)`;
                ctx.beginPath(); ctx.moveTo(orb[i].x,orb[i].y); ctx.lineTo(orb[j].x,orb[j].y); ctx.stroke();
            }
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 23. شلال رقمي — كود Matrix يتساقط من الأعلى
    // ────────────────────────────────────────────────────
    'digital-waterfall': (ctx, data, time, w, h, bFreq) => {
        const fontSize=DevicePerf.isLowEnd?12:14;
        const cols=Math.floor(w/fontSize);
        const hue=(time*25)%360;

        if (!_matrixCols||_matrixCols.length!==cols) {
            _matrixCols=new Float32Array(cols);
            for (let i=0;i<cols;i++) _matrixCols[i]=Math.random()*-h;
        }

        ctx.font=`bold ${fontSize}px monospace`;
        for (let c=0;c<cols;c++) {
            const v=data.freq[Math.floor(c*bFreq/cols)]/255;
            const spd=(1+v*5+_frameBassAvg*4)*(DevicePerf.isLowEnd?1.5:1);
            const y=_matrixCols[c], h2=(hue+c*3)%360;

            if (y>0&&y<h) {
                ctx.fillStyle=`hsl(${h2},100%,92%)`; ctx.globalAlpha=0.92;
                ctx.fillText(String.fromCharCode(0x30A0+Math.floor(Math.random()*96)),c*fontSize,y);

                const steps=DevicePerf.isLowEnd?8:16;
                for (let s=1;s<steps;s++) {
                    const sy=y-s*fontSize; if(sy<0) break;
                    ctx.fillStyle=`hsl(${h2},100%,${50+v*20}%)`;
                    ctx.globalAlpha=(1-s/steps)*(0.4+v*0.4);
                    ctx.fillText(String.fromCharCode(0x30A0+Math.floor(Math.random()*96)),c*fontSize,sy);
                }
            }
            _matrixCols[c]+=spd;
            if (_matrixCols[c]>h+fontSize*22) _matrixCols[c]=-(Math.random()*h*0.5);
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 24. توهج الحواف — حواف الشاشة تتوهج بالإيقاع
    // ────────────────────────────────────────────────────
    // ────────────────────────────────────────────────────
    // 24. توهج الحواف — حواف حية بأقواس وجسيمات وزوايا متوهجة
    // ────────────────────────────────────────────────────
    'edge-glow': (ctx, data, time, w, h, bFreq) => {
        const isLow  = DevicePerf.isLowEnd;
        const hue0   = (time * 38) % 360;
        const energy = _frameAvgEnergy;
        const beat   = _beatPulse;

        // ══════════════════════════════════════════════
        // مُساعد: تحويل موضع على محيط المستطيل (0..1) → {x,y,nx,ny}
        // المحيط الكلي = 2*(w+h), نبدأ من الزاوية العليا-يسار
        // ══════════════════════════════════════════════
        const perim = 2 * (w + h);
        const perimToXY = (t) => {
            const d = ((t % 1) + 1) % 1 * perim;
            if (d < w)          return { x: d,     y: 0,     nx:  0, ny: -1 };
            if (d < w + h)      return { x: w,     y: d-w,   nx:  1, ny:  0 };
            if (d < 2*w + h)    return { x: w-(d-w-h), y: h, nx:  0, ny:  1 };
            return                     { x: 0, y: h-(d-2*w-h),   nx: -1, ny:  0 };
        };

        // ══════════════════════════════════════════════
        // 1. توهج خلفي ناعم على كل ضلع (shadow glow)
        // ══════════════════════════════════════════════
        if (!isLow) {
            const margin = 28 + energy * 55 + beat * 20;
            [
                // [x1, y1, x2, y2,  gx1, gy1, gx2, gy2,  freqBin]
                [0, 0, w, 0,        0, 0,      0, margin,    0],
                [w, 0, w, h,        w, 0,      w-margin, 0,  Math.floor(bFreq*0.33)],
                [0, h, w, h,        0, h,      0, h-margin,  Math.floor(bFreq*0.66)],
                [0, 0, 0, h,        0, 0,      margin, 0,    Math.floor(bFreq*0.85)],
            ].forEach(([x1,y1,x2,y2, gx1,gy1,gx2,gy2, fi], ei) => {
                const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const hue = (hue0 + ei * 90) % 360;
                const g   = ctx.createLinearGradient(gx1, gy1, gx2, gy2);
                g.addColorStop(0,   `hsla(${hue},100%,60%,${0.18 + vs * 0.28})`);
                g.addColorStop(1,   `hsla(${hue},100%,60%,0)`);
                ctx.fillStyle   = g;
                ctx.globalAlpha = 1;
                // رسم شريط التوهج الجانبي
                if (ei === 0) ctx.fillRect(0, 0, w, margin);
                else if (ei === 1) ctx.fillRect(w - margin, 0, margin, h);
                else if (ei === 2) ctx.fillRect(0, h - margin, w, margin);
                else ctx.fillRect(0, 0, margin, h);
            });
        }

        // ══════════════════════════════════════════════
        // 2. أقواس مقسّمة على طول كل ضلع — القلب الرئيسي
        // كل شريحة تمتد من الحافة نحو المركز بنسبة تردداتها
        // ══════════════════════════════════════════════
        const segsPerEdge = isLow ? 16 : 32;
        const totalSegs   = segsPerEdge * 4;

        ctx.lineCap = 'round';
        for (let i = 0; i < totalSegs; i++) {
            const t   = i / totalSegs;
            const fi  = Math.floor(t * bFreq);
            const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const vr  = data.freq[fi] / 255;
            const v   = vs * 0.58 + vr * 0.42;
            if (v < 0.04) continue;

            const { x, y, nx, ny } = perimToXY(t);
            const hue = (hue0 + t * 320) % 360;
            const lum = 50 + v * 38;
            const len = (12 + v * (isLow ? 55 : 90) + beat * 22) * (1 + energy * 0.5);
            const lw  = isLow ? (1.8 + v * 4) : (2 + v * 6.5);

            ctx.globalAlpha = 0.50 + v * 0.50;
            ctx.lineWidth   = lw;
            _glow(ctx, `hsl(${hue},100%,${lum}%)`, isLow ? v * 7 : v * 22 + beat * 8);

            if (!isLow && v > 0.38) {
                const lg = ctx.createLinearGradient(x, y, x + nx * len, y + ny * len);
                lg.addColorStop(0,   `hsla(${hue},100%,${lum}%,0.8)`);
                lg.addColorStop(0.6, `hsla(${hue},100%,${lum+18}%,0.95)`);
                lg.addColorStop(1,   `hsla(${(hue+50)%360},100%,92%,1)`);
                ctx.strokeStyle = lg;
            } else {
                ctx.strokeStyle = `hsl(${hue},100%,${lum}%)`;
            }

            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(x + nx * len, y + ny * len);
            ctx.stroke();

            // نقطة متوهجة عند طرف الشريحة للقمم العالية
            if (!isLow && v > 0.56) {
                ctx.globalAlpha = (v - 0.56) * 2.3;
                _glow(ctx, `hsl(${hue},100%,94%)`, 12 + v * 8);
                ctx.fillStyle = `hsl(${hue},100%,97%)`;
                ctx.beginPath();
                ctx.arc(x + nx * len, y + ny * len, 1.8 + v * 5, 0, Math.PI * 2);
                ctx.fill();
            }
        }
        _clearGlow(ctx); ctx.lineCap = 'butt';

        // ══════════════════════════════════════════════
        // 3. خط الحافة المضيء — يتنفس مع كل ضلع على حدة
        // ══════════════════════════════════════════════
        const edges = [
            { x1:0, y1:0, x2:w, y2:0,   fi: 0 },
            { x1:w, y1:0, x2:w, y2:h,   fi: Math.floor(bFreq*0.33) },
            { x1:0, y1:h, x2:w, y2:h,   fi: Math.floor(bFreq*0.66) },
            { x1:0, y1:0, x2:0, y2:h,   fi: Math.floor(bFreq*0.85) },
        ];
        edges.forEach(({ x1,y1,x2,y2,fi }, ei) => {
            const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const vr  = data.freq[fi] / 255;
            const v   = vs * 0.55 + vr * 0.45;
            const hue = (hue0 + ei * 90) % 360;

            // طبقتان: توهج عريض + خط دقيق فوقه
            [[14, 0.12 + v*0.14], [3.5 + v*3, 0.55 + v*0.45]].forEach(([lw, a]) => {
                ctx.globalAlpha = a;
                ctx.lineWidth   = lw;
                const g = ctx.createLinearGradient(x1, y1, x2, y2);
                g.addColorStop(0,    `hsla(${hue},100%,65%,0)`);
                g.addColorStop(0.25, `hsla(${hue},100%,72%,1)`);
                g.addColorStop(0.5,  `hsla(${(hue+40)%360},100%,78%,1)`);
                g.addColorStop(0.75, `hsla(${hue},100%,72%,1)`);
                g.addColorStop(1,    `hsla(${hue},100%,65%,0)`);
                ctx.strokeStyle = g;
                _glow(ctx, `hsl(${hue},100%,78%)`, lw * (1.5 + v));
                ctx.beginPath(); ctx.moveTo(x1,y1); ctx.lineTo(x2,y2); ctx.stroke();
            });
        });
        ctx.globalAlpha = 1; _clearGlow(ctx);

        // ══════════════════════════════════════════════
        // 4. زوايا متوهجة — نقاط طاقة في الأركان الأربعة
        // ══════════════════════════════════════════════
        const corners = [[0,0],[w,0],[w,h],[0,h]];
        corners.forEach(([cx2,cy2], ci) => {
            const fi  = Math.floor(ci * bFreq / 4);
            const vs  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const v   = Math.pow(vs, 1.4);
            const hue = (hue0 + ci * 90) % 360;
            const r   = isLow ? (8 + v * 22 + beat * 10) : (10 + v * 36 + beat * 16);

            // هالة خارجية
            if (!isLow) {
                const cg = ctx.createRadialGradient(cx2, cy2, 0, cx2, cy2, r * 2.8);
                cg.addColorStop(0,   `hsla(${hue},100%,80%,${0.60 + v * 0.40})`);
                cg.addColorStop(0.4, `hsla(${hue},100%,60%,${0.22 + v * 0.28})`);
                cg.addColorStop(1,   `hsla(${hue},100%,50%,0)`);
                _glow(ctx, `hsl(${hue},100%,82%)`, 18 + v * 20 + beat * 14);
                ctx.fillStyle   = cg;
                ctx.globalAlpha = 1;
                ctx.beginPath(); ctx.arc(cx2, cy2, r * 2.8, 0, Math.PI * 2); ctx.fill();
                _clearGlow(ctx);
            }

            // نقطة النواة
            ctx.globalAlpha = 0.70 + v * 0.30;
            _glow(ctx, `hsl(${hue},100%,90%)`, isLow ? 6 : 14 + v * 18 + beat * 10);
            ctx.fillStyle = `hsl(${hue},100%,${78 + v * 20}%)`;
            ctx.beginPath(); ctx.arc(cx2, cy2, r * 0.55, 0, Math.PI * 2); ctx.fill();
            _clearGlow(ctx);

            // خطوط قطرية تخرج من الزاوية عند قمم التردد
            if (!isLow && v > 0.38) {
                const dirs = ci === 0 ? [[1,0],[0,1]] : ci === 1 ? [[-1,0],[0,1]] :
                             ci === 2 ? [[-1,0],[0,-1]] : [[1,0],[0,-1]];
                dirs.forEach(([dx,dy]) => {
                    const len = v * 55 + beat * 25;
                    ctx.globalAlpha = (v - 0.38) * 1.6;
                    ctx.strokeStyle = `hsl(${hue},100%,88%)`;
                    ctx.lineWidth   = 1.5 + v * 3;
                    ctx.lineCap     = 'round';
                    _glow(ctx, `hsl(${hue},100%,88%)`, 8 + v * 10);
                    ctx.beginPath();
                    ctx.moveTo(cx2, cy2);
                    ctx.lineTo(cx2 + dx * len, cy2 + dy * len);
                    ctx.stroke();
                    ctx.lineCap = 'butt'; _clearGlow(ctx);
                });
            }
        });

        // ══════════════════════════════════════════════
        // 5. جسيمات تتطاير من الحواف نحو المركز عند البيت
        // ══════════════════════════════════════════════
        if (!isLow && beat > 0.40) {
            const sparks = 12;
            for (let s = 0; s < sparks; s++) {
                const t    = (s / sparks + time * 0.07) % 1;
                const { x, y, nx, ny } = perimToXY(t);
                const fi   = Math.floor(t * bFreq);
                const v    = data.freq[fi] / 255;
                const hue  = (hue0 + t * 280) % 360;
                const dist = (beat - 0.40) * 160 * v;
                ctx.globalAlpha = (beat - 0.40) * 1.65 * v;
                _glow(ctx, `hsl(${hue},100%,92%)`, 8 + beat * 10);
                ctx.fillStyle = `hsl(${hue},100%,95%)`;
                ctx.beginPath();
                ctx.arc(x + nx * dist, y + ny * dist, 2 + v * 5, 0, Math.PI * 2);
                ctx.fill();
            }
            _clearGlow(ctx);
        }

        // ══════════════════════════════════════════════
        // 6. إطار موجي متصل يموج مع الموسيقى
        // نرسم مسار مغلق على المحيط مع تمدد عمودي بالتردد
        // ══════════════════════════════════════════════
        if (!isLow) {
            const waveSegs = 60;
            ctx.lineWidth   = 1.8 + energy * 2.5;
            ctx.globalAlpha = 0.55 + energy * 0.30;
            const wg = ctx.createLinearGradient(0, 0, w, 0);
            wg.addColorStop(0,   `hsl(${hue0},100%,72%)`);
            wg.addColorStop(0.5, `hsl(${(hue0+120)%360},100%,78%)`);
            wg.addColorStop(1,   `hsl(${(hue0+240)%360},100%,72%)`);
            ctx.strokeStyle = wg;
            _glow(ctx, `hsl(${hue0},100%,75%)`, 6 + energy * 10);

            ctx.beginPath();
            for (let i = 0; i <= waveSegs; i++) {
                const t    = i / waveSegs;
                const { x, y, nx, ny } = perimToXY(t);
                const fi   = Math.floor(t * bFreq);
                const vs   = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
                const push = vs * 12 * (1 + beat * 0.8);
                const px   = x + nx * push;
                const py   = y + ny * push;
                i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
            }
            ctx.closePath(); ctx.stroke();
            _clearGlow(ctx);
        }

        ctx.globalAlpha = 1;
    },
    // ────────────────────────────────────────────────────
    // 25. نفق بلازما — حلقات بلازما ملونة في نفق
    // ────────────────────────────────────────────────────
    'plasma-tunnel': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, maxR=Math.min(cx,cy);
        const rings=DevicePerf.isLowEnd?6:12;
        const step=DevicePerf.isLowEnd?12:6;

        for (let ri=0;ri<rings;ri++) {
            const t=((ri/rings+time*0.3)%1);
            const r=maxR*t;
            const v=data.freq[Math.floor(ri*bFreq/rings)]/255;
            const hue=(ri*30+time*60)%360;
            ctx.globalAlpha=(1-t)*(0.3+v*0.7);
            ctx.strokeStyle=`hsl(${hue},100%,${50+v*30}%)`;
            ctx.lineWidth=2+v*6+_beatPulse*3;
            _glow(ctx,`hsl(${hue},100%,70%)`,DevicePerf.isLowEnd?0:15*(1-t));

            const segs=DevicePerf.isLowEnd?24:48;
            ctx.beginPath();
            for (let i=0;i<=segs;i++) {
                const ang=(i/segs)*Math.PI*2+time*0.5;
                const dv=data.freq[Math.floor((i/segs)*bFreq)]/255;
                const dist=r+dv*25*(1-t);
                const x=cx+Math.cos(ang)*dist, y=cy+Math.sin(ang)*dist;
                i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
            }
            ctx.closePath(); ctx.stroke();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 26. معادل ثلاثي الأبعاد — أعمدة بمنظور 3D حقيقي
    // ────────────────────────────────────────────────────
    'equalizer-3d': (ctx, data, time, w, h, bFreq) => {
        const N=DevicePerf.isLowEnd?20:36;
        const persp=h*0.12, bw=(w-persp)/N;

        for (let i=0;i<N;i++) {
            const v=(_smoothedFreq?_smoothedFreq[Math.floor(i*bFreq/N)]:data.freq[Math.floor(i*bFreq/N)])/255;
            const bh=v*h*0.75*(1+_beatPulse*0.15);
            const x=i*bw, hue=(i*8+time*30)%360, fw=bw*0.88;

            if (!DevicePerf.isLowEnd&&bh>4) {
                const g=ctx.createLinearGradient(x,h-bh,x,h);
                g.addColorStop(0,`hsl(${(hue+20)%360},100%,75%)`);
                g.addColorStop(1,`hsl(${hue},100%,38%)`);
                ctx.fillStyle=g;
            } else { ctx.fillStyle=`hsl(${hue},100%,55%)`; }

            ctx.globalAlpha=0.9; ctx.fillRect(x,h-bh,fw,bh);
            ctx.globalAlpha=0.6; ctx.fillStyle=`hsl(${(hue+30)%360},100%,72%)`;
            ctx.beginPath();
            ctx.moveTo(x,h-bh); ctx.lineTo(x+persp,h-bh-persp);
            ctx.lineTo(x+fw+persp,h-bh-persp); ctx.lineTo(x+fw,h-bh);
            ctx.closePath(); ctx.fill();
            ctx.globalAlpha=0.4; ctx.fillStyle=`hsl(${hue},100%,28%)`;
            ctx.beginPath();
            ctx.moveTo(x+fw,h-bh); ctx.lineTo(x+fw+persp,h-bh-persp);
            ctx.lineTo(x+fw+persp,h-persp); ctx.lineTo(x+fw,h);
            ctx.closePath(); ctx.fill();
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 27. شبكة عنكبوتية — خيوط شعاعية ودائرية
    // ────────────────────────────────────────────────────
    'sound-web': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, maxR=Math.min(cx,cy)*0.92;
        const spokes=DevicePerf.isLowEnd?8:16, rings=DevicePerf.isLowEnd?5:8;
        const hue=(time*20)%360;
        const pts=[];

        for (let r=1;r<=rings;r++) {
            const row=[];
            for (let s=0;s<spokes;s++) {
                const v=data.freq[Math.floor((r*spokes+s)*bFreq/(rings*spokes))]/255;
                const ang=(s/spokes)*Math.PI*2-Math.PI/2+time*0.05;
                const rad=(r/rings)*maxR*(0.5+v*0.6)*(1+_beatPulse*0.1);
                row.push({x:cx+Math.cos(ang)*rad, y:cy+Math.sin(ang)*rad, v});
            }
            pts.push(row);
        }

        for (let r=0;r<rings;r++) {
            const v=pts[r][0].v, h2=(hue+r*20)%360;
            ctx.globalAlpha=0.3+v*0.5; ctx.strokeStyle=`hsl(${h2},90%,${55+v*25}%)`;
            ctx.lineWidth=0.8+v*2;
            ctx.beginPath();
            pts[r].forEach((p,i)=>i===0?ctx.moveTo(p.x,p.y):ctx.lineTo(p.x,p.y));
            ctx.closePath(); ctx.stroke();
        }

        for (let s=0;s<spokes;s++) {
            const v=pts[rings-1][s].v, h2=(hue+s*22)%360;
            ctx.globalAlpha=0.4+v*0.5; ctx.strokeStyle=`hsl(${h2},90%,60%)`;
            ctx.lineWidth=1+v*1.5;
            ctx.beginPath(); ctx.moveTo(cx,cy);
            pts.forEach(row=>ctx.lineTo(row[s].x,row[s].y)); ctx.stroke();
        }

        if (!DevicePerf.isLowEnd) {
            pts.forEach(row=>row.forEach(p=>{
                if(p.v<0.1) return;
                ctx.globalAlpha=p.v;
                _glow(ctx,`hsl(${hue},100%,70%)`,5*p.v);
                ctx.fillStyle=`hsl(${hue},100%,82%)`;
                ctx.beginPath(); ctx.arc(p.x,p.y,2+p.v*4,0,Math.PI*2); ctx.fill();
            }));
            _clearGlow(ctx);
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 28. حلقة قوس قزح — حلقة متوهجة بأشواك ترتفع مع الترددات
    // ────────────────────────────────────────────────────
    'rainbow-ring': (ctx, data, time, w, h, bFreq) => {
        const cx = w/2, cy = h/2;
        const isLow = DevicePerf.isLowEnd;
        const N = isLow ? 80 : 160;
        const baseR = Math.min(cx,cy) * (0.28 + _frameBassAvg*0.12 + _beatPulse*0.06);
        const maxSpike = Math.min(cx,cy) * 0.55;

        // رسم حلقتين دائريتين خلفيتين كأساس
        const rings = isLow ? 1 : 2;
        for (let ri = 0; ri < rings; ri++) {
            const rr = baseR * (1 - ri*0.18);
            const hue0 = (time*45 + ri*60) % 360;
            ctx.globalAlpha = 0.22 - ri*0.06;
            ctx.strokeStyle = `hsl(${hue0},100%,65%)`;
            ctx.lineWidth = 3 - ri;
            _glow(ctx, `hsl(${hue0},100%,70%)`, 8);
            ctx.beginPath(); ctx.arc(cx, cy, rr, 0, Math.PI*2); ctx.stroke();
        }
        _clearGlow(ctx);

        // رسم الأشواك — كل شوكة ترتفع بقدر تردده
        ctx.save();
        for (let i = 0; i < N; i++) {
            const fi   = Math.floor(i * bFreq / N);
            const val  = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const ang  = (i / N) * Math.PI * 2 - Math.PI / 2;
            const spike = val * maxSpike * (1 + _beatPulse * 0.25);
            const hue  = (i / N * 360 + time * 50) % 360;

            const x1 = cx + Math.cos(ang) * baseR;
            const y1 = cy + Math.sin(ang) * baseR;
            const x2 = cx + Math.cos(ang) * (baseR + spike);
            const y2 = cy + Math.sin(ang) * (baseR + spike);

            if (spike < 2) continue;

            // خط الشوكة بتدرج لوني
            const grad = ctx.createLinearGradient(x1, y1, x2, y2);
            grad.addColorStop(0, `hsla(${hue},100%,55%,0.6)`);
            grad.addColorStop(1, `hsla(${(hue+40)%360},100%,85%,${0.5 + val*0.5})`);
            ctx.strokeStyle = grad;
            ctx.lineWidth = 1.2 + val * 2.8;
            ctx.globalAlpha = 0.55 + val * 0.45;
            _glow(ctx, `hsl(${hue},100%,75%)`, val * 10);
            ctx.beginPath(); ctx.moveTo(x1, y1); ctx.lineTo(x2, y2); ctx.stroke();

            // نقطة مضيئة عند طرف الشوكة إذا كانت عالية
            if (val > 0.55) {
                ctx.globalAlpha = (val - 0.55) * 2;
                ctx.fillStyle = `hsl(${(hue+20)%360},100%,92%)`;
                ctx.beginPath(); ctx.arc(x2, y2, 1.5 + val*2, 0, Math.PI*2); ctx.fill();
            }
        }
        ctx.restore();

        // نواة مركزية متوهجة
        const coreR = baseR * 0.28 + _beatPulse * 8;
        const cHue  = (time * 70) % 360;
        const cg = ctx.createRadialGradient(cx, cy, 0, cx, cy, coreR);
        cg.addColorStop(0, `hsla(${cHue},100%,95%,${0.6 + _beatPulse*0.4})`);
        cg.addColorStop(0.5, `hsla(${(cHue+40)%360},100%,65%,${0.3 + _beatPulse*0.3})`);
        cg.addColorStop(1, `hsla(${cHue},100%,55%,0)`);
        ctx.fillStyle = cg;
        ctx.globalAlpha = 1;
        _glow(ctx, `hsl(${cHue},100%,80%)`, 15 + _beatPulse*12);
        ctx.beginPath(); ctx.arc(cx, cy, coreR, 0, Math.PI*2); ctx.fill();
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 29. أشعة شمسية — أشعة تمتد من مركز كالشمس
    // ────────────────────────────────────────────────────
    'radial-bars': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2;
        const N=_N(40, 60, 120);
        const maxL=Math.min(cx,cy)*0.72;
        const bass=(data.freq[0]+data.freq[1]+data.freq[2]+data.freq[3])*0.25;
        const innerR=18+(bass/255)*28+_beatPulse*16;

        for (let i=0;i<N;i++) {
            const v=(_smoothedFreq?_smoothedFreq[Math.floor(i*bFreq/N)]:data.freq[Math.floor(i*bFreq/N)])/255;
            if (v < 0.02) continue;
            const len=v*maxL, ang=(i/N)*Math.PI*2-Math.PI/2, hue=(i/N*360+time*25)%360;
            _glow(ctx, `hsl(${hue},100%,65%)`, 6 + _beatPulse*8);
            ctx.strokeStyle=`hsl(${hue},100%,${50+_beatPulse*20}%)`;
            ctx.lineWidth=1.5+v*3.5; ctx.globalAlpha=0.5+v*0.5;
            ctx.beginPath();
            ctx.moveTo(cx+Math.cos(ang)*innerR, cy+Math.sin(ang)*innerR);
            ctx.lineTo(cx+Math.cos(ang)*(innerR+len), cy+Math.sin(ang)*(innerR+len));
            ctx.stroke();
        }
        _clearGlow(ctx);
        const g=ctx.createRadialGradient(cx,cy,0,cx,cy,innerR);
        g.addColorStop(0,'rgba(255,255,220,0.95)'); g.addColorStop(1,'rgba(255,200,50,0.3)');
        ctx.fillStyle=g; ctx.globalAlpha=1;
        ctx.beginPath(); ctx.arc(cx,cy,innerR,0,Math.PI*2); ctx.fill();
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 30. خطوط دوارة — خطوط تدور كعقارب الساعة
    // ────────────────────────────────────────────────────
    'spinning-lines': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2;
        const N=DevicePerf.isLowEnd?48:96;
        const OR=Math.min(cx,cy)*0.88, IR=Math.min(cx,cy)*0.12;

        ctx.save(); ctx.translate(cx,cy); ctx.rotate(time*0.35);
        for (let i=0;i<N;i++) {
            const v=(_smoothedFreq?_smoothedFreq[Math.floor(i*bFreq/N)]:data.freq[Math.floor(i*bFreq/N)])/255;
            const ang=(i/N)*Math.PI*2;
            const len=IR+v*(OR-IR), hue=(200+v*120+time*40)%360;
            _glow(ctx,`hsl(${hue},100%,65%)`,DevicePerf.isLowEnd?0:8*v);
            ctx.strokeStyle=`hsl(${hue},100%,${50+v*30}%)`; ctx.lineWidth=1+v*3;
            ctx.globalAlpha=0.3+v*0.7;
            ctx.beginPath();
            ctx.moveTo(Math.cos(ang)*IR, Math.sin(ang)*IR);
            ctx.lineTo(Math.cos(ang)*len, Math.sin(ang)*len);
            ctx.stroke();
        }
        ctx.restore(); _clearGlow(ctx); ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 31. انفجار قصاصات — مستطيلات ملونة تتساقط وتدور
    // ────────────────────────────────────────────────────
    'confetti-burst': (ctx, data, time, w, h, bFreq) => {
        const bass=data.freq[2], now=Date.now()/1000;
        const maxP=DevicePerf.maxParticles;

        if (bass>168&&now-lastBassHit>0.18&&confettiParticles.length<maxP) {
            lastBassHit=now;
            const burst=Math.min(DevicePerf.isLowEnd?18:45, maxP-confettiParticles.length);
            for (let i=0;i<burst;i++) {
                confettiParticles.push({
                    x:w*(0.3+Math.random()*0.4), y:h/2,
                    vx:(Math.random()-0.5)*13, vy:(Math.random()-0.5)*13,
                    cw:4+Math.random()*10, ch:2+Math.random()*6,
                    rot:Math.random()*Math.PI*2, rspd:(Math.random()-0.5)*0.3,
                    color:`hsl(${Math.random()*360},100%,60%)`, life:1.0,
                });
            }
        }

        for (let i=confettiParticles.length-1;i>=0;i--) {
            const p=confettiParticles[i];
            p.x+=p.vx; p.y+=p.vy; p.vy+=0.16; p.vx*=0.98;
            p.rot+=p.rspd; p.life-=0.018;
            if(p.life<=0){confettiParticles.splice(i,1);continue;}
            ctx.save(); ctx.translate(p.x,p.y); ctx.rotate(p.rot);
            ctx.globalAlpha=p.life; ctx.fillStyle=p.color;
            ctx.fillRect(-p.cw/2,-p.ch/2,p.cw,p.ch);
            ctx.restore();
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 32. شبكة نيون — شبكة متوهجة بتقاطعات ساطعة
    // ────────────────────────────────────────────────────
    'neon-grid': (ctx, data, time, w, h, bFreq) => {
        const step=DevicePerf.isLowEnd?35:24;
        const hue=(time*30)%360, eng=_frameAvgEnergy;
        const colsN=Math.ceil(w/step), rowsN=Math.ceil(h/step);

        ctx.strokeStyle=`hsla(${hue},100%,55%,${0.18+eng*0.28})`;
        ctx.lineWidth=0.5; ctx.beginPath();
        for (let x=0;x<=w;x+=step){ctx.moveTo(x,0);ctx.lineTo(x,h);}
        for (let y=0;y<=h;y+=step){ctx.moveTo(0,y);ctx.lineTo(w,y);}
        ctx.stroke();

        for (let r=0;r<=rowsN;r++) {
            for (let c=0;c<=colsN;c++) {
                const idx=Math.floor((r*colsN+c)/(rowsN*colsN)*bFreq);
                const v=data.freq[idx]/255;
                if(v<0.04) continue;
                const x=c*step, y=r*step, h2=(hue+c*5+r*7)%360;
                _glow(ctx,`hsl(${h2},100%,70%)`,DevicePerf.isLowEnd?0:12*v);
                ctx.fillStyle=`hsl(${h2},100%,${65+v*25}%)`; ctx.globalAlpha=0.5+v*0.5;
                ctx.beginPath(); ctx.arc(x,y,2+v*5,0,Math.PI*2); ctx.fill();
                _clearGlow(ctx);
            }
        }

        if (!DevicePerf.isLowEnd) {
            const wx=(Math.sin(time*0.8)*0.5+0.5)*w, wy=(Math.cos(time*0.6)*0.5+0.5)*h;
            const grad=ctx.createRadialGradient(wx,wy,0,wx,wy,step*4);
            grad.addColorStop(0,`hsla(${(hue+90)%360},100%,70%,${eng*0.45})`);
            grad.addColorStop(1,`hsla(${(hue+90)%360},100%,70%,0)`);
            ctx.globalAlpha=1; ctx.fillStyle=grad; ctx.fillRect(0,0,w,h);
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 33. شمس صوتية — شمس حقيقية مع كورونا وأشعة
    // ────────────────────────────────────────────────────
    'audio-sun': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, eng=_frameAvgEnergy;
        const baseR=35+eng*55+_beatPulse*15;
        const rounded=Math.round(baseR/5)*5;

        if(rounded!==_sunGradLastR){
            _sunGradLastR=rounded;
            _sunGradCache=ctx.createRadialGradient(cx,cy,0,cx,cy,baseR*1.4);
            _sunGradCache.addColorStop(0,'rgba(255,255,220,1)');
            _sunGradCache.addColorStop(0.25,'rgba(255,220,100,0.95)');
            _sunGradCache.addColorStop(0.6,'rgba(255,140,20,0.7)');
            _sunGradCache.addColorStop(1,'rgba(255,80,0,0)');
        }

        if(!DevicePerf.isLowEnd){
            const cg=ctx.createRadialGradient(cx,cy,baseR,cx,cy,baseR*2.5);
            cg.addColorStop(0,`rgba(255,150,20,${0.15+eng*0.22})`);
            cg.addColorStop(1,'rgba(255,80,0,0)');
            ctx.fillStyle=cg; ctx.beginPath(); ctx.arc(cx,cy,baseR*2.5,0,Math.PI*2); ctx.fill();
        }

        ctx.fillStyle=_sunGradCache;
        ctx.beginPath(); ctx.arc(cx,cy,baseR*1.4,0,Math.PI*2); ctx.fill();

        const rays=DevicePerf.isLowEnd?24:48;
        ctx.strokeStyle='rgba(255,200,80,0.65)';
        for (let i=0;i<rays;i++) {
            const ang=(i/rays)*Math.PI*2+time*0.08;
            const v=data.freq[Math.floor(i*bFreq/rays)]/255;
            const len=v*Math.min(cx,cy)*0.55;
            ctx.lineWidth=1+v*3; ctx.globalAlpha=0.3+v*0.6;
            ctx.beginPath();
            ctx.moveTo(cx+Math.cos(ang)*baseR*1.05, cy+Math.sin(ang)*baseR*1.05);
            ctx.lineTo(cx+Math.cos(ang)*(baseR*1.05+len), cy+Math.sin(ang)*(baseR*1.05+len));
            ctx.stroke();
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 34. معدن سائل — حلقات فضية تتموج كالمعدن المذاب
    // ────────────────────────────────────────────────────
    'liquid-metal': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2;
        const rings=DevicePerf.isLowEnd?3:5;
        const step=DevicePerf.isLowEnd?2:1;

        for (let j=0;j<rings;j++) {
            const R=Math.min(cx,cy)*(0.22+j*0.14), dist=18+j*5;
            const hue=195+j*12, sat=12+j*5, lum=52+j*7;
            const g=ctx.createLinearGradient(cx-R,cy,cx+R,cy);
            g.addColorStop(0,   `hsl(${hue},${sat}%,${lum-14}%)`);
            g.addColorStop(0.35,`hsl(${hue},${sat+12}%,${lum+22}%)`);
            g.addColorStop(0.65,`hsl(${hue},${sat+12}%,${lum+22}%)`);
            g.addColorStop(1,   `hsl(${hue},${sat}%,${lum-14}%)`);
            ctx.strokeStyle=g; ctx.lineWidth=3+j;
            _glow(ctx, `hsl(${hue},20%,88%)`, 5+_frameBassAvg*9);

            ctx.beginPath();
            const N=Math.floor(bFreq/step);
            for (let i=0;i<=N;i++) {
                const ang=(i/N)*Math.PI*2+time*0.3;
                const v=(i<N?data.freq[i*step]:data.freq[0])/255;
                const off=v*dist*Math.sin(time*1.8+j*1.3+i*0.1);
                const x=cx+Math.cos(ang)*(R+off), y=cy+Math.sin(ang)*(R+off);
                i===0?ctx.moveTo(x,y):ctx.lineTo(x,y);
            }
            ctx.closePath(); ctx.stroke();
        }
        _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 35. مربعات متزامنة — شبكة مربعات تتزامن مع البيت
    // ────────────────────────────────────────────────────
    'sync-squares': (ctx, data, time, w, h, bFreq) => {
        const cols=DevicePerf.isLowEnd?6:9, rows=DevicePerf.isLowEnd?5:7;
        const cw=w/cols, ch=h/rows;

        for (let r=0;r<rows;r++) {
            for (let c=0;c<cols;c++) {
                const idx=Math.floor((r*cols+c)/(cols*rows)*bFreq);
                const v=(_smoothedFreq?_smoothedFreq[idx]:data.freq[idx])/255;
                const sz=Math.min(cw,ch)*v*0.88*(1+_beatPulse*0.25);
                if(sz<1) continue;
                const hue=(c*35+r*25+time*50)%360;
                ctx.fillStyle=`hsl(${hue},90%,${45+v*30}%)`;
                ctx.globalAlpha=0.5+v*0.5;

                if(!DevicePerf.isLowEnd&&sz>6){
                    ctx.save();
                    ctx.translate(c*cw+cw/2,r*ch+ch/2);
                    ctx.rotate(time*0.4+c*0.2+r*0.15);
                    ctx.fillRect(-sz/2,-sz/2,sz,sz);
                    ctx.restore();
                } else {
                    ctx.fillRect(c*cw+(cw-sz)/2,r*ch+(ch-sz)/2,sz,sz);
                }
            }
        }
        ctx.globalAlpha=1;
    },

    // ────────────────────────────────────────────────────
    // 36. مسارات النجوم — نجوم بذيول طويلة كالتعرض الطويل
    // ────────────────────────────────────────────────────
    'star-trails': (ctx, data, time, w, h, bFreq) => {
        let sum=0; for(let i=0;i<10;i++) sum+=data.freq[i];
        const bass=sum/10, maxP=DevicePerf.maxParticles;
        const trailLen=DevicePerf.isLowEnd?14:30;

        if(bass>118&&Math.random()>0.8&&starTrailsParticles.length<maxP) {
            starTrailsParticles.push({
                x:w/2+(Math.random()-0.5)*w*0.3,
                y:h/2+(Math.random()-0.5)*h*0.3,
                angle:Math.random()*Math.PI*2,
                speed:1.5+Math.random()*4+_frameBassAvg*3,
                life:1, trail:[], hue:Math.random()*360, size:1+Math.random()*2,
            });
        }

        for (let i=starTrailsParticles.length-1;i>=0;i--) {
            const p=starTrailsParticles[i];
            p.trail.push({x:p.x,y:p.y});
            if(p.trail.length>trailLen) p.trail.shift();
            p.x+=Math.cos(p.angle)*p.speed;
            p.y+=Math.sin(p.angle)*p.speed;
            p.life-=0.008;
            if(p.life<=0||p.x<-20||p.x>w+20||p.y<-20||p.y>h+20){starTrailsParticles.splice(i,1);continue;}

            for (let j=1;j<p.trail.length;j++) {
                const a=(j/p.trail.length)*p.life;
                ctx.globalAlpha=a;
                ctx.strokeStyle=`hsl(${p.hue},100%,${60+a*25}%)`;
                ctx.lineWidth=p.size*(j/p.trail.length);
                _glow(ctx,`hsl(${p.hue},100%,70%)`,DevicePerf.isLowEnd?0:4*a);
                ctx.beginPath();
                ctx.moveTo(p.trail[j-1].x,p.trail[j-1].y);
                ctx.lineTo(p.trail[j].x,p.trail[j].y);
                ctx.stroke();
            }
            ctx.globalAlpha=p.life; ctx.fillStyle=`hsl(${p.hue},80%,95%)`;
            ctx.beginPath(); ctx.arc(p.x,p.y,p.size*1.5,0,Math.PI*2); ctx.fill();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 38. شفق قطبي — ستائر ضوئية تتموج كالأوروراBorealis
    // ────────────────────────────────────────────────────
    'aurora-curtain': (ctx, data, time, w, h, bFreq) => {
        const isLow = DevicePerf.isLowEnd;
        const cols = isLow ? 30 : 60;
        const step = w / cols;

        for (let i = 0; i < cols; i++) {
            const fi = Math.floor(i * bFreq / cols);
            const val = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            const x = i * step;

            // موجات متعددة الطبقات تُعطي عمق الشفق الحقيقي
            const wave1 = Math.sin(time*0.8 + i*0.22) * 0.3;
            const wave2 = Math.sin(time*1.4 + i*0.15 + 2) * 0.2;
            const wave3 = Math.sin(time*0.5 + i*0.35) * 0.15;
            const heightFactor = 0.3 + val*0.55 + wave1 + wave2 + wave3;

            const curtainH = heightFactor * h * 0.75;
            const topY = h*0.05 + (1 - heightFactor)*h*0.25;

            const hue1 = (120 + i*2.8 + time*18) % 360;
            const hue2 = (hue1 + 60) % 360;

            const g = ctx.createLinearGradient(x, topY, x, topY + curtainH);
            g.addColorStop(0,   `hsla(${hue1},100%,85%,0)`);
            g.addColorStop(0.2, `hsla(${hue1},100%,65%,${0.55 + val*0.3})`);
            g.addColorStop(0.6, `hsla(${hue2},100%,55%,${0.7 + val*0.25})`);
            g.addColorStop(1,   `hsla(${hue2},85%,35%,0)`);

            ctx.fillStyle = g;
            const bw = step * (0.8 + val*0.4);
            ctx.fillRect(x - bw*0.1, topY, bw, curtainH);

            // وميض خفيف على القمم
            if (!isLow && val > 0.6) {
                ctx.globalAlpha = (val - 0.6)*1.5 * (0.5 + 0.5*Math.sin(time*8+i));
                _glow(ctx, `hsl(${hue1},100%,90%)`, 8);
                ctx.fillStyle = `hsl(${hue1},100%,95%)`;
                ctx.beginPath(); ctx.arc(x + step*0.5, topY+4, 1.5, 0, Math.PI*2); ctx.fill();
            }
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 39. مطر الصوت — قطرات ملونة تنزل وتتناثر عند الارتطام
    // ────────────────────────────────────────────────────
    'sound-drops': (ctx, data, time, w, h, bFreq) => {
        const isLow = DevicePerf.isLowEnd;
        if (!_sdDrops)    _sdDrops    = [];
        if (!_sdSplashes) _sdSplashes = [];

        const MAX_DROPS   = isLow ? 60  : 140;
        const MAX_SPLASH  = isLow ? 80  : 200;
        const N           = isLow ? 20  : 40;

        // توليد قطرات جديدة — عتبة منخفضة وبدون احتياط
        for (let i = 0; i < N; i++) {
            const fi  = Math.floor(i * bFreq / N);
            const val = (_smoothedFreq ? _smoothedFreq[fi] : data.freq[fi]) / 255;
            // عتبة 0.15 بدلاً من 0.45 — تضمن ظهور المطر دائماً
            if (val > 0.15 && _sdDrops.length < MAX_DROPS && Math.random() < 0.55) {
                _sdDrops.push({
                    x     : (i / N) * w + (Math.random() - 0.5) * (w / N) * 2,
                    y     : -10,
                    speed : 4 + val * 10 + Math.random() * 3,
                    len   : 10 + val * 30,
                    hue   : (i / N * 360 + time * 45) % 360,
                    alpha : 0.55 + val * 0.45,
                    size  : 1.2 + val * 3,
                    val,
                });
            }
        }
        // احتياط: أضف قطرات عشوائية حتى لو الصوت هادئ
        if (_sdDrops.length < 8 && Math.random() < 0.35) {
            _sdDrops.push({
                x: Math.random() * w, y: -10,
                speed: 3 + Math.random() * 5,
                len: 12 + Math.random() * 18,
                hue: Math.random() * 360,
                alpha: 0.4, size: 1.5, val: 0.3,
            });
        }

        // تحريك القطرات ورسمها
        for (let i = _sdDrops.length - 1; i >= 0; i--) {
            const d = _sdDrops[i];
            d.y += d.speed;

            if (d.y - d.len > h) {
                // تناثر عند الارتطام
                if (_sdSplashes.length < MAX_SPLASH) {
                    const sc = isLow ? 3 : Math.floor(4 + d.size * 2);
                    for (let s = 0; s < sc; s++) {
                        const ang = -Math.PI + Math.random() * Math.PI;
                        _sdSplashes.push({
                            x: d.x, y: h - 2,
                            vx: Math.cos(ang) * (0.8 + Math.random() * 3.5),
                            vy: -(1.2 + Math.random() * 4.5),
                            life: 0.7 + Math.random() * 0.4,
                            hue: d.hue, size: 1 + Math.random() * 2,
                        });
                    }
                }
                _sdDrops.splice(i, 1);
                continue;
            }

            // رسم القطرة كخط بتدرج لوني
            const yTop = Math.max(-5, d.y - d.len);
            const grad = ctx.createLinearGradient(d.x, yTop, d.x, d.y);
            grad.addColorStop(0,   `hsla(${d.hue},100%,65%,0)`);
            grad.addColorStop(0.6, `hsla(${d.hue},100%,70%,${d.alpha * 0.6})`);
            grad.addColorStop(1,   `hsl(${d.hue},100%,80%)`);
            ctx.globalAlpha = d.alpha;
            _glow(ctx, `hsl(${d.hue},100%,70%)`, 5);
            ctx.strokeStyle = grad;
            ctx.lineWidth = d.size;
            ctx.lineCap = 'round';
            ctx.beginPath(); ctx.moveTo(d.x, yTop); ctx.lineTo(d.x, d.y); ctx.stroke();

            // نقطة لامعة عند رأس القطرة
            ctx.globalAlpha = d.alpha;
            ctx.fillStyle = `hsl(${d.hue},100%,88%)`;
            ctx.beginPath(); ctx.arc(d.x, d.y, d.size * 0.7, 0, Math.PI * 2); ctx.fill();
        }

        // رسم التناثر
        for (let i = _sdSplashes.length - 1; i >= 0; i--) {
            const s = _sdSplashes[i];
            s.x += s.vx; s.y += s.vy;
            s.vy += 0.18; s.vx *= 0.96;
            s.life -= 0.032;
            if (s.life <= 0) { _sdSplashes.splice(i, 1); continue; }
            ctx.globalAlpha = s.life * 0.9;
            _glow(ctx, `hsl(${s.hue},100%,70%)`, 4 * s.life);
            ctx.fillStyle = `hsl(${s.hue},100%,72%)`;
            ctx.beginPath(); ctx.arc(s.x, s.y, s.size * s.life, 0, Math.PI * 2); ctx.fill();
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 40. موجة الصدمة — انفجار دائري يتمدد من المركز مع كل ضربة
    // ────────────────────────────────────────────────────
    'shockwave': (ctx, data, time, w, h, bFreq) => {
        const isLow = DevicePerf.isLowEnd;
        if (!_shockwaves) _shockwaves = [];
        const cx = w/2, cy = h/2;
        const maxR = Math.hypot(cx, cy);

        let bassSum = 0;
        for (let i = 0; i < 6; i++) bassSum += data.freq[i];
        const bassNow = bassSum / 6 / 255;

        const beatReady = _beatPulse > 0.3;
        const timeReady = (time - _shockLastTime) > 1.5;
        if ((beatReady || timeReady) && _shockwaves.length < (isLow ? 5 : 10)) {
            _shockLastTime = time;
            const hue = (time * 70) % 360;
            const baseSpd = 5 + bassNow * 12 + _beatPulse * 8;
            _shockwaves.push({ r: 4, life: 1.0, hue, speed: baseSpd, width: 5 + _beatPulse*8, maxR, type: 'main' });
            if (!isLow) {
                _shockwaves.push({ r: 2, life: 0.8, hue: (hue+90)%360, speed: baseSpd*0.6, width: 2.5, maxR: maxR*0.75, type: 'inner' });
                if (_beatPulse > 0.5) {
                    _shockwaves.push({ r: 6, life: 0.65, hue: (hue+180)%360, speed: baseSpd*1.5, width: 1.5, maxR: maxR*0.55, type: 'fast' });
                }
            }
        }

        // ── النبض المركزي الدائم يستجيب للصوت ──
        const pulseR  = 10 + bassNow * 55 + Math.sin(time * 7) * 6 + _beatPulse * 20;
        const pulseHue = (time * 55) % 360;

        if (!isLow) {
            // توهج خارجي للنبضة
            const outerGrad = ctx.createRadialGradient(cx, cy, pulseR*0.5, cx, cy, pulseR*2.2);
            outerGrad.addColorStop(0, `hsla(${pulseHue},100%,65%,${0.15 + bassNow*0.2})`);
            outerGrad.addColorStop(1, `hsla(${pulseHue},100%,50%,0)`);
            ctx.fillStyle = outerGrad;
            ctx.globalAlpha = 1;
            ctx.beginPath(); ctx.arc(cx, cy, pulseR*2.2, 0, Math.PI*2); ctx.fill();
        }
        // حلقة النبض الرئيسية
        ctx.globalAlpha = 0.6 + bassNow * 0.4;
        _glow(ctx, `hsl(${pulseHue},100%,70%)`, 10 + _beatPulse*14);
        ctx.strokeStyle = `hsl(${pulseHue},100%,${60+bassNow*20}%)`;
        ctx.lineWidth = 2.5 + bassNow * 5;
        ctx.beginPath(); ctx.arc(cx, cy, pulseR, 0, Math.PI*2); ctx.stroke();
        // نقطة مركزية لامعة
        ctx.globalAlpha = 0.7 + _beatPulse * 0.3;
        ctx.fillStyle = `hsl(${pulseHue},100%,92%)`;
        ctx.beginPath(); ctx.arc(cx, cy, 4 + _beatPulse * 8, 0, Math.PI*2); ctx.fill();
        _clearGlow(ctx);

        // ── رسم موجات الصدمة ──
        for (let i = _shockwaves.length - 1; i >= 0; i--) {
            const sw = _shockwaves[i];
            sw.r    += sw.speed;
            sw.life -= sw.type === 'fast' ? 0.028 : (sw.type === 'inner' ? 0.020 : 0.015);
            if (sw.life <= 0 || sw.r > sw.maxR) { _shockwaves.splice(i, 1); continue; }

            const progress = sw.r / sw.maxR;
            const alpha    = sw.life * Math.pow(1 - progress, 0.5);
            if (alpha < 0.01) { _shockwaves.splice(i, 1); continue; }

            ctx.globalAlpha = Math.min(alpha, 1);
            const hue2 = (sw.hue + sw.r * 0.25) % 360;
            _glow(ctx, `hsl(${hue2},100%,70%)`, isLow ? 4 : 16 * sw.life);

            // الحلقة الرئيسية بسُمك يتلاشى
            ctx.strokeStyle = `hsl(${hue2},100%,${58 + sw.life*25}%)`;
            ctx.lineWidth   = sw.width * sw.life * (1 - progress * 0.6);
            ctx.beginPath(); ctx.arc(cx, cy, sw.r, 0, Math.PI * 2); ctx.stroke();

            // خطوط شعاعية حول الحلقة الرئيسية فقط
            if (!isLow && sw.type === 'main' && sw.life > 0.35) {
                const spokes = 16;
                ctx.lineWidth = 1.2;
                ctx.globalAlpha = alpha * 0.45;
                for (let s = 0; s < spokes; s++) {
                    const ang = (s / spokes) * Math.PI * 2 + sw.r * 0.008;
                    const rin = sw.r - sw.width * 1.5;
                    const rot = sw.r + sw.width * 1.5;
                    ctx.beginPath();
                    ctx.moveTo(cx + Math.cos(ang) * rin, cy + Math.sin(ang) * rin);
                    ctx.lineTo(cx + Math.cos(ang) * rot, cy + Math.sin(ang) * rot);
                    ctx.stroke();
                }
            }
        }
        ctx.globalAlpha = 1; _clearGlow(ctx);
    },

    // ────────────────────────────────────────────────────
    // 37. حلقات ديناميكية — حلقات تولد عند كل ضربة
    // ────────────────────────────────────────────────────
    'dynamic-rings': (ctx, data, time, w, h, bFreq) => {
        const cx=w/2, cy=h/2, maxP=Math.floor(DevicePerf.maxParticles/4);
        let sum2=0; for(let i=0;i<8;i++) sum2+=data.freq[i];
        const bass=sum2/8;

        if(bass>142&&time-lastBeat>0.27&&liveRipples.length<maxP){
            lastBeat=time;
            const hue=Math.random()*360;
            const numR=DevicePerf.isLowEnd?1:3;
            for(let k=0;k<numR;k++){
                liveRipples.push({r:k*14,life:1,width:1.5+(bass/255)*5,hue:(hue+k*30)%360,spd:2+k*0.8});
            }
        }

        for (let i=liveRipples.length-1;i>=0;i--) {
            const p=liveRipples[i];
            p.r+=p.spd; p.life-=0.012;
            if(p.life<=0){liveRipples.splice(i,1);continue;}
            ctx.globalAlpha=p.life*p.life;
            ctx.strokeStyle=`hsl(${p.hue},100%,${55+p.life*25}%)`;
            ctx.lineWidth=p.width*p.life;
            _glow(ctx,`hsl(${p.hue},100%,70%)`,DevicePerf.isLowEnd?0:14*p.life);
            ctx.beginPath(); ctx.arc(cx,cy,p.r,0,Math.PI*2); ctx.stroke();
        }
        ctx.globalAlpha=1; _clearGlow(ctx);
    },
};
