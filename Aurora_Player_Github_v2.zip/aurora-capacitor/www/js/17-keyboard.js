
document.addEventListener('DOMContentLoaded', () => {
    
    const eqToggle = document.getElementById('eqToggle');
    const resetEqBtn = document.getElementById('resetEqBtn');
    
    document.getElementById('randomBtn').addEventListener('click', toggleRandomPlayback);
        // === إعداد زر المؤثرات (نقر مفرد، مزدوج، 3 نقرات، ضغط مطول) ===
    const blossomBtnObj = document.getElementById('blossomToggle');

    const startBlossomPress = (e) => {
        if (e.type === 'mousedown' && e.button !== 0) return; // للماوس الأيسر فقط
        isBlossomLongPress = false;
        blossomPressTimer = setTimeout(() => {
            isBlossomLongPress = true;
            blossomClickCount = 0; // تصفير النقرات
            clearTimeout(blossomClickActionTimer);
            openVisualizerMenu();
        }, 500); // 500 مللي ثانية للضغط المطول
    };

    const cancelBlossomPress = () => {
        if (blossomPressTimer) {
            clearTimeout(blossomPressTimer);
            blossomPressTimer = null;
        }
    };

    blossomBtnObj.addEventListener('touchstart', startBlossomPress, { passive: true });
    blossomBtnObj.addEventListener('mousedown', startBlossomPress);
    blossomBtnObj.addEventListener('touchend', cancelBlossomPress);
    blossomBtnObj.addEventListener('mouseup', cancelBlossomPress);
    blossomBtnObj.addEventListener('mouseleave', cancelBlossomPress);
    blossomBtnObj.addEventListener('touchmove', cancelBlossomPress, { passive: true });

    blossomBtnObj.addEventListener('click', (e) => {
        // منع تنفيذ النقر العادي إذا كان المستخدم قد قام بضغط مطول
        if (isBlossomLongPress) {
            e.preventDefault();
            return;
        }

        blossomClickCount++;
        clearTimeout(blossomClickActionTimer);

        if (blossomClickCount >= 3) {
            // 3 نقرات: افتح القائمة فوراً
            blossomClickCount = 0;
            openVisualizerMenu();
        } else {
            // انتظار 300 مللي ثانية للتفريق بين النقر المفرد والمزدوج
            blossomClickActionTimer = setTimeout(() => {
                const count = blossomClickCount;
                blossomClickCount = 0;

                if (count === 1) {
                    handleBlossomSingleClick();
                } else if (count === 2) {
                    handleBlossomDoubleClick();
                }
            }, 300);
        }
    });

    document.getElementById('lyricsToggleBtn').addEventListener('click', toggleLyricsDisplay);
    document.getElementById('loopBtn').addEventListener('click', toggleLoopMode);
    document.getElementById('prevBtn').addEventListener('click', playPrevious);
    document.getElementById('playPauseBtn').addEventListener('click', togglePlayPause);
    document.getElementById('nextBtn').addEventListener('click', playNext);
    document.getElementById('sortButton').addEventListener('click', () => sortPlaylist());

    document.querySelectorAll('.close-overlay-btn').forEach(btn => {
        btn.addEventListener('click', () => history.back());
    });
    
    volumeSlider.addEventListener('input', handleVolumeChange);
    volumeBtn.addEventListener('click', toggleMute);

    document.getElementById('singleFileInput').addEventListener('change', (e) => handleFileSelection(e.target.files));
    document.getElementById('folderInput').addEventListener('change', (e) => handleFileSelection(e.target.files));
    playlistToggle.addEventListener('click', () => showOverlay('playlistOverlay'));
    infoBtn.addEventListener('click', () => showOverlay('infoOverlay'));
    
    if (eqToggle) {
        eqToggle.addEventListener('click', () => showOverlay('eqOverlay'));
    }
    if (resetEqBtn) {
        resetEqBtn.addEventListener('click', resetAllEq);
    }
    
   // تطبيق التأخير لمدة 300 ملي ثانية على حدث البحث لمنع تجميد المتصفح
searchInput.addEventListener('input', debounce((e) => {
    filterPlaylistOnly(e.target.value); 
}, 300));


    // ══ Seeking Logic (المرحلتان: بصري أثناء السحب، تطبيق عند الإفراج) ══
    // startSeeking  → يُفعّل وضع السحب ويُحدّث الشريط بصرياً فقط
    // duringSeeking → يُتابع تحديث الشريط بصرياً دون أي تغيير للصوت
    // stopSeeking   → يُطبّق موضع السحب على المشغّل مرة واحدة بعد الإفراج

    const startSeeking = (e) => {
        isSeeking = true;
        seekVisual(e);          // تحديث بصري فقط
        e.preventDefault();
    };

    const duringSeeking = (e) => {
        if (!isSeeking) return;
        seekVisual(e);          // تحديث بصري فقط
        e.preventDefault();     // منع التمرير أثناء سحب الشريط
    };

    const stopSeeking = () => {
        if (isSeeking) applySeek(); // ← التطبيق الفعلي مرة واحدة عند الإفراج
        isSeeking = false;
    };

    progressContainer.addEventListener('mousedown',  startSeeking,  { passive: false });
    document.addEventListener       ('mousemove',    duringSeeking);
    document.addEventListener       ('mouseup',      stopSeeking);

    progressContainer.addEventListener('touchstart', startSeeking,  { passive: false });
    // passive: false ضروري لـ touchmove حتى يعمل e.preventDefault() ويمنع تمرير الصفحة أثناء السحب
    document.addEventListener       ('touchmove',    duringSeeking, { passive: false });
    document.addEventListener       ('touchend',     stopSeeking);

    // Player event listeners
    audioPlayer.addEventListener('timeupdate', handleTimeUpdate);
    audioPlayer.addEventListener('loadedmetadata', handleTimeUpdate);
    audioPlayer.addEventListener('ended', playNext); 
        audioPlayer.addEventListener('play', () => {
        window.playbackErrorCount = 0; 
        updatePlayPauseBtn();
        updatePositionState(); // يضبط playbackState = 'playing' في الإشعار
        if (visualizerModeIndex !== -1 && animationFrameId === null) {
            visualize();
        }
    });

        audioPlayer.addEventListener('pause', () => {
        updatePlayPauseBtn();
        updatePositionState(); // يضبط playbackState = 'paused' في الإشعار
    });

    audioPlayer.addEventListener('error', handleMediaError);
    
    // تحسين: Event Delegation لقائمة التشغيل لتوفير الذاكرة
    // التعامل مع النقر على القائمة بأكملها بدلاً من كل عنصر
    playlistElement.addEventListener('click', (e) => {
        // --- أضف هذا الجزء في البداية تماماً ---
        if (isLongPressing) {
            isLongPressing = false; // تصفير الحالة للمرة القادمة
            e.preventDefault();
            e.stopPropagation();
            return; // توقف هنا ولا تشغل الأغنية
        }

        const item = e.target.closest('.playlist-item');
        if (!item) return;

        const index = parseInt(item.dataset.index);

        // التحقق مما إذا كان النقر على زر قائمة الانتظار
        if (e.target.classList.contains('queue-btn')) {
            e.stopPropagation();
            if (index === currentIndex) {
                showToast('هذه الأغنية تعمل الآن — لا يمكن إضافتها للانتظار', 'info', 2500);
                return;
            }
            toggleQueueState(index);
        } else {
            // النقر على العنصر نفسه للتشغيل
            selectTrack(index);
        }
    });

    // ═══════════════════════════════════════════════════════
    // نظام سحب وإفلات الملفات المحسَّن (Full-Page Drop Zone)
    // ═══════════════════════════════════════════════════════
    const dragOverlayEl = document.getElementById('drag-overlay');
    let dragDepth = 0; // عداد عمق الدخول لمنع الإغلاق الخاطئ عند مرور المؤشر على عناصر أبناء

    const showDragOverlay = () => {
        if (dragOverlayEl) {
            dragOverlayEl.classList.remove('drag-overlay-hidden');
        }
    };

    const hideDragOverlay = () => {
        dragDepth = 0;
        if (dragOverlayEl) {
            dragOverlayEl.classList.add('drag-overlay-hidden');
        }
    };

    // نستخدم document بدلاً من mainContent لتغطية كامل الصفحة
    document.addEventListener('dragenter', (e) => {
        // نتحقق أن السحب يحتوي على ملفات فعلاً
        if (e.dataTransfer && e.dataTransfer.types && e.dataTransfer.types.includes('Files')) {
            e.preventDefault();
            dragDepth++;
            if (dragDepth === 1) showDragOverlay();
        }
    });

    document.addEventListener('dragleave', (e) => {
        if (e.dataTransfer && e.dataTransfer.types && e.dataTransfer.types.includes('Files')) {
            dragDepth--;
            if (dragDepth <= 0) hideDragOverlay();
        }
    });

    document.addEventListener('dragover', (e) => {
        if (e.dataTransfer && e.dataTransfer.types && e.dataTransfer.types.includes('Files')) {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'copy';
        }
    });

    const handleDrop = async (e) => {
        e.preventDefault();
        hideDragOverlay();

        const items = e.dataTransfer.items;
        if (!items || items.length === 0) return;

        showToast('🔄 جارٍ فحص الملفات والمجلدات...', 'info', 5000);

        const promises = [];
        for (let i = 0; i < items.length; i++) {
            const entry = items[i].webkitGetAsEntry ? items[i].webkitGetAsEntry() : null;
            if (entry) {
                promises.push(scanFiles(entry).then(scannedFiles => {
                    // إعادة ضبط مسار الملف النسبي إذا كان متاحاً
                    scannedFiles.forEach(f => {
                        if (!f.customPath && entry.fullPath) {
                            f.customPath = f.name; // fallback
                        }
                    });
                    return scannedFiles;
                }));
            } else if (items[i].getAsFile) {
                const file = items[i].getAsFile();
                if (file) promises.push(Promise.resolve([file]));
            }
        }

        try {
            const nestedFiles = await Promise.all(promises);
            const allFiles = [].concat(...nestedFiles);

            // نمرر جميع أنواع الملفات المدعومة (صوت + صور + كلمات)
            const supportedFiles = allFiles.filter(f =>
                f.type.startsWith('audio/') ||
                f.type.startsWith('image/') ||
                f.name.toLowerCase().endsWith('.lrc') ||
                f.name.toLowerCase().endsWith('.srt')
            );

            const audioCount  = supportedFiles.filter(f => f.type.startsWith('audio/')).length;
            const imageCount  = supportedFiles.filter(f => f.type.startsWith('image/')).length;
            const lyricsCount = supportedFiles.filter(f =>
                f.name.toLowerCase().endsWith('.lrc') || f.name.toLowerCase().endsWith('.srt')
            ).length;

            if (supportedFiles.length > 0) {
                let summary = [];
                if (audioCount)  summary.push(`${audioCount} صوتي`);
                if (imageCount)  summary.push(`${imageCount} صورة`);
                if (lyricsCount) summary.push(`${lyricsCount} كلمات`);
                showToast(`تم اكتشاف: ${summary.join(' • ')}`, 'info', 3000);
                handleFileSelection(supportedFiles);
            } else {
                showToast('⚠️ لم يتم العثور على ملفات مدعومة في المحتوى المُسحب.', 'error');
            }
        } catch (err) {
            console.error('Drop error:', err);
            showToast('حدث خطأ أثناء قراءة الملفات.', 'error');
        }
    };

    document.addEventListener('drop', handleDrop);
    
    // ── Media Session API — تسجيل جميع أوامر التحكم من شاشة القفل والإشعارات ──
    if ('mediaSession' in navigator) {
        // أوامر التشغيل الأساسية
        navigator.mediaSession.setActionHandler('play',          togglePlayPause);
        navigator.mediaSession.setActionHandler('pause',         togglePlayPause);
        navigator.mediaSession.setActionHandler('previoustrack', playPrevious);
        navigator.mediaSession.setActionHandler('nexttrack',     playNext);

        // إيقاف التشغيل نهائياً (يُظهره بعض أنظمة أندرويد في الإشعار)
        navigator.mediaSession.setActionHandler('stop', () => {
            const player = getActivePlayer();
            if (player) { player.pause(); player.currentTime = 0; }
            updatePositionState();
        });

        // تقديم 10 ثوان (زر >> في بعض أجهزة أندرويد وسماعات البلوتوث)
        navigator.mediaSession.setActionHandler('seekforward', (details) => {
            const player = getActivePlayer();
            if (!player) return;
            const skip = details.seekOffset || 10;
            player.currentTime = Math.min(player.duration, player.currentTime + skip);
            updatePositionState();
        });

        // ترجيع 10 ثوان (زر << في بعض أجهزة أندرويد وسماعات البلوتوث)
        navigator.mediaSession.setActionHandler('seekbackward', (details) => {
            const player = getActivePlayer();
            if (!player) return;
            const skip = details.seekOffset || 10;
            player.currentTime = Math.max(0, player.currentTime - skip);
            updatePositionState();
        });

        // سحب شريط التقدم من شاشة القفل مباشرةً
        navigator.mediaSession.setActionHandler('seekto', (details) => {
            const player = getActivePlayer();
            if (!player) return;
            if (details.fastSeek && 'fastSeek' in player) {
                player.fastSeek(details.seekTime);
            } else {
                player.currentTime = details.seekTime;
            }
            updatePositionState();
        });
    }


        // محاولة الاستعادة التلقائية عند فتح التطبيق
    loadAndRestorePlaylist().then((success) => {
        // استعادة مؤقت النوم إن كان نشطاً قبل إغلاق الصفحة
        restoreSleepTimerState();

    });

    window.addEventListener('popstate', (event) => {
        const currentHash = window.location.hash;

        // إذا كانت قائمة السياق مفتوحة — أغلقها فقط بدون history.back إضافي
        if (contextMenuVisible) {
            _dismissContextMenu();
            // أعد إظهار الـ overlay السابق إذا كان في الحالة
            if (event.state && event.state.overlay && event.state.overlay !== 'contextMenu') {
                const prev = document.getElementById(event.state.overlay);
                if (prev) prev.style.display = 'flex';
            }
            return;
        }

        // إخفاء جميع الـ Overlays
        document.querySelectorAll('.overlay').forEach(el => {
            el.style.display = 'none';
        });

        // مسح البحث عند الخروج من قائمة التشغيل
        if (currentHash !== '#playlistOverlay') {
            if (searchInput.value !== '') {
                clearSearch();
            }
        }

        // إعادة إظهار الـ Overlay المخزَّن في الحالة (إن وُجد)
        if (event.state && event.state.overlay && event.state.overlay !== 'contextMenu') {
            const overlay = document.getElementById(event.state.overlay);
            if (overlay) overlay.style.display = 'flex';
        }
    });
    
   // حفظ الحالة عند إغلاق التطبيق أو وضعه في الخلفية (يدعم الهواتف والكمبيوتر)
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') {
        if (files.length > 0 && files[currentIndex]) {
            const player = getActivePlayer();
            // التقاط الثواني الأخيرة فوراً قبل إسبات المتصفح
            if (player && !player.paused) {
                localStorage.setItem('aurora_exact_time', player.currentTime);
            }
            savePlaylistState();
        }
    }
});

window.addEventListener('pagehide', () => {
    if (files.length > 0 && files[currentIndex]) {
        savePlaylistState();
    }
});

    
    const initialHash = window.location.hash;
    if (initialHash === '#playlistOverlay') {
        showOverlay('playlistOverlay');
    } else if (initialHash === '#infoOverlay') {
        showOverlay('infoOverlay');
    } else if (initialHash === '#eqOverlay') {
        showOverlay('eqOverlay');
    }
    
    createEqUI();
    createPresetsUI();
    loadEqSettings(); // **جديد: تحميل إعدادات المعادل المحفوظة**
    
    // في نهاية دالة التحميل في app.js
    handleVolumeChange(); // لضبط لون شريط الصوت عند البدء

// التحكم في الصوت باستخدام عجلة الماوس (نسخة مبسطة)
volumeContainer.addEventListener('wheel', function(e) {
    e.preventDefault();
    
    const step = 0.05;
    let newVolume = parseFloat(volumeSlider.value);
    
    // تحديد الاتجاه
    if (e.deltaY < 0) {
        newVolume += step; // تمرير لأعلى = زيادة الصوت
    } else {
        newVolume -= step; // تمرير لأسفل = خفض الصوت
    }
    
    // تحديد الحدود
    newVolume = Math.max(0, Math.min(1, newVolume));
    
    // تطبيق التغيير وتشغيل حدث التحديث
    volumeSlider.value = newVolume;
    handleVolumeChange();
    
}, { passive: false });

// ===============================================
// تحكم بلوحة المفاتيح (Keyboard Controls)
// ===============================================
function setupKeyboardControls() {
    document.addEventListener('keydown', (e) => {
        // تجاهل الأحداث إذا كان المستخدم يكتب في حقل إدخال
        const activeElement = document.activeElement;
        const isInputFocused = activeElement && (
            activeElement.tagName === 'INPUT' || 
            activeElement.tagName === 'TEXTAREA' || 
            activeElement.isContentEditable
        );
        
        if (isInputFocused) {
            // إذا كان في حقل البحث، نسمح فقط بمفاتيح معينة
            if (activeElement.id === 'searchInput') {
                // مفتاح Escape لإغلاق البحث
                if (e.key === 'Escape') {
                    clearSearch();
                    activeElement.blur();
                    e.preventDefault();
                }
                return;
            }
            return; // تجاهل المفاتيح في حقول الإدخال الأخرى
        }

        // السماح باختصارات النظام (Ctrl, Meta, Alt) بالمرور بشكل طبيعي
        // مثل: Ctrl+R للتحديث، Ctrl+T لتبويب جديد، Cmd+Q للإغلاق
        if (e.ctrlKey || e.metaKey || e.altKey) return;

        // منع السلوك الافتراضي للمفاتيح التي نستخدمها
        e.preventDefault();
        
        switch(e.key.toLowerCase()) {
            case ' ': // مفتاح المسافة
                togglePlayPause();
                break;
                
            case 'arrowright':
            case 'l': // حرف L للإنجليزي
            case 'ذ': // حرف الذال للعربي (كنت متأكدًا أنه يساوي السهم لليمين في بعض الأنظمة)
                playNext();
                break;
                
            case 'arrowleft':
            case 'j': // حرف J للإنجليزي
            case 'ت': // حرف التاء للعربي (كنت متأكدًا أنه يساوي السهم لليسار في بعض الأنظمة)
                playPrevious();
                break;
                
            case 'arrowup':
                // زيادة الصوت
                volumeSlider.value = Math.min(1, parseFloat(volumeSlider.value) + 0.05);
                handleVolumeChange();
                showToast(`الصوت: ${Math.round(parseFloat(volumeSlider.value) * 100)}%`, 'info', 1000);
                break;
                
            case 'arrowdown':
                // خفض الصوت
                volumeSlider.value = Math.max(0, parseFloat(volumeSlider.value) - 0.05);
                handleVolumeChange();
                showToast(`الصوت: ${Math.round(parseFloat(volumeSlider.value) * 100)}%`, 'info', 1000);
                break;
                
            case 'm': // كتم الصوت
                toggleMute();
                break;
                
            case 'r': // تشغيل عشوائي
                toggleRandomPlayback();
                break;
                
            case 'o': // تكرار (Loop)
                toggleLoopMode();
                break;
                
            case 'f': // ملء الشاشة
                if (typeof window.toggleFullscreenMode === 'function') {
                    window.toggleFullscreenMode();
                } else {
                    // fallback إذا لم يتحمّل الملف بعد
                    const mediaContainer = document.getElementById('mediaContainer');
                    if (document.fullscreenElement) {
                        document.exitFullscreen();
                    } else if (mediaContainer && mediaContainer.requestFullscreen) {
                        mediaContainer.requestFullscreen();
                    }
                }
                break;
                
            case 'b': // مؤثرات بصرية (Blossom)
                toggleBlossom();
                break;
                
            case 'y': // إظهار/إخفاء الكلمات
                toggleLyricsDisplay();
                break;
                
            case 's': // فرز القائمة
                sortPlaylist();
                break;
                
            case 'p': // فتح قائمة التشغيل
                showOverlay('playlistOverlay');
                break;
                
            case 'i': // فتح معلومات
                showOverlay('infoOverlay');
                break;
                
            case 'e': // فتح معادل الصوت
                showOverlay('eqOverlay');
                break;
                
            case 'escape': // إغلاق الـ Overlay المفتوح
                // إذا كانت قائمة السياق مفتوحة، نتركها تتعامل مع ESC بنفسها
                // لمنع استدعاء history.back() مرتين
                if (contextMenuVisible) break;
                
                const overlays = document.querySelectorAll('.overlay');
                let overlayClosed = false;
                overlays.forEach(overlay => {
                    if (overlay.style.display === 'flex') {
                        overlay.style.display = 'none';
                        overlayClosed = true;
                        
                        // إذا كانت قائمة التشغيل، امسح البحث
                        if (overlay.id === 'playlistOverlay') {
                            clearSearch();
                        }
                    }
                });
                if (overlayClosed) {
                    history.back();
                }
                break;
                
            case '0': // الانتقال لبداية الملف
                const player = getActivePlayer();
                if (player) {
                    player.currentTime = 0;
                    showToast('⏮️ العودة إلى البداية', 'info', 1000);
                }
                break;
                
            case '1': // تقديم 10 ثواني
                if (audioPlayer) {
                    audioPlayer.currentTime = Math.min(audioPlayer.duration, audioPlayer.currentTime + 10);
                    showToast('⏩ تقديم 10 ثواني', 'info', 1000);
                }
                break;
                
            case '2': // ترجيع 10 ثواني
                if (audioPlayer) {
                    audioPlayer.currentTime = Math.max(0, audioPlayer.currentTime - 10);
                    showToast('⏪ ترجيع 10 ثواني', 'info', 1000);
                }
                break;
                
            case '?': // عرض مساعدة لوحة المفاتيح
                showKeyboardHelp();
                break;
        }
    });
}

// ===============================================
// عرض مساعدة لوحة المفاتيح
// ===============================================
function showKeyboardHelp() {
    const helpMessage = `
    ⚡ أوامر لوحة المفاتيح:
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    
    ▶️ تشغيل/إيقاف: مفتاح المسافة (Space)
    ⏭️ التالي: السهم لليمين (→) أو حرف L
    ⏮️ السابق: السهم لليسار (←) أو حرف J
    🔊 زيادة الصوت: السهم لأعلى (↑)
    🔈 خفض الصوت: السهم لأسفل (↓)
    🔇 كتم/إعادة الصوت: M
    
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    
    🔀 تشغيل عشوائي: R
    🔁 تكرار: O
    🌸 المؤثرات البصرية: B
    📜 الكلمات: Y
    ↖️ وضع ملئ الشاشه: F
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    
    📋 قائمة التشغيل: P
    ℹ️ المعلومات: I
    🎛️ معادل الصوت: E
    🚪 إغلاق النوافذ: Escape
    
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    
    ⏩ تقديم 10 ثواني: 1
    ⏪ ترجيع 10 ثواني: 2
    ⏮️ البداية: 0
    📖 المساعدة: ?
    
    ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬
    `;
    
    // إنشاء عنصر لعرض المساعدة
    const helpOverlay = document.createElement('div');
    helpOverlay.id = 'keyboardHelpOverlay';
    helpOverlay.className = 'overlay';
    helpOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.9);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        backdrop-filter: blur(5px);
    `;
    
    const helpContent = document.createElement('div');
    helpContent.style.cssText = `
        background: var(--card-bg);
        padding: 30px;
        border-radius: 20px;
        max-width: 90%;
        max-height: 80%;
        overflow-y: auto;
        border: 2px solid var(--accent-color);
        box-shadow: 0 0 30px rgba(0, 150, 255, 0.5);
        color: white;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        white-space: pre-line;
        text-align: center;
    `;
    
    helpContent.innerHTML = helpMessage;
    
    const closeBtn = document.createElement('button');
    closeBtn.textContent = '✕';
    closeBtn.style.cssText = `
        position: absolute;
        top: 15px;
        right: 15px;
        background: var(--accent-color);
        color: white;
        border: none;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        font-size: 20px;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: all 0.3s;
    `;
    
    closeBtn.onmouseover = () => closeBtn.style.transform = 'scale(1.1)';
    closeBtn.onmouseout = () => closeBtn.style.transform = 'scale(1)';
    closeBtn.onclick = () => helpOverlay.remove();
    
    helpContent.appendChild(closeBtn);
    helpOverlay.appendChild(helpContent);
    
    // إغلاق بالضغط على Escape
    helpOverlay.onkeydown = (e) => {
        if (e.key === 'Escape') helpOverlay.remove();
    };
    
    document.body.appendChild(helpOverlay);
    
    // التركيز على الـ overlay للاستماع للأحداث
    helpOverlay.focus();
    
    // إظهار رسالة توضيحية
    showToast('تم عرض مساعدة لوحة المفاتيح', 'info');
}
    // أضف هذا السطر في نهاية الحدث:
    setupKeyboardControls();

        // ===============================================
    // التحكم بالإيماءات (Swipe Gestures)
    // ===============================================
    let swipeTouchStartY = 0;
    let swipeTouchEndY = 0;
    const minSwipeDistance = 50;

    // 1. سحب الشريط السفلي للأعلى -> لفتح القائمة
    if (bottomSection) {
        bottomSection.addEventListener('touchstart', (e) => {
            swipeTouchStartY = e.changedTouches[0].screenY;
        }, {passive: true});

        bottomSection.addEventListener('touchend', (e) => {
            swipeTouchEndY = e.changedTouches[0].screenY;
            if (swipeTouchStartY - swipeTouchEndY > minSwipeDistance) {
                showOverlay('playlistOverlay');
            }
        }, {passive: true});
    }

    // 2. سحب القائمة للأسفل -> لإغلاق القائمة
    if (playlistOverlay) {
        playlistOverlay.addEventListener('touchstart', (e) => {
            swipeTouchStartY = e.changedTouches[0].screenY;
        }, {passive: true});

        playlistOverlay.addEventListener('touchend', (e) => {
            swipeTouchEndY = e.changedTouches[0].screenY;
            const distance = swipeTouchEndY - swipeTouchStartY;
            const isTouchingList = e.target.closest('#playlist');

            if (distance > minSwipeDistance) {
                if (!isTouchingList || playlistElement.scrollTop === 0) {
                     hideOverlay('playlistOverlay');
                }
            }
        }, {passive: true});
    }

    // ===============================================
    // برمجة أزرار القائمة الجديدة (إضافة / مسح)
    // ===============================================

    const addFilesBtn = document.getElementById('addFilesBtn');
    const clearPlaylistBtn = document.getElementById('clearPlaylistBtn');

    // 1. زر إضافة ملفات
    if (addFilesBtn) {
        addFilesBtn.addEventListener('click', () => {
            // محاكاة النقر على مدخل الملفات الموجود مسبقاً
            // ملاحظة: سيقوم كود handleFileSelection الموجود بدمج الملفات تلقائياً
            document.getElementById('singleFileInput').click();
        });
    }

    // 2. زر مسح القائمة
       if (clearPlaylistBtn) {
        clearPlaylistBtn.addEventListener('click', async () => {
            if (files.length === 0) return;

            // استخدام النافذة المخصصة
            showCustomConfirm('هل أنت متأكد من مسح جميع الأغاني من القائمة بشكل نهائي؟', async () => {
                
                audioPlayer.pause();
                audioPlayer.removeAttribute('src'); 
                audioPlayer.load(); 

                if (currentAudioBlobUrl) {
                    URL.revokeObjectURL(currentAudioBlobUrl);
                    currentAudioBlobUrl = null;
                }
                
                BlobManager.cleanupAll();

                files = [];
                allUploadedFiles = [];
                fileQueue = [];
                shuffledIndices = [];
                currentIndex = 0;
                
                coverMap.clear();  
                lyricsMap.clear(); 

                await dbManager.clear();
                
                renderPlaylist();
                trackTitleEl.textContent = "اختر أغنية";
                trackArtistEl.textContent = "تم مسح القائمة";
                currentTimeEl.textContent = "0:00";
                durationTimeEl.textContent = "0:00";
                bar.style.transform = `translateX(-100%)`;
                
                coverArt.style.display = 'none';
                coverArt.src = '';
                defaultIcon.style.display = 'flex';
                
                msClear();        // ← مسح إشعار شاشة القفل
                resetThemeColor(); // ← إعادة اللون الافتراضي للمشغل
                updateButtonStates();
                
                showToast('🗑️ تم مسح القائمة بنجاح', 'info');
            });
        });
    }

// ===============================================
// إعداد أحداث قائمة السياق
// ===============================================

const closeContextMenuBtn = document.getElementById('closeContextMenu');
if (closeContextMenuBtn) {
    closeContextMenuBtn.addEventListener('click', hideContextMenuAndGoBack);
}

// إغلاق قائمة السياق عند النقر على الخلفية
const contextBackdropEl = document.getElementById('contextBackdrop');
if (contextBackdropEl) {
    contextBackdropEl.addEventListener('click', hideContextMenuAndGoBack);
}

// إغلاق قائمة السياق عند النقر خارجها (الخلفية لها معالجها الخاص)
document.addEventListener('click', (e) => {
    if (isLongPressing) {
        isLongPressing = false;
        return;
    }
    const contextMenu = document.getElementById('contextMenu');
    const contextBackdropEl2 = document.getElementById('contextBackdrop');
    if (contextMenuVisible && contextMenu &&
        !contextMenu.contains(e.target) &&
        e.target !== contextBackdropEl2 &&
        !e.target.closest('.playlist-item') &&
        !e.target.classList.contains('queue-btn')) {
        hideContextMenuAndGoBack();
    }
});

// إغلاق قائمة السياق بمفتاح Escape
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && contextMenuVisible) {
        hideContextMenuAndGoBack();
    }
});

// === معالج نقرات قائمة السياق — click فقط (بدون touchend) ===
// .context-item تحتوي على touch-action:manipulation في CSS
// → المتصفح يُلغي تأخير 300ms تلقائياً → click سريع بدون أي تحذير
document.querySelectorAll('.context-item').forEach(item => {
    item.addEventListener('click', (e) => {
        if (isLongPressing) {
            isLongPressing = false;
            return;
        }
        e.stopPropagation();
        const action = item.getAttribute('data-action');
        item.style.backgroundColor = 'rgba(255, 255, 255, 0.2)';
        setTimeout(() => {
            item.style.backgroundColor = '';
            handleContextMenuAction(action);
        }, 50);
    });
});

// إعداد أحداث الضغط المطول
setupLongPressEvents();

// إعداد السحب للأسفل لإغلاق قائمة السياق
setupContextMenuSwipe();

// إعداد الإيماء على غلاف الأغنية (سحب لليمين/يسار لتغيير المقطع)
setupCoverSwipeGesture();

// أغلق حدث DOMContentLoaded هنا أولاً
});
