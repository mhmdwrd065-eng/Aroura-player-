
// ===============================================
// وظائف معالجة الملفات والتحميل
// ===============================================

// ===============================================
// دالة فحص الملفات المحسنة (Non-Blocking)
// ===============================================
// استبدل دالة scanFiles الحالية بهذه النسخة المحسنة
async function scanFiles(item) {
    const allFiles = [];
    
    // حماية ضد العناصر الفارغة أو غير المعرَّفة
    if (!item) return allFiles;

    // التعامل مع Entry API (Standard & Webkit)
    if (item.isFile) {
        return new Promise((resolve) => {
            item.file((file) => {
                resolve([file]);
            }, (err) => {
                console.warn("فشل قراءة الملف:", err);
                resolve([]);
            });
        });
    } 
    else if (item.isDirectory) {
        const dirReader = item.createReader();
        
        // قراءة محتويات المجلد (يجب القراءة في حلقة تكرارية لأن بعض المتصفحات تعيد 100 ملف فقط في المرة الواحدة)
        const readEntries = async () => {
            return new Promise((resolve, reject) => {
                dirReader.readEntries((results) => {
                    resolve(results);
                }, (err) => reject(err));
            });
        };

        try {
            let batch;
            do {
                batch = await readEntries();
                if (batch.length > 0) {
                    // معالجة كل عنصر بشكل متوازي
                    const promises = batch.map(entry => scanFiles(entry));
                    const results = await Promise.all(promises);
                    results.forEach(files => allFiles.push(...files));
                }
            } while (batch.length > 0);
        } catch (error) {
            console.error("Error reading directory:", error);
        }
    }
    
    return allFiles;
}

// ===============================================
// دالة معالجة اختيار الملفات (تم التعديل لحفظ الصور)
// ===============================================
async function handleFileSelection(uploadedFiles) {
    if (uploadedFiles.length === 0) return;

    // تحويل FileList إلى مصفوفة
    let newFilesList = Array.from(uploadedFiles);
    
    // (تعديل 1) السماح بمرور الصور أيضاً للحفظ في القاعدة
    // نقبل الصوتيات + الصور (jpg, png, etc) + ملفات الكلمات
    const audioAndImageFiles = newFilesList.filter(f => 
        f.type.startsWith('audio/') || 
        f.type.startsWith('image/')
    );

    // بناء مجموعة أسماء الأغاني المتاحة (من الملفات المرفوعة + القائمة الحالية)
    const availableAudioBaseNames = new Set([
        // أسماء الأغاني في الملفات المرفوعة الحالية
        ...newFilesList
            .filter(f => f.type.startsWith('audio/'))
            .map(f => f.name.substring(0, f.name.lastIndexOf('.'))),
        // أسماء الأغاني الموجودة مسبقاً في القائمة
        ...files.map(f => f.name.substring(0, f.name.lastIndexOf('.')))
    ]);

    // قبول ملفات الكلمات فقط إذا كان هناك أغنية بنفس الاسم
    const lyricsFiles = newFilesList.filter(f => {
        if (!f.name.endsWith('.lrc') && !f.name.endsWith('.srt')) return false;
        const baseName = f.name.substring(0, f.name.lastIndexOf('.'));
        const hasMatchingAudio = availableAudioBaseNames.has(baseName);
        if (!hasMatchingAudio) {
            console.info(`تم تجاهل ملف الكلمات بدون أغنية مطابقة: ${f.name}`);
        }
        return hasMatchingAudio;
    });

    const skippedLyrics = newFilesList.filter(f => 
        (f.name.endsWith('.lrc') || f.name.endsWith('.srt')) && 
        !lyricsFiles.includes(f)
    ).length;

    if (skippedLyrics > 0) {
        showToast(`تم تجاهل ${skippedLyrics} ملف كلمات بدون أغنية مطابقة`, 'info', 3000);
    }

    const validFiles = [...audioAndImageFiles, ...lyricsFiles];
    
    // استخراج الصوتيات فقط لإضافتها للقائمة
    const newAudioFiles = validFiles.filter(f => f.type.startsWith('audio/'));
    
    if (validFiles.length > 0) {
        try {
            showToast(`جاري معالجة ${validFiles.length} ملف... يرجى الانتظار`, 'info', 3000);

            trackTitleEl.textContent = "جاري الحفظ...";
            trackArtistEl.textContent = "0%";

            // (تعديل 2) حفظ كل الملفات (صوت وصور) في قاعدة البيانات
            await dbManager.saveAudioFiles(validFiles, (saved, total) => {
                const percent = Math.round((saved / total) * 100);
                trackArtistEl.textContent = `${percent}% مكتمل (${saved}/${total})`;
            });
            
            // إضافة وقت الإضافة
            newAudioFiles.forEach(f => { 
                if(!f.timeAdded) f.timeAdded = Date.now(); 
            });

            // دمج الصوتيات الجديدة مع القائمة الحالية
            const uniqueNewAudio = newAudioFiles.filter(newFile => {
                // نتحقق مما إذا كان الملف موجوداً بالفعل بناءً على الاسم والحجم
                const isDuplicate = files.some(existingFile => 
                    existingFile.name === newFile.name && existingFile.size === newFile.size
                );
                
                if (isDuplicate) {
                    console.warn(`تم تجاهل الملف المكرر: ${newFile.name}`);
                }
                
                return !isDuplicate;
            });

            if (uniqueNewAudio.length === 0 && newAudioFiles.length > 0) {
                 showToast('جميع الملفات المختارة موجودة بالفعل!', 'info');
                 // استعادة النص الصحيح بدلاً من تركه على "جاري الحفظ..."
                 if (files[currentIndex]) {
                     updateTrackInfo(files[currentIndex]);
                 } else {
                     trackTitleEl.textContent = "اختر أغنية";
                     trackArtistEl.textContent = "اسحب وأفلت الملفات هنا للبدء";
                 }
                 return;
            }
         
            if (files.length === 0) {
                files = newAudioFiles; // القائمة تحتوي صوتيات فقط
                // (تعديل 3) بناء خريطة الصور باستخدام كل الملفات المرفوعة
                buildFileMaps(validFiles); 
                renderPlaylist();
                playFile(files[0]);
                showToast(`تم حفظ ${validFiles.length} ملف بنجاح!`, 'success');
            } else if (uniqueNewAudio.length > 0) {
                files = [...files, ...uniqueNewAudio];
                
                buildFileMaps(validFiles);

                // تحديث قائمة العشوائية بذكاء — إدراج الأغاني الجديدة دون إعادة توليد القائمة
                if (isRandomPlayback) {
                    const prevCount = files.length - uniqueNewAudio.length;
                    const newIndices = Array.from({length: uniqueNewAudio.length}, (_, i) => prevCount + i);
                    insertNewFilesIntoShuffleList(newIndices);
                }

                renderPlaylist();
                showToast(`تم إضافة ${uniqueNewAudio.length} أغنية جديدة!`, 'success');
            } else {
                // حتى لو لم تكن هناك أغاني جديدة، قد تكون هناك صور جديدة
                buildFileMaps(validFiles);
                showToast('تم تحديث الملفات والصور.', 'info');
            }

            if(files[currentIndex]) updateTrackInfo(files[currentIndex]);

            savePlaylistState();

        } catch (err) {
            console.error("Quota Exceeded or DB Error:", err);
            trackArtistEl.textContent = "فشل الحفظ!";
            showToast('⚠️ مساحة التخزين ممتلئة أو حدث خطأ.', 'error');
        }
    } else {
        showToast('لم يتم العثور على ملفات مدعومة.', 'error');
    }
}

