// ===============================================
// دوال إدارة قائمة السياق
// ===============================================

// ── داخلية: تُخفي الواجهة فقط بدون أي تعامل مع سجل التصفح ──
function _dismissContextMenu() {
    const contextMenu = document.getElementById('contextMenu');
    const contextBackdrop = document.getElementById('contextBackdrop');
    if (contextMenu) contextMenu.classList.remove('show');
    if (contextBackdrop) contextBackdrop.classList.remove('show');
    contextMenuVisible = false;
    currentContextIndex = -1;
    document.body.style.overflow = '';
}

// ── تُخفي القائمة وتُنظّف الـ hash بصمت (replaceState لا يُطلق popstate) ──
// تستبدل سجل #contextMenu بـ #playlistOverlay حتى يعمل زر رجوع هاتف بشكل صحيح
// (الرجوع من trackInfoOverlay → يُعيد playlistOverlay وليس صفحة فارغة)
function hideContextMenu() {
    _dismissContextMenu();
    if (window.location.hash === '#contextMenu') {
        // نستبدل سجل القائمة بسجل قائمة التشغيل (التي كانت مفتوحة خلف القائمة)
        history.replaceState(
            { overlay: 'playlistOverlay' },
            '',
            '#playlistOverlay'
        );
    }
}

// ── تُخفي القائمة وترجع في التاريخ — تُستخدم بزر X والخلفية فقط ──
function hideContextMenuAndGoBack() {
    _dismissContextMenu();
    if (window.location.hash === '#contextMenu') {
        history.back();
    }
}

// إظهار قائمة السياق
function showContextMenu(index, x, y) {
    currentContextIndex = index;
    const contextMenu = document.getElementById('contextMenu');
    const contextBackdrop = document.getElementById('contextBackdrop');
    const contextMenuTitle = document.getElementById('contextMenuTitle');

    if (!contextMenu || index < 0 || index >= files.length) return;

    const fileName = files[index].name.substring(0, files[index].name.lastIndexOf('.'));
    contextMenuTitle.textContent = fileName.length > 25 ? fileName.substring(0, 25) + '...' : fileName;

    updateContextMenuButtons(index);

    if (contextBackdrop) contextBackdrop.classList.add('show');

    // إعادة ضبط أي تحويل متبقٍّ من سحب سابق قبل إظهار القائمة
    contextMenu.style.transition = '';
    contextMenu.style.transform  = '';

    requestAnimationFrame(() => {
        contextMenu.classList.add('show');
    });

    contextMenuVisible = true;

    if (window.location.hash !== '#contextMenu') {
        history.pushState({ overlay: 'contextMenu' }, '', '#contextMenu');
    }

    const playlistItem = playlistElement.querySelector(`.playlist-item[data-index="${index}"]`);
    if (playlistItem) {
        playlistItem.classList.add('long-press');
        setTimeout(() => playlistItem.classList.remove('long-press'), 500);
    }

    document.body.style.overflow = 'hidden';
}

// تحديث أزرار قائمة السياق بناءً على الحالة
function updateContextMenuButtons(index) {
    const addTopBtn    = document.querySelector('.context-item[data-action="addToQueueTop"]');
    const addEndBtn    = document.querySelector('.context-item[data-action="addToQueue"]');
    const removeQueueBtn = document.querySelector('.context-item[data-action="removeFromQueue"]');
    const deleteBtn    = document.querySelector('.context-item[data-action="delete"]');

    const isInQueue   = fileQueue.includes(index);
    const isAtTop     = fileQueue.length > 0 && fileQueue[0] === index;
    const queuePos    = fileQueue.indexOf(index);
    const isPlaying   = index === currentIndex;

    // ── إذا كانت هي الأغنية الحالية — نُخفي كل خيارات الانتظار ونُظهر تنبيهاً ──
    if (isPlaying) {
        if (addTopBtn)      addTopBtn.style.display    = 'none';
        if (addEndBtn)      addEndBtn.style.display    = 'none';
        if (removeQueueBtn) removeQueueBtn.style.display = 'none';
        // نُظهر تلميحاً داخل قائمة السياق نفسها
        let nowPlayingHint = document.getElementById('contextNowPlayingHint');
        if (!nowPlayingHint) {
            nowPlayingHint = document.createElement('li');
            nowPlayingHint.id = 'contextNowPlayingHint';
            nowPlayingHint.className = 'context-item context-hint';
            nowPlayingHint.style.cssText = 'opacity:0.55; cursor:default; font-size:13px; gap:8px;';
            nowPlayingHint.innerHTML = '<span class="context-icon"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></span><span class="context-text">تعمل الآن — لا يمكن إضافتها للانتظار</span>';
            // ندرجه بعد زر التشغيل مباشرة
            const playBtn = document.querySelector('.context-item[data-action="play"]');
            if (playBtn && playBtn.parentNode) playBtn.after(nowPlayingHint);
        }
        nowPlayingHint.style.display = 'flex';
        if (deleteBtn) deleteBtn.style.display = 'flex';
        return;
    }

    // إخفاء التلميح إن كان مرئياً من أغنية سابقة
    const existingHint = document.getElementById('contextNowPlayingHint');
    if (existingHint) existingHint.style.display = 'none';

    if (isInQueue) {
        // الأغنية موجودة بالفعل في قائمة الانتظار
        if (addTopBtn) {
            // إذا لم تكن في الأول، أعطِ خيار ترقيتها لأوّل الانتظار
            if (!isAtTop) {
                addTopBtn.style.display = 'flex';
                addTopBtn.querySelector('.context-text').textContent = 'تقديمها لأول الانتظار';
            } else {
                addTopBtn.style.display = 'none';
            }
        }
        if (addEndBtn)      addEndBtn.style.display = 'none';
        if (removeQueueBtn) {
            removeQueueBtn.style.display = 'flex';
            // نُظهر الموضع الحالي في زر الإزالة
            const posText = removeQueueBtn.querySelector('.context-text');
            if (posText) posText.textContent = `إزالة من الانتظار (#${queuePos + 1})`;
        }
    } else {
        // الأغنية غير موجودة في قائمة الانتظار
        if (addTopBtn) {
            addTopBtn.style.display = 'flex';
            addTopBtn.querySelector('.context-text').textContent = 'إضافة إلى أول الانتظار';
        }
        if (addEndBtn)      addEndBtn.style.display = fileQueue.length > 0 ? 'flex' : 'none';
        if (removeQueueBtn) removeQueueBtn.style.display = 'none';
    }

    if (deleteBtn) deleteBtn.style.display = 'flex';
}

// ── نظام السحب للأسفل لإغلاق قائمة السياق (Swipe-to-Dismiss) ──
// يُفعَّل عند إضافة القائمة للـ DOM (مرة واحدة فقط عبر DOMContentLoaded)
function setupContextMenuSwipe() {
    const contextMenu = document.getElementById('contextMenu');
    const contextList = document.getElementById('contextMenu')?.querySelector('.context-menu-list');
    if (!contextMenu) return;

    // ────────── الثوابت ──────────
    const DISMISS_THRESHOLD = 80;   // البيكسلات اللازمة لتأكيد الإغلاق
    const DISMISS_VELOCITY  = 0.4;  // السرعة الكافية للإغلاق حتى دون تجاوز العتبة (px/ms)

    // ────────── الحالة الداخلية ──────────
    let dragStartY   = 0;
    let lastY        = 0;
    let lastTime     = 0;
    let currentDY    = 0;
    let isDragging   = false;
    let velocityY    = 0;

    // ─── هل القائمة مُمرَّرة للأعلى؟ (نمنع السحب حتى نصل لأعلى القائمة) ───
    function isListScrolled() {
        const list = contextMenu.querySelector('.context-menu-list');
        return list ? list.scrollTop > 2 : false;
    }

    // ─── تطبيق الترجمة أثناء السحب (بدون transition للاستجابة الفورية) ───
    function applyDrag(dy) {
        // نسمح فقط بالسحب للأسفل (dy موجب)
        const clampedDY = Math.max(0, dy);
        contextMenu.style.transition = 'none';
        contextMenu.style.transform  = `translateY(${clampedDY}px)`;

        // تلاشٍ تدريجي للخلفية بالتزامن مع السحب
        const backdrop = document.getElementById('contextBackdrop');
        if (backdrop) {
            const menuHeight = contextMenu.offsetHeight || 300;
            const progress   = Math.min(clampedDY / menuHeight, 1);
            backdrop.style.opacity = String(1 - progress * 0.8);
        }
    }

    // ─── إعادة القائمة لوضعها الطبيعي بحركة نعمة ───
    function snapBack() {
        contextMenu.style.transition = '';   // إعادة CSS transition الأصلي
        contextMenu.style.transform  = '';   // إعادة الحالة لـ .show (translateY(0))
        // إعادة opacity الخلفية
        const backdrop = document.getElementById('contextBackdrop');
        if (backdrop) backdrop.style.opacity = '';
    }

    // ─── الإغلاق بحركة خروج سريعة ثم dismissal ───
    function dismissWithAnimation() {
        const menuHeight = contextMenu.offsetHeight || 300;
        contextMenu.style.transition = 'transform 0.28s cubic-bezier(0.32, 0.72, 0, 1)';
        contextMenu.style.transform  = `translateY(${menuHeight + 20}px)`;

        // تلاشٍ الخلفية بالتزامن
        const backdrop = document.getElementById('contextBackdrop');
        if (backdrop) {
            backdrop.style.transition = 'opacity 0.25s ease';
            backdrop.style.opacity    = '0';
        }

        // بعد انتهاء الحركة — تنظيف كامل
        setTimeout(() => {
            contextMenu.style.transition = '';
            contextMenu.style.transform  = '';
            if (backdrop) {
                backdrop.style.transition = '';
                backdrop.style.opacity    = '';
            }
            hideContextMenuAndGoBack();
        }, 285);
    }

    // ════════════ أحداث اللمس ════════════

    contextMenu.addEventListener('touchstart', (e) => {
        if (!contextMenuVisible) return;

        // السماح بالسحب فقط من الهيدر أو مقبض السحب (::before) أو عند وصول التمرير للأعلى
        const touchTarget = e.target;
        const isFromHeader = touchTarget.closest('.context-menu-header');
        const isFromHandle = !touchTarget.closest('.context-menu-list');

        if (!isFromHeader && !isFromHandle && isListScrolled()) return;

        isDragging  = true;
        dragStartY  = e.touches[0].clientY;
        lastY       = dragStartY;
        lastTime    = Date.now();
        currentDY   = 0;
        velocityY   = 0;
    }, { passive: true });

    contextMenu.addEventListener('touchmove', (e) => {
        if (!isDragging || !contextMenuVisible) return;

        const now  = Date.now();
        const y    = e.touches[0].clientY;
        const dy   = y - dragStartY;
        const dt   = now - lastTime;

        // حساب السرعة اللحظية
        if (dt > 0) velocityY = (y - lastY) / dt;
        lastY    = y;
        lastTime = now;

        // منع السحب للأعلى (عكس الاتجاه) والسحب أثناء تمرير القائمة
        if (dy <= 0) {
            if (isDragging) snapBack();
            return;
        }

        if (isListScrolled()) {
            isDragging = false;
            snapBack();
            return;
        }

        currentDY = dy;

        // منع تمرير الصفحة خلف القائمة أثناء السحب
        if (e.cancelable) e.preventDefault();

        applyDrag(dy);
    }, { passive: false });

    contextMenu.addEventListener('touchend', () => {
        if (!isDragging) return;
        isDragging = false;

        const shouldDismiss =
            currentDY >= DISMISS_THRESHOLD ||           // تجاوز العتبة المسافية
            (currentDY > 20 && velocityY >= DISMISS_VELOCITY); // سرعة كافية مع سحب بسيط

        if (shouldDismiss) {
            dismissWithAnimation();
        } else {
            snapBack();
        }

        currentDY = 0;
        velocityY = 0;
    }, { passive: true });

    contextMenu.addEventListener('touchcancel', () => {
        isDragging = false;
        currentDY  = 0;
        snapBack();
    }, { passive: true });
}

// معالجة إجراءات قائمة السياق
function handleContextMenuAction(action) {
    const targetIndex = currentContextIndex;
    if (targetIndex === -1) return;

    // إغلاق القائمة بصمت (replaceState) — آمن تماماً قبل فتح أي overlay آخر
    hideContextMenu();

    switch(action) {
        case 'play':
            selectTrack(targetIndex);
            break;

        case 'addToQueueTop':
            // إضافة أو ترقية الأغنية لأوّل قائمة الانتظار
            if (targetIndex !== currentIndex) {
                const existingPos = fileQueue.indexOf(targetIndex);
                if (existingPos > -1) fileQueue.splice(existingPos, 1); // إزالتها من موضعها القديم
                fileQueue.unshift(targetIndex);                          // وضعها في الأول
                renderPlaylist();
                updateQueueIndicator();
                savePlaylistState();
                showToast('✅ تمت الإضافة إلى أول قائمة الانتظار', 'success');
            }
            break;

        case 'addToQueue':
        case 'removeFromQueue':
            toggleQueueState(targetIndex);
            break;

        case 'delete':
            deleteTrack(targetIndex);
            break;

        case 'info':
            showFileInfo(targetIndex);
            break;
    }
}

// الرجوع من معلومات الأغنية إلى قائمة الأغاني
function backToPlaylistFromInfo() {
    const trackInfoOverlay = document.getElementById('trackInfoOverlay');
    if (trackInfoOverlay) trackInfoOverlay.style.display = 'none';

    if (window.location.hash === '#trackInfoOverlay') {
        history.back();
    } else {
        showOverlay('playlistOverlay');
    }
}

// إغلاق كل شيء من نافذة معلومات الأغنية
function closeAllFromInfo() {
    document.querySelectorAll('.overlay').forEach(el => {
        el.style.display = 'none';
    });
    _dismissContextMenu();
    if (window.location.hash) {
        history.replaceState({}, '', window.location.pathname);
    }
}

// حذف أغنية من القائمة
async function deleteTrack(index) {
    if (index < 0 || index >= files.length) return;

    const file = files[index];
    const fileName = file.name.substring(0, file.name.lastIndexOf('.')) || file.name;

    showCustomConfirm(`هل أنت متأكد من حذف "${fileName}" من القائمة؟`, async () => {
        const uniqueId = (file.customPath || file.name) + '_' + file.size;
        const wasCurrentSong = (index === currentIndex);

        // إغلاق قائمة السياق فوراً قبل أي عملية
        hideContextMenu();

        try {
            await dbManager.deleteAudioFile(uniqueId);

            // ── حذف ملف الكلمات المرتبط بالأغنية (إن وجد) ─────────────
            const companionLyrics = searchForCompanionFile(file);
            if (companionLyrics) {
                const lyricsUniqueId = (companionLyrics.customPath || companionLyrics.name) + '_' + companionLyrics.size;
                try { await dbManager.deleteAudioFile(lyricsUniqueId); } catch (_) {}
                // إزالته من خريطة الكلمات في الذاكرة
                const baseName = file.name.substring(0, file.name.lastIndexOf('.'));
                lyricsMap.delete(baseName);
                // مسح الكلمات من الشاشة إذا كانت تخص الأغنية الحالية
                if (index === currentIndex) {
                    lyricsData = [];
                    currentLyricIndex = 0;
                    lyricsDisplay.style.display = 'none';
                    isLyricsVisible = false;
                    lyricsToggleBtn.classList.remove('active');
                }
            }

            // ── حالة: الأغنية الوحيدة في القائمة ──────────────────────
            if (files.length === 1) {
                audioPlayer.pause();
                audioPlayer.src = "";
                if (currentAudioBlobUrl) {
                    URL.revokeObjectURL(currentAudioBlobUrl);
                    currentAudioBlobUrl = null;
                }
                trackTitleEl.textContent = "اختر أغنية";
                trackArtistEl.textContent = "تم حذف القائمة";
                coverArt.style.display = 'none';
                defaultIcon.style.display = 'flex';
                msClear();
                fileQueue.length = 0;
                files.splice(0, 1);
                shuffledIndices = [];
                shuffleHistory = [];
                shufflePointer = 0;
                renderPlaylist();
                updateQueueIndicator();
                savePlaylistState();
                showToast('تم حذف الأغنية بنجاح', 'info');
                return;
            }

            // ── تحديث currentIndex قبل الحذف (للأغاني التي بعد المحذوفة) ──
            if (!wasCurrentSong && index < currentIndex) {
                currentIndex--;
            }

            // ── تحديث قائمة الانتظار ──────────────────────────────────
            const queueIndex = fileQueue.indexOf(index);
            if (queueIndex > -1) fileQueue.splice(queueIndex, 1);
            for (let i = 0; i < fileQueue.length; i++) {
                if (fileQueue[i] > index) fileQueue[i]--;
            }

            // ── حذف الملف من المصفوفة ─────────────────────────────────
            files.splice(index, 1);

            // ── تحديث حالة التشغيل العشوائي ──────────────────────────
            let nextIndexAfterDelete = -1;

            if (isRandomPlayback) {
                const posInShuffle = shuffledIndices.indexOf(index);

                // إزالة الأغنية من قائمة الترتيب العشوائي
                if (posInShuffle !== -1) {
                    shuffledIndices.splice(posInShuffle, 1);
                    // تصحيح المؤشر إذا كانت الأغنية قبل الموضع الحالي
                    if (posInShuffle < shufflePointer) shufflePointer--;
                }

                // تصحيح جميع الفهارس للإزاحة بعد الحذف
                shuffledIndices = shuffledIndices.map(i => i > index ? i - 1 : i);
                shuffleHistory = shuffleHistory
                    .filter(i => i !== index)
                    .map(i => i > index ? i - 1 : i);

                if (wasCurrentSong) {
                    // إعادة توليد القائمة إذا أصبحت غير صالحة
                    if (!isShuffleListValid()) generateShuffledList();

                    // التالي في الترتيب العشوائي
                    if (shuffledIndices.length > 0) {
                        if (shufflePointer >= shuffledIndices.length) shufflePointer = 0;
                        nextIndexAfterDelete = shuffledIndices[shufflePointer];
                    }
                }
            } else if (wasCurrentSong) {
                // ── وضع ترتيب عادي: تشغيل الأغنية التي حلّت محلها ──
                nextIndexAfterDelete = Math.min(index, files.length - 1);
            }

            // ── تحديث currentIndex إذا كانت الأغنية المحذوفة هي الحالية ──
            if (wasCurrentSong && nextIndexAfterDelete >= 0) {
                currentIndex = nextIndexAfterDelete;
            }

            renderPlaylist();
            updateQueueIndicator();
            savePlaylistState();

            // ── تشغيل الأغنية التالية إذا كانت المحذوفة تعمل حالياً ──
            if (wasCurrentSong && files.length > 0) {
                playFile(files[currentIndex]);
            }

            showToast('تم حذف الأغنية بنجاح', 'info');

        } catch (err) {
            console.error("Error deleting file:", err);
            showToast('حدث خطأ أثناء الحذف من الذاكرة', 'error');
        }
    });
}

// عرض معلومات الملف مع إمكانية التعديل
function showFileInfo(index) {
    if (index < 0 || index >= files.length) return;

    const file = files[index];
    const fileSize = (file.size / (1024 * 1024)).toFixed(2);
    const detailsBox = document.getElementById('trackDetailsBox');
    const fileKey = `${file.name}_${file.size}`;

    const createRow = (id, label, value, isEditable = false) => {
        const safeValue = escapeHTML(value || '');
        if (isEditable) {
            return `<div class="detail-row">
                        <span class="detail-label">${label}:</span>
                        <input type="text" id="edit_${id}" class="detail-input" value="${safeValue}" placeholder="غير معروف">
                    </div>`;
        } else {
            return `<div class="detail-row">
                        <span class="detail-label">${label}:</span>
                        <span class="detail-value" title="${safeValue}">${safeValue || '-'}</span>
                    </div>`;
        }
    };

    const renderViewMode = (meta) => {
        let html = createRow('name', 'اسم الملف', file.name) +
                   createRow('size', 'الحجم', `${fileSize} MB`) +
                   createRow('type', 'النوع', file.type || 'صوت/غير معروف') +
                   createRow('title', 'العنوان', meta.title) +
                   createRow('artist', 'الفنان', meta.artist) +
                   createRow('album', 'الألبوم', meta.album) +
                   createRow('year', 'السنة', meta.year) +
                   createRow('genre', 'النوع', meta.genre);

        html += `<div style="text-align:center; margin-top: 20px;">
                    <button id="editInfoBtn" class="secondary-btn" style="background: var(--surface-color); color: var(--accent-color); padding: 8px 20px; border-radius: 8px; font-size: 15px; border: 1px solid var(--accent-color);"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left:6px"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg> تعديل المعلومات</button>
                 </div>`;

        detailsBox.innerHTML = html;
        document.getElementById('editInfoBtn').onclick = () => renderEditMode(meta);
    };

    const renderEditMode = (meta) => {
        let html = createRow('name', 'اسم الملف', file.name, false) +
                   createRow('size', 'الحجم', `${fileSize} MB`, false) +
                   createRow('title', 'العنوان', meta.title, true) +
                   createRow('artist', 'الفنان', meta.artist, true) +
                   createRow('album', 'الألبوم', meta.album, true) +
                   createRow('year', 'السنة', meta.year, true) +
                   createRow('genre', 'النوع', meta.genre, true);

        html += `<div style="display:flex; justify-content:center; gap:10px; margin-top: 20px;">
                    <button id="saveInfoBtn" class="secondary-btn" style="background: var(--accent-color); color: white; padding: 8px 20px; border-radius: 8px; font-size: 15px;"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-left:6px"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg> حفظ</button>
                    <button id="cancelInfoBtn" class="secondary-btn" style="background: #333; color: white; padding: 8px 20px; border-radius: 8px; font-size: 15px;"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" style="margin-left:6px"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> إلغاء</button>
                 </div>`;

        detailsBox.innerHTML = html;

        document.getElementById('cancelInfoBtn').onclick = () => renderViewMode(meta);
        document.getElementById('saveInfoBtn').onclick = async () => {
            const newMeta = {
                title: document.getElementById('edit_title').value.trim(),
                artist: document.getElementById('edit_artist').value.trim(),
                album: document.getElementById('edit_album').value.trim(),
                year: document.getElementById('edit_year').value.trim(),
                genre: document.getElementById('edit_genre').value.trim(),
                imageUrl: meta.imageUrl
            };

            try {
                await dbManager.saveMeta(fileKey, newMeta);
                showToast('تم حفظ التعديلات بنجاح!', 'success');
                if (index === currentIndex) updateTrackInfo(file);
                renderViewMode(newMeta);
            } catch (err) {
                console.error("Error saving metadata:", err);
                showToast('حدث خطأ أثناء الحفظ', 'error');
            }
        };
    };

    // إظهار النافذة
    showOverlay('trackInfoOverlay');
    detailsBox.innerHTML = `<div style="text-align:center; padding: 10px; color: var(--accent-color);">جاري جلب البيانات...</div>`;

    dbManager.loadMeta(fileKey).then(async (cachedMeta) => {
        let meta = cachedMeta || {};

        if (!cachedMeta || (!cachedMeta.title && !cachedMeta.artist)) {
            try {
                const tag = await getMetadata(file);
                if (tag && tag.tags) {
                    meta.title = tag.tags.title || meta.title;
                    meta.artist = tag.tags.artist || meta.artist;
                    meta.album = tag.tags.album || meta.album;
                    meta.year = tag.tags.year || meta.year;
                    meta.genre = tag.tags.genre || meta.genre;
                    meta.imageUrl = tag.tags.pictureUrl || meta.imageUrl;
                    dbManager.saveMeta(fileKey, meta);
                }
            } catch (e) {
                console.warn("فشل قراءة الميتاداتا", e);
            }
        }

        renderViewMode(meta);
    });
}
