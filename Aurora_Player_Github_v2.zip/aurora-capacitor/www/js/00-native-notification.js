// ═══════════════════════════════════════════════════════════════
//  aurora-native-notification.js
//  جسر الإشعارات الأصلية لـ Android (Capacitor)
//  يعمل بالتوازي مع Media Session API الموجود
// ═══════════════════════════════════════════════════════════════

const AuroraNative = (() => {

    let _isAndroid = false;
    let _MusicControls = null;
    let _initialized = false;

    // الكشف عن بيئة Capacitor
    async function init() {
        try {
            if (window.Capacitor && window.Capacitor.isNativePlatform()) {
                const { MusicControls } = await import('capacitor-music-controls-plugin-new');
                _MusicControls = MusicControls;
                _isAndroid = true;
                _setupListeners();
                console.log('[Aurora Native] تم تفعيل الإشعارات الأصلية ✅');
            }
        } catch (e) {
            console.log('[Aurora Native] تعذّر تحميل الإشعارات الأصلية، سيُستخدم Media Session فقط');
        }
        _initialized = true;
    }

    // إعداد مستمعي الأزرار من الإشعار
    function _setupListeners() {
        if (!_MusicControls) return;
        _MusicControls.addListener('controlsNotification', (info) => {
            const action = info.message;
            switch (action) {
                case 'music-controls-next':           skipNext();        break;
                case 'music-controls-previous':       skipPrev();        break;
                case 'music-controls-play':           resumePlayback();  break;
                case 'music-controls-pause':          pausePlayback();   break;
                case 'music-controls-destroy':        stopAndClear();    break;
                case 'music-controls-toggle-play-pause':
                    togglePlayPause(); break;
            }
        });
    }

    // تحديث الإشعار عند تغيير الأغنية
    async function updateNotification({ title, artist, album, artworkUrl, isPlaying, duration, elapsed }) {
        if (!_isAndroid || !_MusicControls) return;
        try {
            await _MusicControls.create({
                track:       title   || 'Aurora Player',
                artist:      artist  || '',
                album:       album   || '',
                cover:       artworkUrl || 'www/icons/icon-512x512.png',
                isPlaying:   isPlaying !== false,
                dismissable: false,
                hasPrev:     true,
                hasNext:     true,
                hasClose:    false,
                duration:    duration || 0,
                elapsed:     elapsed  || 0,
                hasSkipForward:  false,
                hasSkipBackward: false,
                ticker:      `▶ ${title || 'Aurora Player'}`,
                playIcon:    'media_play',
                pauseIcon:   'media_pause',
                prevIcon:    'media_prev',
                nextIcon:    'media_next',
                closeIcon:   'media_close',
                notificationIcon: 'notification_icon'
            });
        } catch (e) {
            console.warn('[Aurora Native] خطأ في تحديث الإشعار:', e);
        }
    }

    // تحديث حالة التشغيل فقط (play/pause) بدون إعادة إنشاء الإشعار
    async function updatePlayState(isPlaying, elapsed) {
        if (!_isAndroid || !_MusicControls) return;
        try {
            if (isPlaying) {
                await _MusicControls.updateIsPlaying({ isPlaying: true });
            } else {
                await _MusicControls.updateIsPlaying({ isPlaying: false });
            }
            if (elapsed !== undefined) {
                await _MusicControls.updateElapsed({ elapsed, isPlaying });
            }
        } catch (e) {}
    }

    // إخفاء الإشعار
    async function destroy() {
        if (!_isAndroid || !_MusicControls) return;
        try { await _MusicControls.destroy(); } catch(e) {}
    }

    return { init, updateNotification, updatePlayState, destroy };
})();

// ══════════════════════════════════════════════════════════════
//  الربط مع نظام Aurora الموجود
//  نضيف hooks على الدوال الموجودة بدلاً من تعديلها
// ══════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', async () => {
    await AuroraNative.init();

    // ربط مع msApply الموجود (يُستدعى عند كل تغيير في الإشعار)
    const _origMsApply = window.msApply;
    window.msApply = function() {
        if (_origMsApply) _origMsApply.apply(this, arguments);
        // نقرأ الحالة الحالية من المتغيرات الموجودة
        _syncNativeNotification();
    };

    // ربط مع updatePositionState الموجود
    const _origPositionState = window.updatePositionState;
    window.updatePositionState = function() {
        if (_origPositionState) _origPositionState.apply(this, arguments);
        const player = typeof getActivePlayer === 'function' ? getActivePlayer() : null;
        if (player) {
            AuroraNative.updatePlayState(!player.paused, player.currentTime);
        }
    };

    // ربط مع msClear الموجود
    const _origMsClear = window.msClear;
    window.msClear = function() {
        if (_origMsClear) _origMsClear.apply(this, arguments);
        AuroraNative.destroy();
    };
});

function _syncNativeNotification() {
    // قراءة البيانات من المتغيرات الداخلية لـ media-session
    const title  = window._msTitle   || '';
    const artist = window._msArtist  || '';
    const album  = window._msAlbum   || '';
    const art    = window._msArtworkDataUrl || null;
    const player = typeof getActivePlayer === 'function' ? getActivePlayer() : null;

    AuroraNative.updateNotification({
        title,
        artist,
        album,
        artworkUrl:  art,
        isPlaying:   player ? !player.paused : false,
        duration:    player?.duration  || 0,
        elapsed:     player?.currentTime || 0
    });
}
