
// ===============================================
// نظام مؤقت الإيقاف الزمني — يدعم الساعات والدقائق
// ===============================================
let sleepInterval     = null;
let sleepEndTime      = 0;
let sleepTotalDuration = 0;

// ثابت محيط القوس (2 × π × r) حيث r=52
const TIMER_ARC_CIRCUMFERENCE = 2 * Math.PI * 52;

/**
 * تحديث قوس SVG وعرض الوقت المتبقي بصيغة HH:MM:SS أو MM:SS
 */
function updateTimerDisplay() {
    const diff       = Math.max(0, sleepEndTime - Date.now());
    const totalSecs  = Math.floor(diff / 1000);
    const h          = Math.floor(totalSecs / 3600);
    const m          = Math.floor((totalSecs % 3600) / 60);
    const s          = totalSecs % 60;

    const display = document.getElementById('remainingTime');
    if (display) {
        if (h > 0) {
            // عرض الساعات عند وجودها
            display.innerText =
                `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        } else {
            display.innerText =
                `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
        }
    }

    // تحريك قوس التقدم
    const arc = document.getElementById('timerProgressArc');
    if (arc && sleepTotalDuration > 0) {
        const progress = diff / sleepTotalDuration;
        arc.style.strokeDashoffset = TIMER_ARC_CIRCUMFERENCE * (1 - progress);
    }
}

/**
 * بدء مؤقت النوم
 * @param {number} hours   - الساعات (0 أو أكثر)
 * @param {number} minutes - الدقائق (0–59)
 */
function setSleepTimer(hours, minutes) {
    const h = parseInt(hours)   || 0;
    const m = parseInt(minutes) || 0;

    if (h < 0 || m < 0 || (h === 0 && m === 0)) return;

    const ms           = (h * 3600 + m * 60) * 1000;
    sleepEndTime       = Date.now() + ms;
    sleepTotalDuration = ms;

    localStorage.setItem('aurora_sleep_end',   String(sleepEndTime));
    localStorage.setItem('aurora_sleep_total', String(sleepTotalDuration));

    document.getElementById('timerSelector').style.display = 'none';
    document.getElementById('timerDisplay').style.display  = 'block';

    updateTimerDisplay();

    clearInterval(sleepInterval);
    sleepInterval = setInterval(() => {
        if (sleepEndTime - Date.now() <= 0) {
            executeSleepStop();
        } else {
            updateTimerDisplay();
        }
    }, 1000);

    const label = h > 0
        ? (m > 0 ? `${h} ساعة و${m} دقيقة` : `${h} ساعة`)
        : `${m} دقيقة`;
    showToast(`⏳ سيتم إيقاف الموسيقى بعد ${label}`, 'info');
}

/**
 * بدء المؤقت من حقلَي الساعات والدقائق المخصصَّين
 */
function startCustomTimer() {
    const hVal = parseInt(document.getElementById('customHours')?.value) || 0;
    const mVal = parseInt(document.getElementById('customMins')?.value)  || 0;
    if (hVal === 0 && mVal === 0) {
        showToast('أدخِل مدة صحيحة (ساعات أو دقائق)', 'error');
        return;
    }
    setSleepTimer(hVal, mVal);
}

// دعم مفتاح Enter في حقلَي الوقت المخصص
(function () {
    function attachEnterKey() {
        ['customHours', 'customMins'].forEach(id => {
            const input = document.getElementById(id);
            if (!input) return;
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.keyCode === 13) {
                    e.preventDefault();
                    startCustomTimer();
                    this.blur();
                }
            });
        });
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', attachEnterKey);
    } else {
        attachEnterKey();
    }
})();

/**
 * إلغاء المؤقت يدوياً
 */
function stopSleepTimer() {
    clearInterval(sleepInterval);
    sleepEndTime      = 0;
    sleepTotalDuration = 0;
    localStorage.removeItem('aurora_sleep_end');
    localStorage.removeItem('aurora_sleep_total');

    document.getElementById('timerSelector').style.display = 'flex';
    document.getElementById('timerDisplay').style.display  = 'none';
    showToast('تم إلغاء مؤقت النوم', 'info');
}

/**
 * التنفيذ النهائي عند انتهاء الوقت — مع تلاشٍ تدريجي للصوت
 */
async function executeSleepStop() {
    clearInterval(sleepInterval);
    sleepEndTime      = 0;
    sleepTotalDuration = 0;
    localStorage.removeItem('aurora_sleep_end');
    localStorage.removeItem('aurora_sleep_total');

    const player = getActivePlayer();
    if (player && !player.paused) {
        showToast('😴 ينتهي الوقت… تلاشٍ تدريجي', 'info', 4000);
        await fadeOut(player, 3);
    }

    if (typeof updatePlayPauseBtn === 'function') updatePlayPauseBtn();

    document.getElementById('timerSelector').style.display = 'flex';
    document.getElementById('timerDisplay').style.display  = 'none';

    showToast('😴 انتهى الوقت — تم إيقاف التشغيل', 'success', 4000);
}

/**
 * استعادة المؤقت إن كان نشطاً عند آخر إغلاق للصفحة
 */
function restoreSleepTimerState() {
    const savedEnd   = localStorage.getItem('aurora_sleep_end');
    const savedTotal = localStorage.getItem('aurora_sleep_total');
    if (!savedEnd || !savedTotal) return;

    const endTime   = parseInt(savedEnd);
    const totalDur  = parseInt(savedTotal);
    const remaining = endTime - Date.now();

    if (remaining > 0) {
        sleepEndTime       = endTime;
        sleepTotalDuration = totalDur;

        document.getElementById('timerSelector').style.display = 'none';
        document.getElementById('timerDisplay').style.display  = 'block';

        updateTimerDisplay();

        clearInterval(sleepInterval);
        sleepInterval = setInterval(() => {
            if (sleepEndTime - Date.now() <= 0) {
                executeSleepStop();
            } else {
                updateTimerDisplay();
            }
        }, 1000);

        const totalSecs = Math.ceil(remaining / 1000);
        const hLeft     = Math.floor(totalSecs / 3600);
        const mLeft     = Math.ceil((totalSecs % 3600) / 60);
        const label     = hLeft > 0
            ? (mLeft > 0 ? `${hLeft}س ${mLeft}د` : `${hLeft} ساعة`)
            : `${mLeft} دقيقة`;
        showToast(`⏳ مؤقت النوم مستعاد — ${label} متبقية`, 'info', 4000);
    } else {
        localStorage.removeItem('aurora_sleep_end');
        localStorage.removeItem('aurora_sleep_total');
    }
}
// ===============================================
// ملاحظة: دوال واجهة قائمة المؤثرات البصرية (visualizerNamesAr,
// populateVisualizerMenu, turnOffVisualizer, updateVisualizerGridActiveState)
// تم نقلها إلى 13-visualizer-controls.js — مكانها المنطقي الصحيح.
// ===============================================
