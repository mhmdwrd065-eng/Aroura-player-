function setupLongPressEvents() {
    // للأجهزة التي تعمل باللمس
    playlistElement.addEventListener('touchstart', (e) => {
        const item = e.target.closest('.playlist-item');
        if (!item) return;
        
        isLongPressing = false; // تصفير الحالة مع كل لمسة جديدة

        const index = parseInt(item.dataset.index);
        if (isNaN(index)) return;
        
        contextLongPressTimer = setTimeout(() => {
            isLongPressing = true; // تم تأكيد الضغط المطول
            showContextMenu(index, e.touches[0].clientX, e.touches[0].clientY);
            contextLongPressTimer = null;
            // ← الإصلاح: امتص حدث click الاصطناعي الناتج عن رفع الإصبع
            document.addEventListener('touchend', _absorbClickAfterLongPress, { capture: true, once: true });
        }, LONG_PRESS_DURATION);
    }, { passive: true }); 

    playlistElement.addEventListener('touchend', () => {
        if (contextLongPressTimer) {
            clearTimeout(contextLongPressTimer);
            contextLongPressTimer = null;
        }
    });
    
    playlistElement.addEventListener('touchmove', () => {
        if (contextLongPressTimer) {
            clearTimeout(contextLongPressTimer);
            contextLongPressTimer = null;
        }
    });
    
    // لأجهزة الماوس
    playlistElement.addEventListener('mousedown', (e) => {
        // فقط الزر الأيسر (button === 0)
        if (e.button !== 0) return;
        
        const item = e.target.closest('.playlist-item');
        if (!item) return;
        
        isLongPressing = false; // تصفير الحالة مع كل ضغطة جديدة

        const index = parseInt(item.dataset.index);
        if (isNaN(index)) return;
        
        contextLongPressTimer = setTimeout(() => {
            isLongPressing = true; // تم تأكيد الضغط المطول
            showContextMenu(index, e.clientX, e.clientY);
            contextLongPressTimer = null;
            // ← الإصلاح: بعد ظهور القائمة، امتص حدث click الناتج عن رفع زر الماوس
            // حتى لا تُغلق القائمة أو تُشغَّل أي خيار بشكل غير مقصود
            document.addEventListener('mouseup', _absorbClickAfterLongPress, { capture: true, once: true });
        }, LONG_PRESS_DURATION);
    });
    
    playlistElement.addEventListener('mouseup', () => {
        if (contextLongPressTimer) {
            clearTimeout(contextLongPressTimer);
            contextLongPressTimer = null;
        }
    });
    
    playlistElement.addEventListener('mouseleave', () => {
        if (contextLongPressTimer) {
            clearTimeout(contextLongPressTimer);
            contextLongPressTimer = null;
        }
    });
}

// ===============================================
// دالة مساعدة: تُسجَّل مرة واحدة (once) بعد كل ضغط مطول
// ===============================================
function _absorbClickAfterLongPress() {
    // إعادة ضبط علامة الضغط المطول فوراً عند رفع الإصبع
    isLongPressing = false;

    // إذا كانت قائمة السياق مفتوحة: لا تمتص الـ click التالي
    // لأن الـ click التالي هو ما يُغلق القائمة أو ينفّذ خياراً — لا يجب إلغاؤه
    if (contextMenuVisible) return;

    // خارج قائمة السياق: امتص الـ click الاصطناعي لمنع التفعيل غير المقصود
    document.addEventListener('click', function _stopClick(e) {
        e.stopPropagation();
        e.preventDefault();
    }, { capture: true, once: true });
}

// ═══════════════════════════════════════════════════════════════
//  تفعيل Service Worker + PWA الكاملة (v40)
//  ✅ Service Worker  ✅ Background Sync
//  ✅ Periodic Sync   ✅ Push Notifications
// ═══════════════════════════════════════════════════════════════
if ('serviceWorker' in navigator) {
  window.addEventListener('load', async () => {
    try {
      const registration = await navigator.serviceWorker.register('./service-worker.js');
      console.log('[Aurora] Service Worker مسجّل بنجاح:', registration.scope);

      // ── استقبال رسائل من SW (مثل CACHE_UPDATED) ──────────────
      navigator.serviceWorker.addEventListener('message', event => {
        if (event.data?.type === 'CACHE_UPDATED') {
          console.log('[Aurora] الكاش تم تحديثه من Periodic Sync، الإصدار:', event.data.version);
        }
        if (event.data?.type === 'CACHE_CLEARED') {
          console.log('[Aurora] تم مسح الكاش بالكامل.');
        }
      });

      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      // إصلاح خطأ "Registration failed - no active Service Worker":
      // register() يعود فوراً حتى لو SW لا يزال في حالة "installing".
      // sync.register() تشترط SW مفعّلاً (activated) —
      // navigator.serviceWorker.ready يُحلّ فقط بعد اكتمال التفعيل.
      // ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
      const activeReg = await navigator.serviceWorker.ready;

      // ── Periodic Background Sync ───────────────────────────────
      if ('periodicSync' in activeReg) {
        try {
          const status = await navigator.permissions.query({ name: 'periodic-background-sync' });
          if (status.state === 'granted') {
            await activeReg.periodicSync.register('aurora-periodic-sync', {
              minInterval: 24 * 60 * 60 * 1000   // مرة كل 24 ساعة
            });
            console.log('[Aurora] Periodic Sync مفعّل ✅');
          }
        } catch (e) {
          console.warn('[Aurora] Periodic Sync غير مدعوم:', e.message);
        }
      }

      // ── Background Sync ────────────────────────────────────────
      if ('sync' in activeReg) {
        try {
          await activeReg.sync.register('aurora-bg-sync');
          console.log('[Aurora] Background Sync مفعّل ✅');
        } catch (e) {
          console.warn('[Aurora] Background Sync غير مدعوم:', e.message);
        }
      }

      // ── Push Notifications ─────────────────────────────────────
      if ('pushManager' in activeReg) {
        try {
          const permission = await Notification.requestPermission();
          if (permission === 'granted') {
            console.log('[Aurora] Push Notifications مفعّل ✅');
          } else {
            console.warn('[Aurora] إذن الإشعارات مرفوض من المستخدم.');
          }
        } catch (e) {
          console.warn('[Aurora] Push غير مدعوم:', e.message);
        }
      }

    } catch (error) {
      console.error('[Aurora] فشل تسجيل Service Worker:', error);
    }
  });
}
