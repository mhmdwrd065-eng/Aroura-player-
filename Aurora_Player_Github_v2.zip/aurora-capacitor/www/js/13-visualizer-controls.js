
// ===============================================
// نظام التحكم الذكي بالمؤثرات البصرية (Blossom)
// ===============================================

// الدالة الأساسية (تعمل مع اختصار الكيبورد b)
function toggleBlossom() {
    handleBlossomSingleClick();
}

// دالة إيقاف المؤثرات البصرية بالكامل (تُستخدم عند النقر المزدوج في وضع ملء الشاشة)
function stopVisualizer() {
    // إيقاف التبديل التلقائي إن كان شغالاً
    if (autoCycleTimer) {
        clearInterval(autoCycleTimer);
        autoCycleTimer = null;
    }
    if (visualizerModeIndex !== -1) {
        visualizerModeIndex = -1;
        if (typeof toggleBlossomInternal === 'function') toggleBlossomInternal(true);
    } else {
        showToast('المؤثرات البصرية متوقفة بالفعل', 'info');
    }
    // تحديث زر ملء الشاشة إن كان مفتوحاً
    if (typeof window.updateFsBlossomBtn === 'function') {
        setTimeout(window.updateFsBlossomBtn, 100);
    }
}

// 1. وظيفة النقر المفرد (التنقل للمؤثر التالي)
function handleBlossomSingleClick() {
    if (files.length === 0 && visualizerModeIndex === -1) {
        showToast('وضع البلوسوم يعمل فقط مع الملفات الصوتية.', 'error');
        return;
    }
    if (autoCycleTimer) {
        clearInterval(autoCycleTimer);
        autoCycleTimer = null;
    }
    visualizerModeIndex++;
    if (visualizerModeIndex >= visualizerModes.length) {
        visualizerModeIndex = -1;
    } else if (visualizerModeIndex === 0) {
        visualizerModeIndex = 1;
    }
    toggleBlossomInternal(true);
}

// 2. وظيفة النقر المزدوج (التشغيل التلقائي / الإيقاف)
function handleBlossomDoubleClick() {
    if (files.length === 0 && visualizerModeIndex === -1) {
        showToast('وضع البلوسوم يعمل فقط مع الملفات الصوتية.', 'error');
        return;
    }
    if (autoCycleTimer) {
        clearInterval(autoCycleTimer);
        autoCycleTimer = null;
        visualizerModeIndex = -1;
        toggleBlossomInternal(false);
        showToast('تم إلغاء التبديل التلقائي', 'info');
    } else {
        showToast('تم تفعيل وضع التبديل التلقائي', 'success');
        visualizerModeIndex = 0;
        startAutoCycle(true);
    }
}

// 3. فتح قائمة المؤثرات (3 نقرات أو ضغط مطول)
function openVisualizerMenu() {
    populateVisualizerMenu();
    showOverlay('visualizerOverlay');
}

function startAutoCycle(startImmediately = false) {
    clearInterval(autoCycleTimer);
    
    const cycle = () => {
        audioCanvas.style.transition = 'opacity 0.4s ease-in-out';
        audioCanvas.style.opacity = '0';
        
        setTimeout(() => {
            visualizerModeIndex++;
            if (visualizerModeIndex >= visualizerModes.length) {
                visualizerModeIndex = 1;
            }
            
            toggleBlossomInternal(false); 
            
            audioCanvas.style.opacity = '1';
            
        }, 400);
    };

    if (startImmediately) {
        cycle();
    }
    
    autoCycleTimer = setInterval(cycle, AUTO_CYCLE_DELAY);
}

function toggleBlossomInternal(showToastMessage = true) {
    try {
        if (!masterGain || !analyser) {
            setupAudioContext();
            if (!masterGain) return;
        }
        
        audioCanvas.style.transition = 'opacity 0.2s ease';

        if (visualizerModeIndex === -1) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = null;
            audioCanvas.style.display = 'none';
            blossomToggle.classList.remove('active');
            blossomToggle.blur();
            coverArt.style.filter = 'none';
            coverArt.style.transform = 'scale(1)';
            if(showToastMessage) showToast('تم إيقاف المؤثرات', 'info');

            // تحرير الذاكرة: مسح مصفوفات الجسيمات عند الإيقاف
            confettiParticles = [];
            starTrailsParticles = [];
            liveRipples = [];

            // فصل المحلّل عن مسار الصوت لتوفير الموارد
            if (masterGain && analyser) {
                try {
                    masterGain.disconnect(analyser);
                } catch (e) {
                    console.warn('Error disconnecting analyser:', e);
                }
            }
        } else {
            audioCanvas.style.display = 'block';
            audioCanvas.style.opacity = '1';
            blossomToggle.classList.add('active');
            blossomToggle.blur();
            if (coverArt.style.display === 'block') {
                coverArt.style.filter = 'blur(8px) brightness(0.7)';
                coverArt.style.transform = 'scale(1.1)';
            }
            if(showToastMessage) showToast(`${visualizerModes[visualizerModeIndex]}`, 'info');

            // [تحسين] ضبط حجم الـ canvas فور إظهاره لتجنب الضبابية
            resizeAudioCanvas();

            // إعادة ربط المحلّل بمسار الصوت عند تفعيل المؤثرات
            if (masterGain && analyser) {
                try {
                    masterGain.connect(analyser);
                } catch (e) {
                    console.warn('Error connecting analyser:', e);
                }
            }
            
    if (animationFrameId === null) { 
        // [تحسين] مسح حالة المؤثر السابق قبل بدء المؤثر الجديد
        if (typeof resetVisualizerState === 'function') resetVisualizerState();
        visualize();
    }
        }
    } catch (error) {
        console.error('Error in toggleBlossomInternal:', error);
        showToast('حدث خطأ في المؤثرات البصرية', 'error');
    }
}

function visualize(timestamp = 0) {
    // التحقق من الشروط الأساسية
    if (visualizerModeIndex === -1 || !analyser || getActivePlayer() !== audioPlayer) { 
        cancelAnimationFrame(animationFrameId); 
        animationFrameId = null; 
        return; 
    }

    // [تحسين] لا ترسم عندما تكون الصفحة في الخلفية (يوفر بطارية ويخفف الحِمل)
    if (document.visibilityState === 'hidden') {
        animationFrameId = requestAnimationFrame(visualize);
        return;
    }

    // ── تحكم تكيفي بمعدل الإطارات (24fps على الضعيفة جداً، 30fps على الضعيفة) ──
    if (DevicePerf.isLowEnd) {
        const elapsed = timestamp - _lastFrameTime;
        if (elapsed < _frameInterval) {
            animationFrameId = requestAnimationFrame(visualize);
            return;
        }
        _lastFrameTime = timestamp - (elapsed % _frameInterval);
    }

    // 1. جلب بيانات الصوت أولاً
    analyser.getByteFrequencyData(freqDataArray); 
    analyser.getByteTimeDomainData(timeDataArray); 
    
    // التحقق من نزول المؤثرات للصفر
    let isSilent = true;
    for (let i = 0; i < freqDataArray.length; i++) {
        if (freqDataArray[i] > 0) { isSilent = false; break; }
    }

    // إذا كانت الموسيقى متوقفة والمؤثرات هبطت للصفر تماماً، أوقف الرسم
    if (audioPlayer.paused && isSilent) {
        const _dprStop = Math.min(window.devicePixelRatio || 1, DevicePerf.maxDPR);
        canvasCtx.clearRect(0, 0, audioCanvas.width / _dprStop, audioCanvas.height / _dprStop);
        cancelAnimationFrame(animationFrameId);
        animationFrameId = null;
        return;
    }
    
    // 2. طلب الإطار التالي (استمرار حلقة الرسم)
    animationFrameId = requestAnimationFrame(visualize); 

    // [إصلاح] استخدام الأبعاد المنطقية (CSS pixels) لا الفيزيائية
    // audioCanvas.width/height = أبعاد فيزيائية (مضروبة في DPR)
    // لكن ctx مُحوَّل بـ setTransform(dpr,…) → الإحداثيات المنطقية = فيزيائية / DPR
    // تمرير الأبعاد الفيزيائية للمؤثرات يجعلها ترسم خارج الشاشة على HiDPI
    const _dpr    = Math.min(window.devicePixelRatio || 1, DevicePerf.maxDPR);
    const width   = Math.round(audioCanvas.width  / _dpr);
    const height  = Math.round(audioCanvas.height / _dpr);

    const bufferLengthFreq = analyser.frequencyBinCount;
    const bufferLengthTime = analyser.fftSize;

    // ✨ حساب avgEnergy و bassAvg مرة واحدة لكل الإطار
    // بدلاً من reduce() المتكرر في كل مؤثر (كان يُشغَّل 6 مرات لكل إطار!)
    let _sum = 0;
    for (let i = 0; i < bufferLengthFreq; i++) _sum += freqDataArray[i];
    _frameAvgEnergy = (_sum / bufferLengthFreq) / 255;
    _frameBassAvg   = ((freqDataArray[0] + freqDataArray[1] + freqDataArray[2] + freqDataArray[3]) * 0.25) / 255;

    // ✨ حساب طاقة منتصف الترددات والترددات الحادة
    // الباص: 0-8% | المنتصف: 8-40% | الحادة: 40-80%
    const _midStart  = Math.floor(bufferLengthFreq * 0.08);
    const _midEnd    = Math.floor(bufferLengthFreq * 0.40);
    const _highEnd   = Math.floor(bufferLengthFreq * 0.80);
    let _midSum = 0, _highSum = 0;
    for (let i = _midStart; i < _midEnd; i++) _midSum  += freqDataArray[i];
    for (let i = _midEnd;   i < _highEnd; i++) _highSum += freqDataArray[i];
    _frameMidAvg  = (_midSum  / (_midEnd  - _midStart)) / 255;
    _frameHighAvg = (_highSum / (_highEnd - _midEnd))   / 255;

    // ✨ تحديث البيانات المُنعَّمة (Smoothed Frequency) — حركة أكثر سلاسة
    // [تحسين] الأجهزة الضعيفة جداً: تخطي التنعيم وترك _smoothedFreq = null
    //         المؤثرات ستستخدم data.freq مباشرة (أسرع وأبسط)
    if (!DevicePerf.isUltraLow) {
        if (!_smoothedFreq || _smoothedFreq.length !== bufferLengthFreq) {
            _smoothedFreq = new Float32Array(bufferLengthFreq);
            _smoothedFreq.set(freqDataArray);
        }
        const _sk = _SMOOTH_FAST;
        for (let i = 0; i < bufferLengthFreq; i++) {
            _smoothedFreq[i] = _smoothedFreq[i] * _sk + freqDataArray[i] * (1 - _sk);
        }
    } else {
        _smoothedFreq = null; // المؤثرات تقرأ data.freq مباشرة
    }

    // ✨ كشف البيت (Beat Detection) — يقارن طاقة الباص بمتوسطها عبر الزمن
    _beatAvgEnergy = _beatAvgEnergy * 0.93 + _frameBassAvg * 0.07;
    _beatDetected  = _frameBassAvg > _beatAvgEnergy * 1.28 && _frameBassAvg > 0.07;
    if (_beatDetected) {
        _beatPulse = 1.0;
    } else {
        _beatPulse = Math.max(0, _beatPulse - _BEAT_DECAY);
    }

    // [تحسين] للأجهزة الضعيفة جداً: استخدام fade بدلاً من clear كامل
    // يعطي تأثيراً بصرياً أجمل (ذيول) مع توفير وقت GPU
    if (DevicePerf.isUltraLow) {
        canvasCtx.fillStyle = 'rgba(0,0,0,0.45)';
        canvasCtx.fillRect(0, 0, width, height);
    } else {
        canvasCtx.clearRect(0, 0, width, height);
    }

    // [تحسين] استخدام timestamp من requestAnimationFrame بدلاً من Date.now()
    // أدق وأرخص على الـ CPU (Date.now() يستدعي syscall)
    const _now = timestamp;
    const time = _now / 1000;
    const hue  = (_now / 50) % 360;
    
    canvasCtx.save();
    canvasCtx.beginPath();
    canvasCtx.rect(0, 0, width, height);
    canvasCtx.clip();
    
    const currentStyle = `hsl(${hue}, 100%, 50%)`;
    canvasCtx.fillStyle = currentStyle;
    canvasCtx.strokeStyle = currentStyle;

    const currentMode = visualizerModes[visualizerModeIndex];
    if (currentMode !== 'confetti-burst' && confettiParticles.length > 0) confettiParticles = [];
    if (currentMode !== 'star-trails' && starTrailsParticles.length > 0) starTrailsParticles = [];
    if (currentMode !== 'dynamic-rings' && liveRipples.length > 0) liveRipples = [];
    // ✨ إعادة تهيئة حالة المؤثرات الجسيمية عند تغيير المؤثر
    if (currentMode !== 'fireworks'          && (_fwRockets.length > 0 || _fwSparks.length > 0)) { _fwRockets = []; _fwSparks = []; _fwLastLaunch = 0; }
    if (currentMode !== 'rain-drops'         && _rainDrops  !== null) _rainDrops  = null;
    if (currentMode !== 'digital-waterfall'  && _matrixCols !== null) _matrixCols = null;
    if (currentMode !== 'starfield'          && _stars3D    !== null) _stars3D    = null;
    if (currentMode !== 'sound-drops'        && (_sdDrops   !== null || _sdSplashes !== null)) { _sdDrops = null; _sdSplashes = null; }
    if (currentMode !== 'shockwave'          && _shockwaves !== null) { _shockwaves = null; _shockLastTime = 0; }

    const routine = visualizerRoutines[currentMode];
    if (routine) {
        try {
            routine(canvasCtx, { freq: freqDataArray, time: timeDataArray }, time, width, height, bufferLengthFreq, bufferLengthTime);
        } catch (err) {
            console.error(`Error in visualizer routine '${currentMode}':`, err);
        }
    }

    canvasCtx.restore();
}

function updateButtonStates() {
    randomBtn.classList.toggle('active', isRandomPlayback);

    const modes = [svgs.loopAll, svgs.loopOne, svgs.loopOff];
    loopBtn.innerHTML = modes[isLoopMode];
    loopBtn.classList.toggle('active', isLoopMode !== 2);
    
    lyricsToggleBtn.classList.toggle('active', isLyricsVisible);
    blossomToggle.classList.toggle('active', visualizerModeIndex !== -1);
    updatePlayPauseBtn();
}

// ===============================================
// دوال واجهة قائمة المؤثرات البصرية
// (نُقلت من 19-sleep-timer.js إلى هنا — مكانها المنطقي الصحيح)
// ===============================================
const visualizerNamesAr = {
    'auto-cycle': 'تبديل تلقائي', 'freq-bars': 'أعمدة التردد', 'oval-pulse': 'نبض بيضاوي',
    'time-wave': 'موجة الصوت', 'mirror-bars': 'انعكاس مرآوي', 'scatter': 'جزيئات متناثرة',
    'v-bars': 'أعمدة معكوسة', 'dot-matrix': 'مصفوفة نقاط', 'energy-ring': 'حلقة الطاقة',
    'helix': 'لولب مزدوج', 'tunnel': 'نفق فضائي', 'rain-drops': 'قطرات المطر',
    'sphere': 'كرة متوهجة', 'digital-glitch': 'تشويش رقمي', 'ripple': 'تموجات الماء',
    'fireworks': 'ألعاب نارية', 'wave-ribbon': 'شريط مموج', 'pulsar': 'نجم نابض',
    'starfield': 'حقل النجوم', 'vortex': 'دوامة', 'geometric': 'أشكال هندسية',
    'galaxy-matrix': 'مجرة', 'laser-bubbles': 'فقاعات ليزر', 'digital-waterfall': 'شلال رقمي',
    'edge-glow': 'توهج الحواف', 'plasma-tunnel': 'نفق بلازما', 'equalizer-3d': 'معادل ثلاثي الأبعاد',
    'sound-web': 'شبكة عنكبوتية', 'rainbow-ring': 'حلقة قوس قزح', 'radial-bars': 'أشعة شمسية',
    'spinning-lines': 'خطوط دوارة', 'confetti-burst': 'انفجار قصاصات', 'neon-grid': 'شبكة نيون',
    'audio-sun': 'شمس صوتية', 'liquid-metal': 'معدن سائل', 'sync-squares': 'مربعات متزامنة',
    'star-trails': 'مسارات النجوم', 'dynamic-rings': 'حلقات ديناميكية',
    'aurora-curtain': 'شفق قطبي', 'sound-drops': 'مطر الصوت', 'shockwave': 'موجة الصدمة'
};

function populateVisualizerMenu() {
    const grid = document.getElementById('visualizerGrid');
    if (!grid) return;
    
    grid.innerHTML = ''; 
    
    // 1. زر التبديل التلقائي الثابت في البداية
    const autoBtn = document.createElement('button');
    autoBtn.className = `vis-option-btn ${visualizerModeIndex === 0 && autoCycleTimer ? 'active' : ''}`;
    autoBtn.innerHTML = `<div class="vis-icon-indicator" style="border-radius: 4px;"></div><span>🔄 تبديل تلقائي</span>`;
    autoBtn.onclick = () => {
        visualizerModeIndex = 0;
        startAutoCycle(true);
        updateVisualizerGridActiveState();
        showToast('تم تفعيل التبديل التلقائي', 'success');
        setTimeout(() => hideOverlay('visualizerOverlay'), 300);
    };
    grid.appendChild(autoBtn);

    // 2. باقي المؤثرات الديناميكية
    visualizerModes.forEach((mode, index) => {
        if (mode === 'auto-cycle') return; 
        
        const btn = document.createElement('button');
        const isActive = (visualizerModeIndex === index && !autoCycleTimer);
        btn.className = `vis-option-btn ${isActive ? 'active' : ''}`;
        
        const displayName = visualizerNamesAr[mode] || mode;
        btn.innerHTML = `<div class="vis-icon-indicator"></div><span>${displayName}</span>`;
        
        btn.onclick = () => {
            if (autoCycleTimer) {
                clearInterval(autoCycleTimer);
                autoCycleTimer = null;
            }
            visualizerModeIndex = index;
            toggleBlossomInternal(false);
            showToast(`تم تفعيل: ${displayName}`, 'info');
            updateVisualizerGridActiveState();
            setTimeout(() => hideOverlay('visualizerOverlay'), 300);
        };
        grid.appendChild(btn);
    });
}

function turnOffVisualizer() {
    if (autoCycleTimer) {
        clearInterval(autoCycleTimer);
        autoCycleTimer = null;
    }
    visualizerModeIndex = -1;
    toggleBlossomInternal(false);
    showToast('تم إيقاف المؤثرات البصرية', 'info');
    updateVisualizerGridActiveState();
    setTimeout(() => hideOverlay('visualizerOverlay'), 300);
}

function updateVisualizerGridActiveState() {
    populateVisualizerMenu(); // تحديث الألوان بضمان أمان تام
}

// ===============================================
// [تحسين جديد] ضبط حجم الـ Canvas بدقة بكسل صحيحة
// يمنع الضبابية على شاشات Retina / HiDPI
// ويُخفّف الرسم على الأجهزة الضعيفة عبر تحديد DPR أقصى
// ===============================================
function resizeAudioCanvas() {
    if (!audioCanvas) return;
    const container = audioCanvas.parentElement || document.getElementById('mediaContainer');
    if (!container) return;

    const maxDPR = DevicePerf.maxDPR; // 1 للأجهزة الضعيفة، max 2 للقوية
    const dpr = Math.min(window.devicePixelRatio || 1, maxDPR);

    const cssW = container.clientWidth  || audioCanvas.clientWidth  || 300;
    const cssH = container.clientHeight || audioCanvas.clientHeight || 300;

    // فقط أعد الحجم إذا تغيّر (تجنّب re-allocation غير الضروري)
    const newW = Math.round(cssW * dpr);
    const newH = Math.round(cssH * dpr);

    if (audioCanvas.width !== newW || audioCanvas.height !== newH) {
        audioCanvas.width  = newW;
        audioCanvas.height = newH;
    }
    // [إصلاح] setTransform بدلاً من scale() لمنع التراكم التدريجي للتحويل
    // scale() تُضاعف التحويل الحالي في كل استدعاء → بعد 3 resizes تصبح 8x
    // setTransform() تُعيّن القيمة المطلقة دائماً بصرف النظر عن الحالة السابقة
    canvasCtx.setTransform(dpr, 0, 0, dpr, 0, 0);
}

// ── مستمع تغيير حجم الشاشة (Debounced) ──
let _canvasResizeTimer = null;
window.addEventListener('resize', () => {
    clearTimeout(_canvasResizeTimer);
    _canvasResizeTimer = setTimeout(resizeAudioCanvas, 200);
}, { passive: true });

// ── استئناف المؤثرات عند العودة للتطبيق إن كانت مفعّلة ──
document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
        // إذا كانت المؤثرات البصرية مفعّلة وتوقفت حلقة الرسم، أعِد تشغيلها
        if (visualizerModeIndex !== -1 && animationFrameId === null && analyser) {
            animationFrameId = requestAnimationFrame(visualize);
        }
        // استئناف سياق الصوت إذا تجمّد
        if (audioContext && audioContext.state === 'suspended') {
            audioContext.resume().catch(() => {});
        }
    }
}, { passive: true });

// ===============================================
// وظائف المعادل الصوتي الاحترافي
