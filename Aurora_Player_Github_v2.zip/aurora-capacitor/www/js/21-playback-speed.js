// ═══════════════════════════════════════════════════════
//  21-playback-speed.js — سرعة التشغيل فقط
//  تمت إزالة التحكم في الجهير/النبرة نهائياً
// ═══════════════════════════════════════════════════════

(function () {
    'use strict';

    let currentSpeed = 1.0;

    // ─────────────────────────────────────────────────────
    //  دالة مساعدة: تلوين شريط EQ حسب قيمته
    //  تُستدعى من هنا ومن 14-eq.js عبر window.paintEqSlider
    // ─────────────────────────────────────────────────────
    window.paintEqSlider = function (slider) {
        var isPreamp = (slider.id === 'preampSlider');
        var val, pct, fill, glow, thumb;

        if (isPreamp) {
            // نطاق 0..2 ، مركز عند 1
            val = parseFloat(slider.value);
            pct = (val / 2) * 100;
            fill  = 'rgba(33,150,243,0.75)';
            thumb = '#2196F3';
            glow  = 'rgba(33,150,243,0.55)';
        } else {
            // نطاق -12..12 ، مركز عند 0
            val = parseFloat(slider.value);
            pct = ((val + 12) / 24) * 100;

            if (val > 3) {
                // تعزيز كبير → وردي/أحمر
                fill  = 'rgba(233,30,99,0.8)';
                thumb = '#e91e63';
                glow  = 'rgba(233,30,99,0.6)';
            } else if (val > 0) {
                // تعزيز خفيف → أخضر
                fill  = 'rgba(76,175,80,0.75)';
                thumb = '#4caf50';
                glow  = 'rgba(76,175,80,0.5)';
            } else if (val < -3) {
                // خفض كبير → بنفسجي
                fill  = 'rgba(156,39,176,0.75)';
                thumb = '#9c27b0';
                glow  = 'rgba(156,39,176,0.5)';
            } else if (val < 0) {
                // خفض خفيف → أزرق فاتح
                fill  = 'rgba(33,150,243,0.65)';
                thumb = '#42a5f5';
                glow  = 'rgba(33,150,243,0.45)';
            } else {
                // صفر → رمادي محايد
                fill  = 'rgba(255,255,255,0.12)';
                thumb = '#9e9e9e';
                glow  = 'rgba(255,255,255,0.15)';
            }
        }

        slider.style.setProperty('--eq-pct',   pct.toFixed(1) + '%');
        slider.style.setProperty('--eq-fill',  fill);
        slider.style.setProperty('--eq-thumb', thumb);
        slider.style.setProperty('--eq-glow',  glow);

        // تحديث data-db على الـ band الأب لإظهار القيمة
        var band = slider.closest('.eq-band');
        if (band) {
            var label = isPreamp
                ? (val === 1 ? '×1.0' : '×' + val.toFixed(1))
                : (val > 0 ? '+' : '') + val.toFixed(1) + ' dB';
            band.setAttribute('data-db', label);
        }
    };

    // ─────────────────────────────────────────────────────
    //  تعيين سرعة التشغيل
    // ─────────────────────────────────────────────────────

    window.setPlaybackSpeed = function (speed) {
        speed = Math.min(3, Math.max(0.25, parseFloat(parseFloat(speed).toFixed(2))));
        currentSpeed = speed;

        // تطبيق السرعة على المشغّل النشط
        var player = (typeof getActivePlayer === 'function') ? getActivePlayer() : null;
        if (player) player.playbackRate = speed;

        // تحديث قيمة عرض الزر الرئيسي
        var dropBtn = document.getElementById('speedDropBtn');
        if (dropBtn) {
            var txt = dropBtn.querySelector('.speed-drop-val');
            if (txt) txt.textContent = speed + '×';
        }

        // تمييز الـ chip النشط وإلغاء تمييز الباقين
        document.querySelectorAll('.speed-chip').forEach(function (btn) {
            var s = parseFloat(btn.dataset.speed);
            btn.classList.toggle('active', Math.abs(s - speed) < 0.01);
        });
    };

    // يُستدعى بعد تحميل مقطع جديد لإعادة تطبيق السرعة المختارة
    window.restorePlaybackSpeed = function () {
        var player = (typeof getActivePlayer === 'function') ? getActivePlayer() : null;
        if (player && player.playbackRate !== currentSpeed) {
            player.playbackRate = currentSpeed;
        }
    };

    window.getCurrentPlaybackSpeed = function () { return currentSpeed; };

    // ─────────────────────────────────────────────────────
    //  القائمة المنسدلة للسرعة (inline expand — بلا absolute)
    // ─────────────────────────────────────────────────────

    function closeSpeedPanel() {
        var panel = document.getElementById('speedDropPanel');
        var btn   = document.getElementById('speedDropBtn');
        if (panel) panel.classList.remove('speed-panel-open');
        if (btn)   btn.classList.remove('drop-active');
    }

    function initSpeedDropdown() {
        var btn   = document.getElementById('speedDropBtn');
        var panel = document.getElementById('speedDropPanel');
        if (!btn || !panel) return;

        btn.addEventListener('click', function (e) {
            e.stopPropagation();
            var wasOpen = panel.classList.contains('speed-panel-open');
            closeSpeedPanel();
            if (!wasOpen) {
                panel.classList.add('speed-panel-open');
                btn.classList.add('drop-active');
            }
        });

        // النقر داخل اللوحة لا يُغلقها
        panel.addEventListener('click', function (e) { e.stopPropagation(); });
    }

    // أي نقر خارج اللوحة يُغلقها
    document.addEventListener('click', closeSpeedPanel);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSpeedDropdown);
    } else {
        initSpeedDropdown();
    }

})();
