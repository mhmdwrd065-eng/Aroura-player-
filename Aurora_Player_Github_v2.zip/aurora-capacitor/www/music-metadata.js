/**
 * music-metadata.js — Local Browser Bundle
 * نسخة محلية كاملة تحل محل id3.js
 * تدعم: MP3 (ID3v1/v2) · FLAC · OGG Vorbis · Opus · M4A/AAC · WAV · AIFF · WMA · APE · WavPack
 * API متوافق 100% مع id3js.fromFile() المستخدم في app.js
 * ترجع: { title, artist, album, year, genre, images: [{mime, data}] }
 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? module.exports = factory() :
    typeof define === 'function' && define.amd ? define(factory) :
    (global = typeof globalThis !== 'undefined' ? globalThis : global || self, global.id3js = factory());
}(this, (function () {
    'use strict';

    // ─────────────────────────────────────────────
    // أدوات مشتركة
    // ─────────────────────────────────────────────

    function readUint32BE(dv, offset) { return dv.getUint32(offset, false); }
    function readUint32LE(dv, offset) { return dv.getUint32(offset, true);  }
    function readUint16BE(dv, offset) { return dv.getUint16(offset, false); }
    function readUint16LE(dv, offset) { return dv.getUint16(offset, true);  }

    function readString(buffer, offset, length) {
        return new TextDecoder('latin1').decode(new Uint8Array(buffer, offset, length));
    }

    function readUTF8(buffer, offset, length) {
        return new TextDecoder('utf-8').decode(new Uint8Array(buffer, offset, length)).replace(/\0/g, '').trim();
    }

    function readUTF16(buffer, offset, length) {
        return new TextDecoder('utf-16').decode(new Uint8Array(buffer, offset, length)).replace(/\0/g, '').trim();
    }

    function synchsafeToInt(b0, b1, b2, b3) {
        return (b0 & 0x7F) << 21 | (b1 & 0x7F) << 14 | (b2 & 0x7F) << 7 | (b3 & 0x7F);
    }

    function emptyTags() {
        return { title: null, artist: null, album: null, year: null, genre: null, images: [] };
    }

    // ─────────────────────────────────────────────
    // فك تشفير النصوص حسب الـ encoding byte
    // ─────────────────────────────────────────────
    function decodeTagText(buffer, offset, size) {
        if (size <= 0) return null;
        const encoding = new DataView(buffer).getUint8(offset);
        const arr = new Uint8Array(buffer, offset + 1, size - 1);
        let str;
        try {
            if (encoding === 0) {
                // ISO-8859-1 / Windows-1252 — أكثر شيوعاً للعربية
                str = new TextDecoder('windows-1252').decode(arr);
            } else if (encoding === 1 || encoding === 2) {
                str = new TextDecoder('utf-16').decode(arr);
            } else {
                str = new TextDecoder('utf-8').decode(arr);
            }
        } catch(e) {
            str = new TextDecoder('utf-8').decode(arr);
        }
        return str.replace(/\0/g, '').trim() || null;
    }

    // ─────────────────────────────────────────────
    // MP3 — ID3v2.x
    // ─────────────────────────────────────────────
    function parseID3v2(buffer) {
        const dv  = new DataView(buffer);
        const u8  = new Uint8Array(buffer);
        const tags = emptyTags();

        if (u8[0] !== 0x49 || u8[1] !== 0x44 || u8[2] !== 0x33) return null; // "ID3"

        const version     = u8[3]; // 2, 3 أو 4
        const flags       = u8[5];
        const hasExtended = (flags & 0x40) !== 0;
        const tagSize     = synchsafeToInt(u8[6], u8[7], u8[8], u8[9]);

        // حجم الهيدر الموسّع (ID3v2.3/2.4)
        let offset = 10;
        if (hasExtended && version >= 3) {
            const extSize = version === 4
                ? synchsafeToInt(u8[10], u8[11], u8[12], u8[13])
                : readUint32BE(dv, 10);
            offset += extSize;
        }

        const end = Math.min(10 + tagSize, buffer.byteLength);

        while (offset < end) {
            // ID3v2.2 — frame ID ثلاثة أحرف
            if (version === 2) {
                if (u8[offset] === 0) break;
                const fid  = readString(buffer, offset, 3);
                const fsize = (u8[offset+3] << 16) | (u8[offset+4] << 8) | u8[offset+5];
                const doff  = offset + 6;
                if (fsize <= 0 || doff + fsize > buffer.byteLength) break;

                if      (fid === 'TT2') tags.title  = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TP1') tags.artist = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TAL') tags.album  = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TYE') tags.year   = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TCO') tags.genre  = decodeTagText(buffer, doff, fsize);
                else if (fid === 'PIC') {
                    const img = decodeAPIC_v22(buffer, doff, fsize);
                    if (img) tags.images.push(img);
                }
                offset += 6 + fsize;
            } else {
                // ID3v2.3 / v2.4
                if (u8[offset] === 0) break;
                const fid = readString(buffer, offset, 4);
                let fsize;
                if (version === 4) {
                    fsize = synchsafeToInt(u8[offset+4], u8[offset+5], u8[offset+6], u8[offset+7]);
                } else {
                    fsize = readUint32BE(dv, offset + 4);
                }
                const doff = offset + 10;
                if (fsize <= 0 || doff + fsize > buffer.byteLength) break;

                if      (fid === 'TIT2') tags.title  = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TPE1') tags.artist = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TALB') tags.album  = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TYER' || fid === 'TDRC') tags.year = decodeTagText(buffer, doff, fsize);
                else if (fid === 'TCON') {
                    let g = decodeTagText(buffer, doff, fsize);
                    if (g) g = resolveGenre(g);
                    tags.genre = g;
                }
                else if (fid === 'APIC') {
                    const img = decodeAPIC(buffer, doff, fsize);
                    if (img) tags.images.push(img);
                }
                offset += 10 + fsize;
            }
        }

        return tags;
    }

    function decodeAPIC(buffer, offset, size) {
        try {
            const dv  = new DataView(buffer);
            const encoding = dv.getUint8(offset);
            let i = offset + 1;
            // MIME type (null-terminated)
            const mimeStart = i;
            while (i < offset + size && dv.getUint8(i) !== 0) i++;
            const mime = readString(buffer, mimeStart, i - mimeStart);
            i++; // skip null
            i++; // picture type byte
            // Description (null-terminated, possibly UTF-16)
            if (encoding === 1 || encoding === 2) {
                while (i < offset + size - 1 && (dv.getUint8(i) !== 0 || dv.getUint8(i+1) !== 0)) i += 2;
                i += 2;
            } else {
                while (i < offset + size && dv.getUint8(i) !== 0) i++;
                i++;
            }
            if (i >= offset + size) return null;
            // normalize mime
            const normMime = mime.toLowerCase().includes('png') ? 'image/png' : 'image/jpeg';
            return { mime: normMime, data: buffer.slice(i, offset + size) };
        } catch(e) { return null; }
    }

    function decodeAPIC_v22(buffer, offset, size) {
        try {
            const dv = new DataView(buffer);
            const encoding = dv.getUint8(offset);
            // 3-char format (e.g. "JPG", "PNG")
            const fmt  = readString(buffer, offset + 1, 3).toLowerCase();
            const mime = fmt === 'png' ? 'image/png' : 'image/jpeg';
            let i = offset + 5; // skip encoding(1) + format(3) + type(1)
            if (encoding === 1 || encoding === 2) {
                while (i < offset + size - 1 && (dv.getUint8(i) !== 0 || dv.getUint8(i+1) !== 0)) i += 2;
                i += 2;
            } else {
                while (i < offset + size && dv.getUint8(i) !== 0) i++;
                i++;
            }
            if (i >= offset + size) return null; // description امتد لنهاية الـ frame
            return { mime, data: buffer.slice(i, offset + size) };
        } catch(e) { return null; }
    }

    // ─────────────────────────────────────────────
    // MP3 — ID3v1 (128 بايت في نهاية الملف)
    // ─────────────────────────────────────────────
    function parseID3v1(buffer) {
        if (buffer.byteLength < 128) return null;
        const offset = buffer.byteLength - 128;
        const u8 = new Uint8Array(buffer, offset, 128);
        if (u8[0] !== 0x54 || u8[1] !== 0x41 || u8[2] !== 0x47) return null; // "TAG"

        const dec = new TextDecoder('windows-1252');
        const tags = emptyTags();
        tags.title  = dec.decode(u8.slice(3,  33)).replace(/\0/g,'').trim() || null;
        tags.artist = dec.decode(u8.slice(33, 63)).replace(/\0/g,'').trim() || null;
        tags.album  = dec.decode(u8.slice(63, 93)).replace(/\0/g,'').trim() || null;
        tags.year   = dec.decode(u8.slice(93, 97)).replace(/\0/g,'').trim() || null;
        const genreIdx = u8[127];
        tags.genre  = GENRES[genreIdx] || null;
        return tags;
    }

    // ─────────────────────────────────────────────
    // FLAC
    // ─────────────────────────────────────────────
    function parseFLAC(buffer) {
        const u8  = new Uint8Array(buffer);
        const dv  = new DataView(buffer);
        if (u8[0]!==0x66||u8[1]!==0x4C||u8[2]!==0x61||u8[3]!==0x43) return null; // "fLaC"

        const tags = emptyTags();
        let offset = 4;

        while (offset + 4 <= buffer.byteLength) {
            const blockHeader = dv.getUint8(offset);
            const isLast      = (blockHeader & 0x80) !== 0;
            const blockType   = blockHeader & 0x7F;
            const blockSize   = (dv.getUint8(offset+1) << 16) | (dv.getUint8(offset+2) << 8) | dv.getUint8(offset+3);
            offset += 4;

            // إذا كانت قيمة blockSize غير صالحة نتخطى هذه الكتلة بدلاً من إيقاف الحلقة كلياً
            // حتى لا نفوّت كتل VORBIS_COMMENT أو PICTURE اللاحقة
            if (blockSize === 0) { if (isLast) break; continue; }
            if (offset + blockSize > buffer.byteLength) { if (isLast) break; offset = buffer.byteLength; break; }
            if (blockType === 4) {
                // VORBIS_COMMENT
                parseVorbisComment(buffer, offset, blockSize, tags);
            } else if (blockType === 6) {
                // PICTURE
                const img = parseFLACPicture(buffer, offset, blockSize);
                if (img) tags.images.push(img);
            }

            offset += blockSize;
            if (isLast) break;
        }
        return tags;
    }

    function parseFLACPicture(buffer, offset, size) {
        try {
            const dv  = new DataView(buffer);
            // pictureType(4) + mimeLength(4) + mime + descLength(4) + desc + width(4) + height(4) + colorDepth(4) + colorCount(4) + dataLength(4) + data
            let i = offset + 4; // skip picture type
            const mimeLen  = dv.getUint32(i, false); i += 4;
            const mime     = readString(buffer, i, mimeLen); i += mimeLen;
            const descLen  = dv.getUint32(i, false); i += 4 + descLen;
            i += 16; // width, height, colorDepth, colorCount
            const dataLen  = dv.getUint32(i, false); i += 4;
            if (i + dataLen > buffer.byteLength) return null; // حماية من overread
            return { mime: mime || 'image/jpeg', data: buffer.slice(i, i + dataLen) };
        } catch(e) { return null; }
    }

    // ─────────────────────────────────────────────
    // Vorbis Comment (OGG / FLAC / Opus)
    // ─────────────────────────────────────────────
    function parseVorbisComment(buffer, offset, size, tags) {
        try {
            const dv  = new DataView(buffer);
            let i = offset;
            // vendor string
            const vendorLen = readUint32LE(dv, i); i += 4;
            if (i + vendorLen > offset + size) return; // vendorLen يتجاوز الـ buffer
            i += vendorLen;
            if (i + 4 > offset + size) return; // لا يكفي مكان لـ count
            const count     = readUint32LE(dv, i); i += 4;
            for (let n = 0; n < count; n++) {
                if (i + 4 > offset + size) break;
                const len = readUint32LE(dv, i); i += 4;
                if (i + len > offset + size) break;
                // قراءة خام بدون حذف \0 لضمان سلامة بيانات base64
                const rawComment = new TextDecoder('utf-8').decode(new Uint8Array(buffer, i, len));
                i += len;
                const eq = rawComment.indexOf('=');
                if (eq < 0) continue;
                const key = rawComment.substring(0, eq).toUpperCase().trim();
                const val = rawComment.substring(eq + 1);  // لا trim() هنا لحماية base64
                if (!val) continue;
                const valTrimmed = val.replace(/\0/g, '').trim();
                if      (key === 'TITLE')       tags.title  = valTrimmed || null;
                else if (key === 'ARTIST')      tags.artist = valTrimmed || null;
                else if (key === 'ALBUM')       tags.album  = valTrimmed || null;
                else if (key === 'DATE' || key === 'YEAR') tags.year = valTrimmed.substring(0,4) || null;
                else if (key === 'GENRE')       tags.genre  = valTrimmed || null;
                else if (key === 'METADATA_BLOCK_PICTURE') {
                    // base64-encoded FLAC PICTURE block — نستخدم val الخام لحماية base64
                    try {
                        const cleanB64 = val.replace(/[\s\0]/g, ''); // حذف whitespace و\0 فقط
                        const decoded = base64ToArrayBuffer(cleanB64);
                        const img = parseFLACPicture(decoded, 0, decoded.byteLength);
                        if (img) tags.images.push(img);
                    } catch(e) {}
                }
            }
        } catch(e) {}
    }

    function base64ToArrayBuffer(b64) {
        const bin = atob(b64);
        const ab  = new ArrayBuffer(bin.length);
        const u8  = new Uint8Array(ab);
        for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i);
        return ab;
    }

    // ─────────────────────────────────────────────
    // OGG (Vorbis / Opus) — multi-page packet reassembly
    // ─────────────────────────────────────────────
    function parseOGG(buffer) {
        const u8 = new Uint8Array(buffer);
        if (u8[0]!==0x4F||u8[1]!==0x67||u8[2]!==0x67||u8[3]!==0x53) return null; // "OggS"

        const tags = emptyTags();

        // ── Step 1: parse all OGG pages ──
        const pages = [];
        let offset  = 0;
        while (offset + 27 <= buffer.byteLength) {
            if (u8[offset]!==0x4F||u8[offset+1]!==0x67||u8[offset+2]!==0x67||u8[offset+3]!==0x53) break;
            const headerType = u8[offset + 5];
            const serial     = new DataView(buffer).getUint32(offset + 14, true);
            const segCount   = u8[offset + 26];
            const segTable   = new Uint8Array(buffer, offset + 27, segCount);
            let pageDataLen  = 0;
            for (let i = 0; i < segCount; i++) pageDataLen += segTable[i];
            const dataStart  = offset + 27 + segCount;
            const isContinued = (headerType & 0x01) !== 0;
            pages.push({ serial, dataStart, dataLen: pageDataLen, isContinued });
            offset = dataStart + pageDataLen;
        }

        // ── Step 2: reassemble logical packets per stream (multi-page support) ──
        const streams = {};
        for (const page of pages) {
            if (!streams[page.serial]) streams[page.serial] = [];
            const st  = streams[page.serial];
            const chunk = new Uint8Array(buffer, page.dataStart, page.dataLen);
            if (page.isContinued && st.length > 0) {
                // استكمال packet سابق ممتد على أكثر من page
                const prev = st[st.length - 1];
                const merged = new Uint8Array(prev.length + chunk.length);
                merged.set(prev, 0);
                merged.set(chunk, prev.length);
                st[st.length - 1] = merged;
            } else {
                st.push(new Uint8Array(chunk));
            }
        }

        // ── Step 3: find comment header in each stream ──
        for (const serial in streams) {
            for (const pkt of streams[serial]) {
                // Vorbis comment: \x03vorbis
                const isVorbis = pkt.length > 7 && pkt[0]===3&&pkt[1]===0x76&&pkt[2]===0x6F&&pkt[3]===0x72&&pkt[4]===0x62&&pkt[5]===0x69&&pkt[6]===0x73;
                // OpusTags
                const isOpus   = pkt.length > 8 && pkt[0]===0x4F&&pkt[1]===0x70&&pkt[2]===0x75&&pkt[3]===0x73&&
                                  pkt[4]===0x54&&pkt[5]===0x61&&pkt[6]===0x67&&pkt[7]===0x73;

                if (isVorbis || isOpus) {
                    const headerLen = isOpus ? 8 : 7;
                    const ab = pkt.buffer.slice ? pkt.buffer.slice(pkt.byteOffset, pkt.byteOffset + pkt.byteLength)
                                                : new Uint8Array(pkt).buffer;
                    parseVorbisComment(ab, headerLen, pkt.length - headerLen, tags);
                    // comment header واحد فقط في كل stream — بعد قراءته لا نحتاج الاستمرار في هذا الـ stream
                    break;
                }
            }
        }

        return tags;
    }

    // ─────────────────────────────────────────────
    // M4A / AAC (iTunes MP4 atoms)
    // ─────────────────────────────────────────────
    function parseM4A(buffer) {
        const u8 = new Uint8Array(buffer);
        // يجب أن يحتوي على "ftyp" في البايتات 4-7
        const sig = readString(buffer, 4, 4);
        if (sig !== 'ftyp' && sig !== 'moov' && sig !== 'mdat') {
            // Try scanning first 12 bytes for ftyp
            let found = false;
            for (let i = 0; i < Math.min(32, buffer.byteLength - 4); i++) {
                if (u8[i]===0x66&&u8[i+1]===0x74&&u8[i+2]===0x79&&u8[i+3]===0x70) { found = true; break; }
            }
            if (!found) return null;
        }

        const tags = emptyTags();
        findAtom(buffer, 0, buffer.byteLength, tags);
        return tags;
    }

    function findAtom(buffer, start, end, tags) {
        const dv = new DataView(buffer);
        let offset = start;
        while (offset + 8 <= end) {
            let size = dv.getUint32(offset, false);
            const name = readString(buffer, offset + 4, 4);
            if (size === 0) size = end - offset;
            if (size < 8 || offset + size > end) break;

            if (name === 'moov' || name === 'udta' || name === 'meta' || name === 'ilst' || name === 'trak' || name === 'mdia' || name === 'minf' || name === 'stbl') {
                // meta هو FullBox: له version(1)+flags(3) إضافية = 4 بايتات بعد الـ header
                const innerStart = name === 'meta' ? offset + 12 : offset + 8;
                findAtom(buffer, innerStart, offset + size, tags);
            } else if (name === '\xa9nam') { tags.title  = readIlstData(buffer, offset + 8, size - 8); }
            else if (name === '\xa9ART') { tags.artist = readIlstData(buffer, offset + 8, size - 8); }
            else if (name === '\xa9alb') { tags.album  = readIlstData(buffer, offset + 8, size - 8); }
            else if (name === '\xa9day') { tags.year   = (readIlstData(buffer, offset + 8, size - 8) || '').substring(0,4) || null; }
            else if (name === '\xa9gen' || name === 'gnre') { tags.genre = readIlstData(buffer, offset + 8, size - 8); }
            else if (name === 'covr') {
                const img = readCovr(buffer, offset + 8, size - 8);
                if (img) tags.images.push(img);
            }
            offset += size;
        }
    }

    function readIlstData(buffer, start, size) {
        try {
            const dv   = new DataView(buffer);
            let offset = start;
            while (offset + 8 <= start + size) {
                const asize = dv.getUint32(offset, false);
                if (asize < 8) break; // حماية من infinite loop
                const aname = readString(buffer, offset + 4, 4);
                if (aname === 'data' && asize > 16) {
                    return readUTF8(buffer, offset + 16, asize - 16);
                }
                offset += asize;
            }
        } catch(e) {}
        return null;
    }

    function readCovr(buffer, start, size) {
        try {
            const dv = new DataView(buffer);
            let offset = start;
            while (offset + 8 <= start + size) {
                const asize = dv.getUint32(offset, false);
                if (asize < 8) break; // حماية من infinite loop
                const aname = readString(buffer, offset + 4, 4);
                if (aname === 'data' && asize > 16) {
                    const flags = dv.getUint32(offset + 8, false);
                    const mime  = flags === 14 ? 'image/png' : 'image/jpeg';
                    return { mime, data: buffer.slice(offset + 16, offset + asize) };
                }
                offset += asize;
            }
        } catch(e) {}
        return null;
    }

    // ─────────────────────────────────────────────
    // WAV — INFO chunk + ID3 chunk
    // ─────────────────────────────────────────────
    function parseWAV(buffer) {
        const u8 = new Uint8Array(buffer);
        if (u8[0]!==0x52||u8[1]!==0x49||u8[2]!==0x46||u8[3]!==0x46) return null; // "RIFF"
        if (u8[8]!==0x57||u8[9]!==0x41||u8[10]!==0x56||u8[11]!==0x45) return null; // "WAVE"

        const tags = emptyTags();
        const dv   = new DataView(buffer);
        let offset = 12;

        while (offset + 8 <= buffer.byteLength) {
            const chunkId   = readString(buffer, offset, 4);
            const chunkSize = readUint32LE(dv, offset + 4);
            offset += 8;
            if (chunkId === 'LIST') {
                const listType = readString(buffer, offset, 4);
                if (listType === 'INFO') {
                    parseWAVInfo(buffer, offset + 4, chunkSize - 4, tags);
                }
            } else if (chunkId === 'id3 ' || chunkId === 'ID3 ' || chunkId === 'id3\0') {
                const id3Tags = parseID3v2(buffer.slice(offset, offset + chunkSize));
                if (id3Tags) mergeTags(tags, id3Tags);
            }
            // word-align: كل chunk يجب أن يبدأ على عنوان زوجي
            if (chunkSize === 0) break; // حماية من infinite loop
            offset += chunkSize + (chunkSize & 1);
            if (offset >= buffer.byteLength) break;
        }
        return tags;
    }

    function parseWAVInfo(buffer, start, size, tags) {
        const dv  = new DataView(buffer);
        let offset = start;
        while (offset + 8 <= start + size) {
            const key  = readString(buffer, offset, 4);
            const len  = readUint32LE(dv, offset + 4);
            if (len > size - (offset - start)) break; // حماية من قيم غير صالحة
            const val  = len > 0 ? readUTF8(buffer, offset + 8, len).trim() : '';
            const step = 8 + len + (len & 1);
            offset += step;
            if (step === 8 && len === 0) break; // حماية من infinite loop
            if (!val) continue;
            if      (key === 'INAM') tags.title  = val;
            else if (key === 'IART') tags.artist = val;
            else if (key === 'IPRD') tags.album  = val;
            else if (key === 'ICRD') tags.year   = val.substring(0,4);
            else if (key === 'IGNR') tags.genre  = val;
        }
    }

    // ─────────────────────────────────────────────
    // AIFF
    // ─────────────────────────────────────────────
    function parseAIFF(buffer) {
        const u8 = new Uint8Array(buffer);
        if (u8[0]!==0x46||u8[1]!==0x4F||u8[2]!==0x52||u8[3]!==0x4D) return null; // "FORM"
        const form = readString(buffer, 8, 4);
        if (form !== 'AIFF' && form !== 'AIFC') return null;

        const tags = emptyTags();
        const dv   = new DataView(buffer);
        let offset = 12;

        while (offset + 8 <= buffer.byteLength) {
            const chunkId   = readString(buffer, offset, 4);
            // استخدام Uint32 بدلاً من Int32 لتجنب القيم السالبة
            const chunkSize = dv.getUint32(offset + 4, false);
            offset += 8;
            if (chunkSize === 0 || offset + chunkSize > buffer.byteLength) break;

            if (chunkId === 'ID3 ' || chunkId === 'id3 ' || chunkId === 'ID3\0') {
                const id3Tags = parseID3v2(buffer.slice(offset, offset + chunkSize));
                if (id3Tags) mergeTags(tags, id3Tags);
            } else if (chunkId === 'NAME') {
                tags.title  = readUTF8(buffer, offset, chunkSize) || null;
            } else if (chunkId === 'AUTH') {
                tags.artist = readUTF8(buffer, offset, chunkSize) || null;
            } else if (chunkId === 'ANNO') {
                // ANNO يُستخدم أحياناً للـ comment لكن بعض الأدوات تضع فيه الـ genre
                if (!tags.genre) tags.genre = readUTF8(buffer, offset, chunkSize) || null;
            }
            // AIFF: 2-byte alignment
            offset += chunkSize + (chunkSize & 1);
        }
        return tags;
    }

    // ─────────────────────────────────────────────
    // WMA / ASF
    // ─────────────────────────────────────────────
    function parseASF(buffer) {
        const u8 = new Uint8Array(buffer);
        // ASF Header Object GUID: 30 26 B2 75 8E 66 CF 11 A6 D9 00 AA 00 62 CE 6C
        if (u8[0]!==0x30||u8[1]!==0x26||u8[2]!==0xB2||u8[3]!==0x75) return null;

        const tags = emptyTags();
        const dv   = new DataView(buffer);
        // Object count at offset 24
        const objCount = dv.getUint32(24, true);
        let offset = 30;

        for (let n = 0; n < objCount && offset + 24 <= buffer.byteLength; n++) {
            // Each object: GUID (16) + size (8)
            const objSize = Number(dv.getBigUint64(offset + 16, true));
            // GUID مخزّن كـ bytes خام — نقارنه مع القيم المعروفة byte-by-byte
            const guidBytes = new Uint8Array(buffer, offset, 16);
            const guidStr = Array.from(guidBytes).map(b => b.toString(16).padStart(2,'0')).join('');

            // Content Description Object: {75B22633-668E-11CF-A6D9-00AA0062CE6C}
            // byte order في الملف: 33 26 B2 75  8E 66  CF 11  A6 D9  00 AA 00 62 CE 6C
            const isContentDesc = guidBytes[0]===0x33&&guidBytes[1]===0x26&&guidBytes[2]===0xB2&&guidBytes[3]===0x75&&
                                   guidBytes[4]===0x8E&&guidBytes[5]===0x66&&guidBytes[6]===0xCF&&guidBytes[7]===0x11;
            // Extended Content Description: {D2D0A440-E307-11D2-97F0-00A0C95EA850}
            // byte order: 40 A4 D0 D2  07 E3  D2 11  97 F0  00 A0 C9 5E A8 50
            const isExtDesc = guidBytes[0]===0x40&&guidBytes[1]===0xA4&&guidBytes[2]===0xD0&&guidBytes[3]===0xD2&&
                               guidBytes[4]===0x07&&guidBytes[5]===0xE3&&guidBytes[6]===0xD2&&guidBytes[7]===0x11;

            if (isContentDesc) {
                parseASFContentDesc(buffer, offset + 24, objSize - 24, tags);
            }
            else if (isExtDesc) {
                parseASFExtDesc(buffer, offset + 24, objSize - 24, tags);
            }
            offset += objSize;
        }
        return tags;
    }

    function parseASFContentDesc(buffer, start, size, tags) {
        const dv = new DataView(buffer);
        let i = start;
        const fields = ['title','artist','copyright','description','rating'];
        const lengths = [];
        for (let n = 0; n < 5; n++) { lengths.push(dv.getUint16(i, true)); i += 2; }
        for (let n = 0; n < 5; n++) {
            const len = lengths[n];
            if (len > 0) {
                const val = new TextDecoder('utf-16le').decode(new Uint8Array(buffer, i, len)).replace(/\0/g,'').trim();
                if (fields[n] === 'title')  tags.title  = val || null;
                if (fields[n] === 'artist') tags.artist = val || null;
            }
            i += len;
        }
    }

    function parseASFExtDesc(buffer, start, size, tags) {
        const dv = new DataView(buffer);
        let i = start;
        if (i + 2 > start + size) return;
        const count = dv.getUint16(i, true); i += 2;
        for (let n = 0; n < count; n++) {
            if (i + 2 > start + size) break;
            const nameLen = dv.getUint16(i, true); i += 2;
            if (nameLen === 0 || i + nameLen > start + size) break;
            const name = new TextDecoder('utf-16le').decode(new Uint8Array(buffer, i, nameLen)).replace(/\0/g,'').trim(); i += nameLen;
            if (i + 4 > start + size) break;
            const valType = dv.getUint16(i, true); i += 2;
            const valLen  = dv.getUint16(i, true); i += 2;
            if (i + valLen > start + size) break;
            const key = name.toLowerCase();
            if (valType === 0) {
                // نص UTF-16LE
                const val = new TextDecoder('utf-16le').decode(new Uint8Array(buffer, i, valLen)).replace(/\0/g,'').trim();
                if (key === 'wm/albumtitle' || key === 'album') tags.album = val || null;
                if (key === 'wm/year')   tags.year  = val || null;
                if (key === 'wm/genre')  tags.genre = val || null;
            } else if (valType === 1 && key === 'wm/picture' && tags.images.length === 0) {
                // WM/Picture — بيانات ثنائية خام
                // الهيكل: pictureType(1) + dataLen(4) + mimeType(UTF-16LE null-term) + description(UTF-16LE null-term) + imageData
                try {
                    let p = i;
                    p += 1; // تخطي pictureType
                    const imgDataLen = dv.getUint32(p, true); p += 4;
                    // قراءة MIME type (UTF-16LE null-terminated)
                    const mimeStart = p;
                    while (p + 1 < i + valLen && (dv.getUint8(p) !== 0 || dv.getUint8(p+1) !== 0)) p += 2;
                    const mimeRaw = new TextDecoder('utf-16le').decode(new Uint8Array(buffer, mimeStart, p - mimeStart)).toLowerCase();
                    p += 2; // تخطي null terminator
                    // تخطي description (UTF-16LE null-terminated)
                    while (p + 1 < i + valLen && (dv.getUint8(p) !== 0 || dv.getUint8(p+1) !== 0)) p += 2;
                    p += 2;
                    if (p + imgDataLen <= i + valLen && imgDataLen > 0) {
                        const mime = mimeRaw.includes('png') ? 'image/png' : 'image/jpeg';
                        tags.images.push({ mime, data: buffer.slice(p, p + imgDataLen) });
                    }
                } catch(e) {}
            }
            i += valLen;
        }
    }

    // ─────────────────────────────────────────────
    // APE Tags (نهاية الملف) — MP3 / APE / WavPack
    // ─────────────────────────────────────────────
    function parseAPEv2(buffer) {
        if (buffer.byteLength < 32) return null;
        const u8 = new Uint8Array(buffer);
        const dv = new DataView(buffer);

        // البحث عن APEv2 preamble في آخر 32 بايت
        // قد يكون هناك ID3v1 (128 بايت) بعد APEv2 footer، لذا نبحث في آخر 512 بايت
        const searchStart = Math.max(0, buffer.byteLength - 512);
        let apeOffset = -1;
        for (let i = buffer.byteLength - 8; i >= searchStart; i--) {
            if (u8[i]===0x41&&u8[i+1]===0x50&&u8[i+2]===0x45&&u8[i+3]===0x54 &&
                u8[i+4]===0x41&&u8[i+5]===0x47&&u8[i+6]===0x45&&u8[i+7]===0x58) {
                // "APETAGEX" footer found
                // وفق مواصفات APEv2: tagSize يشمل items + header (32) إذا وُجد
                // الـ header يبدأ عند: footer_start - tagSize
                // الـ items  تبدأ عند: footer_start - tagSize + 32 (إذا وُجد header)
                //                 أو: footer_start - tagSize        (إذا لم يوجد)
                const tagSize  = dv.getUint32(i + 12, true);
                const apeFlags = dv.getUint32(i + 20, true);
                const hasHeader = (apeFlags & (1 << 31)) !== 0;
                apeOffset = i - tagSize; // دائماً بداية منطقة التاغات (header أو items مباشرة)
                break;
            }
        }
        if (apeOffset < 0) return null;

        const tags  = emptyTags();
        // APEv2 Header: preamble(8) + version(4) + tagSize(4) + itemCount(4) + flags(4) + reserved(8) = 32 bytes
        // hasHeader يُحدد إن كانت الـ items بعد الـ header مباشرة أو تبدأ من apeOffset
        const itemsStart = hasHeader ? apeOffset + 32 : apeOffset;
        const count = apeOffset + 16 < buffer.byteLength
            ? dv.getUint32(apeOffset + 16, true) : 0; // item count من الـ header
        let i = itemsStart;

        for (let n = 0; n < count && i < buffer.byteLength; n++) {
            const itemSize  = readUint32LE(dv, i); i += 4;
            const itemFlags = readUint32LE(dv, i); i += 4;
            let keyEnd = i;
            while (keyEnd < buffer.byteLength && u8[keyEnd] !== 0) keyEnd++;
            const key = readString(buffer, i, keyEnd - i).toLowerCase(); i = keyEnd + 1;
            const val = readUTF8(buffer, i, itemSize).trim(); i += itemSize;
            if (!val) continue;
            if      (key === 'title')  tags.title  = val;
            else if (key === 'artist') tags.artist = val;
            else if (key === 'album')  tags.album  = val;
            else if (key === 'year')   tags.year   = val;
            else if (key === 'genre')  tags.genre  = val;
        }
        return tags;
    }

    // ─────────────────────────────────────────────
    // دمج النتائج
    // ─────────────────────────────────────────────
    function mergeTags(base, extra) {
        if (!base.title  && extra.title)  base.title  = extra.title;
        if (!base.artist && extra.artist) base.artist = extra.artist;
        if (!base.album  && extra.album)  base.album  = extra.album;
        if (!base.year   && extra.year)   base.year   = extra.year;
        if (!base.genre  && extra.genre)  base.genre  = extra.genre;
        if (base.images.length === 0)     base.images = extra.images;
        return base;
    }

    // ─────────────────────────────────────────────
    // تحديد نوع الملف
    // ─────────────────────────────────────────────
    function detectFormat(u8, filename) {
        const ext = (filename || '').split('.').pop().toLowerCase();

        // Magic bytes — FLAC يُفحص أولاً لأن بعض الملفات تحمل بادئة ID3v2 قبل هيدر fLaC
        if (u8[0]===0x66&&u8[1]===0x4C&&u8[2]===0x61&&u8[3]===0x43) return 'flac';
        // فحص وجود هيدر fLaC في أول 64 بايت (حالة FLAC مع ID3v2 tag في البداية)
        for (let _f = 1; _f < Math.min(64, u8.length - 3); _f++) {
            if (u8[_f]===0x66&&u8[_f+1]===0x4C&&u8[_f+2]===0x61&&u8[_f+3]===0x43) return 'flac';
        }
        if (u8[0]===0x49&&u8[1]===0x44&&u8[2]===0x33) return 'mp3-id3v2';
        if (u8[0]===0x4F&&u8[1]===0x67&&u8[2]===0x67&&u8[3]===0x53) return 'ogg';
        if (u8[4]===0x66&&u8[5]===0x74&&u8[6]===0x79&&u8[7]===0x70) return 'm4a';
        if (u8[0]===0x52&&u8[1]===0x49&&u8[2]===0x46&&u8[3]===0x46) {
            if (u8[8]===0x57&&u8[9]===0x41&&u8[10]===0x56&&u8[11]===0x45) return 'wav';
            if (u8[8]===0x57&&u8[9]===0x56&&u8[10]===0x50&&u8[11]===0x4B) return 'wavpack';
        }
        if (u8[0]===0x46&&u8[1]===0x4F&&u8[2]===0x52&&u8[3]===0x4D) return 'aiff';
        if (u8[0]===0x30&&u8[1]===0x26&&u8[2]===0xB2&&u8[3]===0x75) return 'wma';
        if (u8[0]===0x4D&&u8[1]===0x41&&u8[2]===0x43&&u8[3]===0x20) return 'ape';
        if (u8[0]===0x77&&u8[1]===0x76&&u8[2]===0x70&&u8[3]===0x6B) return 'wavpack';

        // MP3 بدون ID3 header: يبدأ بـ MPEG sync word (0xFF 0xEX أو 0xFF 0xFX)
        if (u8[0] === 0xFF && (u8[1] & 0xE0) === 0xE0) return 'mp3-id3v2';

        // Fallback by extension
        if (ext === 'mp3' || ext === 'mp2') return 'mp3-id3v2';
        if (ext === 'flac') return 'flac';
        if (ext === 'ogg' || ext === 'oga') return 'ogg';
        if (ext === 'opus') return 'ogg';
        if (ext === 'm4a' || ext === 'm4b' || ext === 'aac' || ext === 'mp4') return 'm4a';
        if (ext === 'wav' || ext === 'wave') return 'wav';
        if (ext === 'aiff' || ext === 'aif') return 'aiff';
        if (ext === 'wma' || ext === 'asf' || ext === 'wmv') return 'wma';
        if (ext === 'ape') return 'ape';
        if (ext === 'wv') return 'wavpack';

        return 'unknown';
    }

    // ─────────────────────────────────────────────
    // القائمة الكاملة لأنواع الموسيقى (ID3 genre)
    // ─────────────────────────────────────────────
    const GENRES = [
        'Blues','Classic Rock','Country','Dance','Disco','Funk','Grunge','Hip-Hop','Jazz','Metal',
        'New Age','Oldies','Other','Pop','R&B','Rap','Reggae','Rock','Techno','Industrial',
        'Alternative','Ska','Death Metal','Pranks','Soundtrack','Euro-Techno','Ambient','Trip-Hop','Vocal','Jazz+Funk',
        'Fusion','Trance','Classical','Instrumental','Acid','House','Game','Sound Clip','Gospel','Noise',
        'Alternative Rock','Bass','Soul','Punk','Space','Meditative','Instrumental Pop','Instrumental Rock','Ethnic','Gothic',
        'Darkwave','Techno-Industrial','Electronic','Pop-Folk','Eurodance','Dream','Southern Rock','Comedy','Cult','Gangsta',
        'Top 40','Christian Rap','Pop/Funk','Jungle','Native US','Cabaret','New Wave','Psychedelic','Rave','Showtunes',
        'Trailer','Lo-Fi','Tribal','Acid Punk','Acid Jazz','Polka','Retro','Musical','Rock & Roll','Hard Rock',
        'Folk','Folk-Rock','National Folk','Swing','Fast Fusion','Bebob','Latin','Revival','Celtic','Bluegrass',
        'Avantgarde','Gothic Rock','Progressive Rock','Psychedelic Rock','Symphonic Rock','Slow Rock','Big Band','Chorus','Easy Listening','Acoustic',
        'Humour','Speech','Chanson','Opera','Chamber Music','Sonata','Symphony','Booty Bass','Primus','Porn Groove',
        'Satire','Slow Jam','Club','Tango','Samba','Folklore','Ballad','Power Ballad','Rhythmic Soul','Freestyle',
        'Duet','Punk Rock','Drum Solo','A Cappella','Euro-House','Dance Hall','Goa','Drum & Bass','Club-House','Hardcore',
        'Terror','Indie','BritPop','Negerpunk','Polsk Punk','Beat','Christian Gangsta Rap','Heavy Metal','Black Metal','Crossover',
        'Contemporary Christian','Christian Rock','Merengue','Salsa','Thrash Metal','Anime','JPop','Synthpop','Abstract','Art Rock',
        'Baroque','Bhangra','Big Beat','Breakbeat','Chillout','Downtempo','Dub','EBM','Eclectic','Electro',
        'Electroclash','Emo','Experimental','Garage','Global','IDM','Illbient','Industro-Goth','Jam Band','Krautrock',
        'Leftfield','Lounge','Math Rock','New Romantic','Nu-Breakz','Post-Punk','Post-Rock','Psytrance','Shoegaze','Space Rock',
        'Trop Rock','World Music','Neoclassical','Audiobook','Audio Theatre','Neue Deutsche Welle','Podcast','Indie-Rock','G-Funk','Dubstep',
        'Garage Rock','Psybient'
    ];

    function resolveGenre(g) {
        if (!g) return g;
        const m = g.match(/^\((\d+)\)(.*)$/);
        if (m) {
            const idx = parseInt(m[1]);
            return GENRES[idx] || m[2].trim() || g;
        }
        const idx = parseInt(g);
        if (!isNaN(idx) && GENRES[idx]) return GENRES[idx];
        return g;
    }

    // ─────────────────────────────────────────────
    // الدالة الرئيسية — تقرأ الملف وتعيد الـ tags
    // ─────────────────────────────────────────────
    const musicMetadata = {
        fromFile: async function(file) {
            return new Promise((resolve, reject) => {
                // نقرأ أول 4 MB كافية لسحب الـ tags والصورة
                // OGG/Opus تخزن الـ tags في بداية الملف لكن الصورة قد تكون كبيرة
                // نقرأ 8MB لضمان احتواء الصورة كاملةً
                const sliceSize = Math.min(file.size, 32 * 1024 * 1024);
                const reader    = new FileReader();

                reader.onload = (e) => {
                    try {
                        const buffer = e.target.result;
                        const u8     = new Uint8Array(buffer);
                        const format = detectFormat(u8, file.name);
                        let tags     = null;

                        if (format === 'mp3-id3v2') {
                            tags = parseID3v2(buffer);
                            // APEv2 قد يكون بديلاً أو إضافةً لـ ID3
                            const ape = parseAPEv2(buffer);
                            if (ape) tags = mergeTags(tags || emptyTags(), ape);
                        } else if (format === 'flac') {
                            tags = parseFLAC(buffer);
                        } else if (format === 'ogg') {
                            tags = parseOGG(buffer);
                        } else if (format === 'm4a') {
                            tags = parseM4A(buffer);
                        } else if (format === 'wav') {
                            tags = parseWAV(buffer);
                        } else if (format === 'aiff') {
                            tags = parseAIFF(buffer);
                        } else if (format === 'wma') {
                            tags = parseASF(buffer);
                        } else if (format === 'ape' || format === 'wavpack') {
                            tags = parseAPEv2(buffer);
                        } else {
                            tags = parseID3v2(buffer) || parseAPEv2(buffer) || emptyTags();
                        }

                        tags = tags || emptyTags();

                        // ID3v1 يكون في آخر 128 بايت من الملف الكامل
                        // إذا لم نقرأ الملف كاملاً نقرأ نهايته منفصلاً
                        if (format === 'mp3-id3v2' && (!tags.title && !tags.artist)) {
                            if (file.size <= sliceSize) {
                                const v1 = parseID3v1(buffer);
                                if (v1) tags = mergeTags(tags, v1);
                                resolve(tags);
                            } else {
                                // الملف أكبر من الـ slice — نقرأ آخر 128 بايت منفصلاً
                                const tailReader = new FileReader();
                                tailReader.onload = (e2) => {
                                    try {
                                        const v1 = parseID3v1(e2.target.result);
                                        if (v1) tags = mergeTags(tags, v1);
                                    } catch(_) {}
                                    resolve(tags);
                                };
                                tailReader.onerror = () => resolve(tags);
                                tailReader.readAsArrayBuffer(file.slice(file.size - 128));
                            }
                        } else {
                            resolve(tags);
                        }
                    } catch(err) {
                        console.warn('[music-metadata] parse error:', err);
                        resolve(emptyTags());
                    }
                };

                reader.onerror = () => resolve(emptyTags());
                reader.readAsArrayBuffer(file.slice(0, sliceSize));
            });
        }
    };

    return musicMetadata;
})));
