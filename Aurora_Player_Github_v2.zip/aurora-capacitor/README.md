# 🎵 Aurora Player — APK Build Guide

## المتطلبات أولاً
تأكد أن عندك مثبّت على جهازك:
- [Node.js](https://nodejs.org) (v18 أو أحدث)
- [Android Studio](https://developer.android.com/studio) (مع Android SDK)
- Java JDK 17+

---

## 🚀 خطوات البناء (Capacitor)

### الخطوة 1 — تثبيت الحزم
افتح Terminal داخل مجلد `aurora-capacitor` ونفّذ:

```bash
npm install
```

### الخطوة 2 — إضافة منصة Android
```bash
npx cap add android
```

### الخطوة 3 — مزامنة الملفات
```bash
npx cap sync android
```

### الخطوة 4 — بناء APK مباشرة
```bash
cd android
./gradlew assembleDebug
```

ستجد الـ APK في:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

### أو: فتح Android Studio وبناء منه
```bash
npx cap open android
```
ثم في Android Studio:
- اختر **Build → Build Bundle(s) / APK(s) → Build APK(s)**

---

## 🌐 الطريقة الأسهل — PWABuilder (بدون كود!)

1. ارفع محتوى مجلد `www` على GitHub Pages:
   - أنشئ Repository جديد على GitHub
   - ارفع جميع ملفات `www` إليه
   - فعّل GitHub Pages من Settings → Pages

2. اذهب إلى [pwabuilder.com](https://pwabuilder.com)

3. أدخل رابط موقعك (مثال: `https://username.github.io/aurora-player`)

4. اضغط **Start** ثم **Build My PWA**

5. اختر **Android** → **Generate Package**

6. حمّل الـ APK مباشرة! ✅

---

## ملاحظات مهمة

- الـ APK الناتج من Capacitor يعمل على Android 5.0+
- Aurora Player يستخدم Web Audio API — يعمل بشكل ممتاز داخل WebView
- لنشره على Google Play استخدم `assembleRelease` بدلاً من `assembleDebug` مع keystore

---

## هيكل المشروع
```
aurora-capacitor/
├── www/                    ← ملفات Aurora Player الكاملة
│   ├── index.html
│   ├── style.css
│   ├── manifest.json
│   ├── service-worker.js
│   ├── music-metadata.js
│   ├── js/
│   └── icons/
├── capacitor.config.json   ← إعدادات Capacitor
├── package.json
└── README.md               ← هذا الملف
```
